﻿namespace WebApiFacturacion.Models.Domain
{
    public class VariablesDiversasModel
    {
        public decimal PorcentajeValorIGV { get; set; } = 18;

        public (string CodigoTributo, string Nombre, string CodigoInternacional) DatosCodigoTributo(string tipoIGV)
        {
            return tipoIGV switch
            {
                "10" => ("1000", "IGV", "VAT"),
                "20" => ("9997", "EXO", "VAT"),
                "30" => ("9998", "INA", "FRE"),
                _ => ("9999", "OTRO", "OTH"),
            };
        }

        public decimal TaxAmount(decimal cantidad, decimal precioBase, string codigoTributo, decimal porcentajeIGV, decimal descuento)
        {
            if (codigoTributo == "1000")
                return Math.Round(cantidad * (precioBase - descuento) * (porcentajeIGV / 100), 2);
            return 0;
        }

        public decimal PriceAmount(decimal precioBase, string codigoTributo, decimal porcentajeIGV, decimal otro, decimal descuento)
        {
            if (codigoTributo == "1000")
                return Math.Round((precioBase - descuento) * (1 + porcentajeIGV / 100), 6);
            return precioBase;
        }
    }
}
