﻿namespace WebApiFacturacion.Models.Dto
{
    public class Empresa
    {
        public string ruc { get; set; }
        public string razon_social { get; set; }
        public string nombre_comercial { get; set; }
        public string domicilio_fiscal { get; set; }
        public string ubigeo { get; set; }
        public string urbanizacion { get; set; }
        public string distrito { get; set; }
        public string provincia { get; set; }
        public string departamento { get; set; }
        public string modo { get; set; }
        public string usu_secundario_produccion_user { get; set; }
        public string usu_secundario_produccion_password { get; set; }
    }
}
