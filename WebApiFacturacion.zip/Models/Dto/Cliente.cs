﻿namespace WebApiFacturacion.Models.Dto
{
    public class Cliente
    {
        public string razon_social_nombres { get; set; }
        public string numero_documento { get; set; }
        public string codigo_tipo_entidad { get; set; }
        public string cliente_direccion { get; set; }
    }
}
