﻿namespace WebApiFacturacion.Models.Dto
{
    public class VentaJson
    {
        public string serie { get; set; }
        public string numero { get; set; }
        public string fecha_emision { get; set; }
        public string hora_emision { get; set; }
        public string fecha_vencimiento { get; set; }
        public string moneda_id { get; set; }
        public string forma_pago_id { get; set; }
        public string total_gravada { get; set; }
        public string total_igv { get; set; }
        public string total_exonerada { get; set; }
        public string total_inafecta { get; set; }
        public string tipo_documento_codigo { get; set; }
        public string nota { get; set; }
    }
}
