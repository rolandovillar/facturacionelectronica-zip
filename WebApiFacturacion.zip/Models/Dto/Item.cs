﻿namespace WebApiFacturacion.Models.Dto
{
    public class Item
    {
         public string producto { get; set; }
        public string cantidad { get; set; }
        public string precio_base { get; set; }
        public string codigo_sunat { get; set; }
        public string codigo_producto { get; set; }
        public string codigo_unidad { get; set; }
        public string tipo_igv_codigo { get; set; }
    }
}
