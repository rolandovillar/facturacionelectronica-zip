﻿namespace WebApiFacturacion.Models.Dto
{
    public class Cuota
    {
    }
}
