﻿namespace WebApiFacturacion.Models.Dto
{
    public class FacturaJson
    {
        public Empresa empresa { get; set; }
        public Cliente cliente { get; set; }
        public VentaJson venta { get; set; }
        public List<Item> items { get; set; }
    }
}
