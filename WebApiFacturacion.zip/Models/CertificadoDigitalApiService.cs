﻿namespace WebApiFacturacion.Models
{
    public class CertificadoDigitalApiService
    {
    }
}
