﻿using Microsoft.AspNetCore.Mvc;
using QRCoder;
using WebApiFacturacion.Models;
using WebApiFacturacion.Models.Dto;

[ApiController]
[Route("api/factura")]
public class FacturaController : ControllerBase
{
    private readonly IXmlUblBuilder _xml;
    private readonly IXmlSigner _sign;
    private readonly ISunatClient _sunat;
    private readonly IPdfGenerator _pdf;

    public FacturaController(
        IXmlUblBuilder xml,
        IXmlSigner sign,
        ISunatClient sunat,
        IPdfGenerator pdf)
    {
        _xml = xml;
        _sign = sign;
        _sunat = sunat;
        _pdf = pdf;
    }

    [HttpPost("generar")]
    public async Task<IActionResult> Generar([FromBody] FacturaJson factura)
    {
        // --- 1. Generar el XML UBL ---
        var xmlDoc = _xml.GenerarXml(factura);

           // --- 2. Firmar digitalmente el XML ---
        var xmlFirmado = _sign.Firmar(xmlDoc,"Certificates/certificado.pfx","tuClaveDelPfx");

        // --- 3. Elegir endpoint SUNAT según modo ---
        // modo == "1" → producción, cualquier otro → beta
        const string UrlBeta = "https://e-beta.sunat.gob.pe/ol-ti-itcpfegem-beta/billService";
        const string UrlProduccion = "https://e-factura.sunat.gob.pe/ol-ti-itcpfegem/billService";
        var endpoint = factura.empresa.modo == "1" ? UrlProduccion : UrlBeta;

        // --- 4. Preparar credenciales desde el JSON ---
        var creds = new Credentials(
            factura.empresa.usu_secundario_produccion_user,
            factura.empresa.usu_secundario_produccion_password
        );

        // --- 5. Enviar a SUNAT y obtener respuesta CDR/XML ---
        var respuestaSunat = await _sunat.EnviarAsync(xmlFirmado, endpoint, creds);

        // --- 6. Generar código QR a partir de la “cadena para QR” de SUNAT ---
        // (típicamente: RUC|TIPO|SERIE|NUMERO|IGV|TOTAL|FECHA|TIPO_DOC|NRO_DOC|)
        var cadenaParaQr = $"{factura.empresa.ruc}|{factura.venta.tipo_documento_codigo}|{factura.venta.serie}|{factura.venta.numero}|{factura.venta.total_igv}|{factura.venta.total_gravada}|{factura.venta.fecha_emision}|{factura.cliente.codigo_tipo_entidad}|{factura.cliente.numero_documento}";
        using var qrGen = new QRCodeGenerator();
        var qrData = qrGen.CreateQrCode(cadenaParaQr, QRCodeGenerator.ECCLevel.Q);
        var qrPng = new PngByteQRCode(qrData).GetGraphic(20);

        // --- 7. Generar el PDF final (incluir XML firmado, QR, respuesta Sunat, etc.) ---
        var pdfBytes = _pdf.GenerarPdf(factura, xmlFirmado, qrPng, respuestaSunat);

        // --- 8. Devolver el PDF al cliente ---
        var fileName = $"{factura.venta.serie}-{factura.venta.numero}.pdf";
        return File(pdfBytes, "application/pdf", fileName);
    }
}