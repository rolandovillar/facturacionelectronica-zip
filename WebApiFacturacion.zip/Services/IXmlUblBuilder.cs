﻿using System.Xml;
using WebApiFacturacion.Models;
using WebApiFacturacion.Models.Dto;

public interface IXmlUblBuilder
{
    XmlDocument GenerarXml(FacturaJson factura);
}
namespace WebApiFacturacion.Services
{
    public interface IXmlUblBuilder
    {
        XmlDocument GenerarXml(FacturaJson factura);
    }
}
