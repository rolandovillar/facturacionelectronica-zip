﻿using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Xml;

public class XmlSigner : IXmlSigner
{
    public XmlDocument Firmar(XmlDocument xml, string rutaPfx, string clavePfx)
    {
        // 1. Cargo el certificado con clave
        var cert = new X509Certificate2(rutaPfx, clavePfx, X509KeyStorageFlags.MachineKeySet);

        // 2. Inicializo SignedXml sobre el documento
        var signed = new SignedXml(xml)
        {
            SigningKey = cert.GetRSAPrivateKey()!
        };

        // 3. Creo la referencia al nodo raíz (URI="")
        var reference = new Reference { Uri = "" };
        reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
        signed.AddReference(reference);

        // 4. Creo y asigno KeyInfo
        var keyInfo = new KeyInfo();
        // Incluyo el certificado X509 dentro de la firma
        keyInfo.AddClause(new KeyInfoX509Data(cert));
        signed.KeyInfo = keyInfo;

        // 5. Calculo la firma
        signed.ComputeSignature();

        // 6. Obtengo el XML de la firma y lo anexo al documento original
        var xmlSignature = signed.GetXml();
        xml.DocumentElement!.AppendChild(xml.ImportNode(xmlSignature, true));

        return xml;
    }
}