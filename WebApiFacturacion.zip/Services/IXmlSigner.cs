﻿using System.Xml;

public interface IXmlSigner
{
    XmlDocument Firmar(XmlDocument xml, string rutaPfx, string clavePfx);
}