﻿using System.Net;
using System.Threading.Tasks;
using System.Xml;

public interface ISunatClient
{
    Task<string> EnviarAsync(XmlDocument xmlFirmado, string servicioUrl, Credentials creds);
}