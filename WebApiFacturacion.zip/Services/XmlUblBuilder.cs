﻿using System.Xml;
using WebApiFacturacion.Models.Dto;

public class XmlUblBuilder : IXmlUblBuilder
{
    public XmlDocument GenerarXml(FacturaJson factura)
    {
        var ns = "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2";
        var doc = new XmlDocument();
        doc.PreserveWhitespace = true;

        var inv = doc.CreateElement("Invoice", ns);
        inv.SetAttribute("xmlns:cac", "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2");
        inv.SetAttribute("xmlns:cbc", "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2");
        inv.SetAttribute("xmlns:ext", "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2");
        inv.SetAttribute("xmlns:ds", "http://www.w3.org/2000/09/xmldsig#");
        doc.AppendChild(inv);

        // ===== 1. ext:UBLExtensions (firma) =====
        var ext = doc.CreateElement("ext:UBLExtensions", ns);
        var ext1 = doc.CreateElement("ext:UBLExtension", ns);
        var extContent = doc.CreateElement("ext:ExtensionContent", ns);
        ext1.AppendChild(extContent);
        ext.AppendChild(ext1);
        inv.AppendChild(ext);

        // ===== 2. Datos Generales =====
        inv.AppendChild(CreateElement(doc, ns, "cbc:UBLVersionID", "2.1"));
        inv.AppendChild(CreateElement(doc, ns, "cbc:CustomizationID", "2.0"));
        inv.AppendChild(CreateElement(doc, ns, "cbc:ID", $"{factura.venta.serie}-{factura.venta.numero}"));
        inv.AppendChild(CreateElement(doc, ns, "cbc:IssueDate", factura.venta.fecha_emision));
        inv.AppendChild(CreateElement(doc, ns, "cbc:IssueTime", factura.venta.hora_emision));
        inv.AppendChild(CreateElement(doc, ns, "cbc:InvoiceTypeCode", factura.venta.tipo_documento_codigo));
        inv.AppendChild(CreateElement(doc, ns, "cbc:DocumentCurrencyCode", "PEN"));

        // ===== 3. Firma =========
        var signature = doc.CreateElement("cac:Signature", ns);
        signature.AppendChild(CreateElement(doc, ns, "cbc:ID", "IDSignKG"));

        var sigParty = doc.CreateElement("cac:SignatoryParty", ns);
        var partyId = doc.CreateElement("cac:PartyIdentification", ns);
        partyId.AppendChild(CreateElement(doc, ns, "cbc:ID", factura.empresa.ruc));
        sigParty.AppendChild(partyId);
        signature.AppendChild(sigParty);

        var sigAttachment = doc.CreateElement("cac:DigitalSignatureAttachment", ns);
        var extRef = doc.CreateElement("cac:ExternalReference", ns);
        extRef.AppendChild(CreateElement(doc, ns, "cbc:URI", "#signatureKG"));
        sigAttachment.AppendChild(extRef);
        signature.AppendChild(sigAttachment);

        inv.AppendChild(signature);

        // ===== 4. Emisor =====
        var supplier = doc.CreateElement("cac:AccountingSupplierParty", ns);
        var party = doc.CreateElement("cac:Party", ns);
        var partyIdSup = doc.CreateElement("cac:PartyIdentification", ns);
        partyIdSup.AppendChild(CreateElement(doc, ns, "cbc:ID", factura.empresa.ruc));
        party.AppendChild(partyIdSup);

        var partyName = doc.CreateElement("cac:PartyLegalEntity", ns);
        partyName.AppendChild(CreateElement(doc, ns, "cbc:RegistrationName", factura.empresa.razon_social));
        party.AppendChild(partyName);
        supplier.AppendChild(party);
        inv.AppendChild(supplier);

        // ===== 5. Cliente =====
        var customer = doc.CreateElement("cac:AccountingCustomerParty", ns);
        var partyC = doc.CreateElement("cac:Party", ns);
        var partyIdCus = doc.CreateElement("cac:PartyIdentification", ns);
        partyIdCus.AppendChild(CreateElement(doc, ns, "cbc:ID", factura.cliente.numero_documento));
        partyC.AppendChild(partyIdCus);

        var partyNameC = doc.CreateElement("cac:PartyLegalEntity", ns);
        partyNameC.AppendChild(CreateElement(doc, ns, "cbc:RegistrationName", factura.cliente.razon_social_nombres));
        partyC.AppendChild(partyNameC);
        customer.AppendChild(partyC);
        inv.AppendChild(customer);

        // ===== 6. Totales =====
        var totalGravada = decimal.Parse(factura.venta.total_gravada);
        var totalIGV = decimal.Parse(factura.venta.total_igv);
        var total = totalGravada + totalIGV;

        var taxTotal = doc.CreateElement("cac:TaxTotal", ns);
        taxTotal.AppendChild(CreateElement(doc, ns, "cbc:TaxAmount", totalIGV.ToString("0.00")));
        inv.AppendChild(taxTotal);

        var legalTotal = doc.CreateElement("cac:LegalMonetaryTotal", ns);
        legalTotal.AppendChild(CreateElement(doc, ns, "cbc:PayableAmount", total.ToString("0.00")));
        inv.AppendChild(legalTotal);

        // ===== 7. Detalle de Ítems =====
        int i = 1;
        foreach (var item in factura.items)
        {
            var line = doc.CreateElement("cac:InvoiceLine", ns);
            line.AppendChild(CreateElement(doc, ns, "cbc:ID", i.ToString()));
            line.AppendChild(CreateElement(doc, ns, "cbc:InvoicedQuantity", item.cantidad));
            var montoLinea = decimal.Parse(item.precio_base) * decimal.Parse(item.cantidad);
            line.AppendChild(CreateElement(doc, ns, "cbc:LineExtensionAmount", montoLinea.ToString("0.00")));

            var price = doc.CreateElement("cac:Price", ns);
            price.AppendChild(CreateElement(doc, ns, "cbc:PriceAmount", item.precio_base));
            line.AppendChild(price);

            inv.AppendChild(line);
            i++;
        }

        return doc;
    }

    private XmlElement CreateElement(XmlDocument doc, string ns, string name, string value)
    {
        var el = doc.CreateElement(name, ns);
        el.InnerText = value ?? "";
        return el;
    }
}