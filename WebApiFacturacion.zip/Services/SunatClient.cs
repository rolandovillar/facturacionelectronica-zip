﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

public class SunatClient : ISunatClient
{
    private readonly HttpClient _http;
    public SunatClient(HttpClient http) => _http = http;

    public async Task<string> EnviarAsync(XmlDocument xml, string url, Credentials creds)
    {
        var content = new StringContent(xml.OuterXml, Encoding.UTF8, "application/xml");
        // Agregar credenciales en headers si es necesario...
        var resp = await _http.PostAsync(url, content);
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadAsStringAsync();
    }
}

public record Credentials(string Usuario, string Clave);