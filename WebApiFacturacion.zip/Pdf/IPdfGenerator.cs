﻿using System.Xml;
using WebApiFacturacion.Models.Dto;

namespace WebApiFacturacion.Models
{
    public interface IPdfGenerator
    {
        byte[] GenerarPdf(
              WebApiFacturacion.Models.Dto.FacturaJson factura,
              System.Xml.XmlDocument xmlFirmado,
              byte[] qrPng,
              string cdrResponse
          );
    }
}