﻿using System.Xml;
using WebApiFacturacion.Models.Dto;

public interface IPdfGenerator
{
    byte[] GenerarPdf(FacturaJson factura, XmlDocument xmlFirmado, byte[] qrPng, string respuestaSunat);
}