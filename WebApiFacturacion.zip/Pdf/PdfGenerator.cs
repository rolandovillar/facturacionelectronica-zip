﻿using System.IO;
using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf;
using System.Xml;
using WebApiFacturacion.Models;
using WebApiFacturacion.Models.Dto;

namespace WebApiFacturacion.Pdf
{
    public class PdfGenerator : IPdfGenerator
    {
        public byte[] GenerarPdf(
        FacturaJson factura,
        XmlDocument xmlFirmado,
        byte[] qrPng,
        string cdrResponse
    )
        {
            using var document = new PdfDocument();
            var page = document.AddPage();
            var gfx = XGraphics.FromPdfPage(page);
            var font = new XFont("Arial", 12);

            // 1) Cabecera
            gfx.DrawString(
                $"Factura {factura.venta.serie}-{factura.venta.numero}",
                font, XBrushes.Black,
                new XRect(40, 40, page.Width, 20),
                XStringFormats.TopLeft
            );

            // 2) QR
            var img = XImage.FromStream(() => new MemoryStream(qrPng));
            gfx.DrawImage(img, 40, 80, 100, 100);

            // 3) CDR
            gfx.DrawString(
                "Respuesta SUNAT (CDR):",
                font, XBrushes.Black,
                new XRect(40, 200, page.Width - 80, 20),
                XStringFormats.TopLeft
            );
            gfx.DrawString(
                cdrResponse,
                font, XBrushes.Black,
                new XRect(40, 220, page.Width - 80, page.Height - 240),
                XStringFormats.TopLeft
            );

            // 4) Guardar
            using var outStream = new MemoryStream();
            document.Save(outStream, false);
            return outStream.ToArray();
        }
    }
}