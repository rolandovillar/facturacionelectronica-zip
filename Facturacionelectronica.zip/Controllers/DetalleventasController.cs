﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class DetalleventasController : Controller
    {
        Contexto ctx;
        public DetalleventasController(Contexto _ctx)
        {
            ctx = _ctx;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        public async Task<IActionResult> Index()
        {

            int Idempresa = ObtenerIdEmpresa();

            var detalles = await ctx.Facturadetalles
            .Include(d => d.Facturacabe)             // Incluimos la cabecera
            .Where(d => d.IdEmpresas == Idempresa)
            .Select(d => new Facturadetalle
            {
                Id = d.Id,
                TipDoc = d.Facturacabe.TipDoc,
                NroFac = d.NroFac,
                Descprod = d.Descprod,
                Serie = d.Serie,
                Marca = d.Marca,
                Modelo = d.Modelo,
                CanProd = d.CanProd,
                Punitprod = d.Punitprod,
                Total = d.Total,
                // Si NomCli está vacío, lo tomamos de la cabecera
                NomCli = string.IsNullOrWhiteSpace(d.NomCli)
                                      ? d.Facturacabe!.NomCli
                                      : d.NomCli,
                Fecha = d.Fecha,
                IdEmpresas = d.IdEmpresas
            })
            .ToListAsync();

            return View(detalles);
        }
    }
}
