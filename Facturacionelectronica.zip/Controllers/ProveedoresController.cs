﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class ProveedoresController : Controller
    {
        private readonly Contexto _context;

        public ProveedoresController(Contexto context)
        {
            _context = context;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        // GET: ProveedoresController
        public ActionResult Index()
        {
            int Idempresa = ObtenerIdEmpresa();

            var proveedores = _context.Proveedors.Where(c => c.Activo == 1 && c.IdEmpresas == Idempresa).ToList();

            return View(proveedores);
        }

        // GET: ProveedoresController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ProveedoresController/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public JsonResult Create(Proveedor proveedor)
        {
            int Idempresa = ObtenerIdEmpresa();

            try
            {
                // Verificar si el nombre o el RUC/DNI ya están en uso
                var proveedorExistente = _context.Proveedors.Where(x=> x.IdEmpresas == Idempresa)
                    .FirstOrDefault(c => c.Nombreproveedor == proveedor.Nombreproveedor || c.Rucdni == proveedor.Rucdni);

                if (proveedorExistente != null)
                {
                    // Generar un mensaje de error dependiendo del campo que coincide
                    string mensajeError = proveedorExistente.Nombreproveedor == proveedor.Nombreproveedor
                        ? "El nombre del proveedor existe en Base de Datos .... Correjir."
                        : "El Documento del proveedor existe en base de datos...... Correjir.";

                    return Json(new { success = false, mensaje = mensajeError });
                }

                // Guardar el proveedor en la base de datos
                proveedor.Activo = 1;
                proveedor.IdEmpresas = Idempresa;

                _context.Add(proveedor);
                _context.SaveChanges();

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Capturar errores generales
                return Json(new { success = false, mensaje = "Ocurrió un error al guardar el proveedor: " + ex.Message });
            }
        }

        // GET: ProveedoresController/Edit/5
        public ActionResult Edit(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var prov = _context.Proveedors.Where(p => p.Id == id && p.IdEmpresas == Idempresa).FirstOrDefault();
            return View(prov);
        }

        [HttpPost]
        public JsonResult Edit(Proveedor proveedor)
        {
            int Idempresa = ObtenerIdEmpresa();
            try
            {
                // Verificar si el nombre o el RUC/DNI ya están en uso por otro proveedor
                var proveedorExistente = _context.Proveedors
                    .FirstOrDefault(c => c.Id != proveedor.Id && c.IdEmpresas == Idempresa &&
                                         (c.Nombreproveedor == proveedor.Nombreproveedor || c.Rucdni == proveedor.Rucdni));

                if (proveedorExistente != null)
                {
                    string mensajeError = proveedorExistente.Nombreproveedor == proveedor.Nombreproveedor
                        ? "El nombre del proveedor ya está en uso."
                        : "El RUC/DNI del proveedor ya está en uso.";

                    return Json(new { success = false, mensaje = mensajeError });
                }

                // Actualizar el proveedor en la base de datos
                var proveedorDb = _context.Proveedors.Find(proveedor.Id);
                if (proveedorDb == null)
                {
                    return Json(new { success = false, mensaje = "Proveedor no encontrado." });
                }

                proveedorDb.Nombreproveedor = proveedor.Nombreproveedor;
                proveedorDb.Rucdni = proveedor.Rucdni;
                proveedorDb.Direccion = proveedor.Direccion;
                proveedorDb.Telefono = proveedor.Telefono;
                proveedorDb.Correo = proveedor.Correo;
                proveedorDb.IdEmpresas = Idempresa;

                _context.SaveChanges();

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, mensaje = "Ocurrió un error al actualizar el proveedor: " + ex.Message });
            }
        }
        // GET: ProveedoresController/Delete/5
        public ActionResult Delete(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var prod = _context.Proveedors.Where(p => p.Id == id && p.IdEmpresas == Idempresa).FirstOrDefault();
            return View(prod);
        }

        // POST: ProveedoresController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            int Idempresa = ObtenerIdEmpresa();
            try
            {
                var prod = _context.Proveedors.Where(p => p.Id == id && p.IdEmpresas == Idempresa).FirstOrDefault();
                prod.Activo = 0;
                prod.IdEmpresas = Idempresa;
                _context.Update(prod);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
