﻿using Facturacionelectronica.Models;
using Facturacionelectronica.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Rotativa.AspNetCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class ComprasController : Controller
    {
        private readonly Contexto _context;
        private int _idempresa;  // <-- propiedad que guardarás
        static int Envio3;
        public int reg = 0;

        public ComprasController(Contexto context)
        {

            _context = context;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            // Guardar el ID de empresa del usuario logueado
            _idempresa = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        public IActionResult Index()
        {
            int Idempresa = ObtenerIdEmpresa();

            return View();
        }

        // GET: PruebaItem/Create
        public IActionResult Create()
        {
            int Idempresa = ObtenerIdEmpresa();

            var proveed = _context.Proveedors
                .Where(p => p.IdEmpresas == Idempresa)
              .OrderBy(n => n.Nombreproveedor)
              .Select(p => new
              {
                  idproveedor = p.Id,
                  nombreproveedor = p.Nombreproveedor,
                  direccion = p.Direccion,
                  rucdni = p.Rucdni,
                  telefono = p.Telefono,
              }).ToList();

            ViewBag.Proveedores = proveed;

            var pro = _context.Productos
                 .Where(p => p.IdEmpresas == Idempresa)
                .Include(m => m.MarcaNavigation)
                .Include(p => p.CategoriumNavegation) // Incluir la propiedad de navegación de Categorium
                .Select(p => new
                {
                    Id = p.Id,
                    Descripcion = p.Descripcion,
                    Referencia = p.Referencia,
                    Serie = p.Serie,
                    Categoria = p.CategoriumNavegation.Nombrecategoria,
                    Preciocosto = p.Preciocosto,
                    Precioventa = p.Precioventa,
                    Stock = p.Stock,
                    Marca = p.MarcaNavigation.Nombremarca,
                    Modelo = p.Modelo,
                    Proveedor = p.ProveedorNavigation.Nombreproveedor,
                }).ToList();

            ViewBag.Productos = pro;



            return View();
        }

        [HttpPost]
        public JsonResult Create([FromForm] Comprascabe compras)
        {
            int Idempresa = ObtenerIdEmpresa();

            try
            {
                compras.IdEmpresas = Idempresa;

                // Guardar en la base de datos
                _context.Add(compras);
                _context.SaveChanges();

                // Regresar el id o el número de registro de la compra
                var numeroregistro = compras.Id;  // Asumiendo que 'Id' es el identificador

                return Json(numeroregistro); // Retorna el Id o cualquier otra información útil
            }
            catch (Exception ex)
            {
                // En caso de error, retorna un mensaje adecuado
                return Json("error: " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult ActualizaProductos([FromBody] List<Comprasdetalle> detalles)
        {
            int Idempresa = ObtenerIdEmpresa();

            if (detalles == null || !detalles.Any())
            {
                return BadRequest("No se recibieron detalles.");
            }

            foreach (var detalle in detalles)
            {
                // Verificamos que el detalle tenga un IdProducto válido
                if (detalle.IdProducto == null || detalle.Cantidad == null || detalle.Precio == null)
                {
                    return BadRequest("Faltan datos en los detalles.");
                }

                // Buscar el producto por Id
                var producto = _context.Productos.FirstOrDefault(p => p.Id == detalle.IdProducto && p.IdEmpresas == Idempresa);

                if (producto != null)
                {
                    // Actualizar stock y precio de costo
                    producto.Stock += detalle.Cantidad ?? 0;
                    producto.Preciocosto = detalle.Precio ?? producto.Preciocosto;
                    producto.Igic = detalle.PorcentajeIgic ?? 0;

                    _context.Productos.Update(producto);
                }

                // Crear una nueva instancia de Comprasdetalle y asignar los valores
                var nuevoDetalle = new Comprasdetalle
                {
                    Documento = detalle.Documento,
                    NumeroFactura = detalle.NumeroFactura,
                    Fecha = DateTime.Now,  // O la fecha que necesites
                    IdProducto = detalle.IdProducto,
                    Descproducto = detalle.Descproducto,
                    Referencia = detalle.Referencia,
                    Marca = detalle.Marca,
                    Serie = detalle.Serie,
                    Modelo = detalle.Modelo,
                    Cantidad = detalle.Cantidad,
                    Precio = detalle.Precio,
                    Importe = detalle.Importe,  // Calcula el importe si es necesario
                    NomProv = detalle.NomProv,
                    Porcentajedescuento = detalle.Porcentajedescuento,
                    Canon = detalle.Canon,
                    Situacion = "Activo",  // Agrega la lógica para la situación
                    PorcentajeIgic = detalle.PorcentajeIgic,
                    ComprascabeId = detalle.ComprascabeId  // Asegúrate de usar el ID de la cabecera
                };

                nuevoDetalle.IdEmpresas = Idempresa;
                _context.Comprasdetalles.Add(nuevoDetalle);
                _context.SaveChanges();

                // Buscar el producto
                var productoinventario = _context.Productos.Where(p => p.Id == detalle.IdProducto && p.IdEmpresas == Idempresa).FirstOrDefault();


                if (productoinventario != null)
                {
                    // Aquí imprimimos los valores que vamos a grabar en el Inventario
                    Console.WriteLine($"Creando inventario para el producto: {detalle.IdProducto}");
                    Console.WriteLine($"Cantidadcompras: {(decimal)(detalle.Cantidad ?? 0)}");
                    Console.WriteLine($"Stock: {(decimal)productoinventario.Stock}");
                    Console.WriteLine($"Fecha: {DateTime.Now}");
                    Console.WriteLine($"Documento: {detalle.Documento}");
                    Console.WriteLine($"Nrodocumento: {detalle.NumeroFactura}");
                    Console.WriteLine($"Marca: {detalle.Marca}");
                    Console.WriteLine($"IdEmpresas: {Idempresa}");
                    Console.WriteLine($"ComprasdetalleId: {detalle.Id}");

                    // Crear la nueva instancia de Inventario
                    var nuevoinventario = new Inventario
                    {
                        Idproducto = detalle.IdProducto,
                        Descproducto = detalle.Descproducto,
                        Cantidadcompras = (decimal)(detalle.Cantidad ?? 0),
                        Cantidadventas = 0,
                        Stock = (decimal)productoinventario.Stock,  // Convertimos Stock a decimal
                        Fecha = DateTime.Now,           // O la fecha que necesites
                        Documento = detalle.Documento,
                        Nrodocumento = detalle.NumeroFactura,
                        Marca = detalle.Marca,
                        IdEmpresas = Idempresa,
                        ComprasdetalleId = detalle.Id,
                    };

                    // Agregar el nuevo inventario
                    _context.Inventarios.Add(nuevoinventario);
                }
                else
                {
                    // Si no encontramos el producto en inventario, devolvemos un mensaje de error
                    return BadRequest("Producto no encontrado en inventario.");
                }

            }

            _context.SaveChanges();

            return Json(1);  // Devuelve éxito
        }


        public JsonResult Pasarclientes(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var prov = _context.Proveedors.Where(p => p.Id == id && p.IdEmpresas == Idempresa).Select(
                  p => new
                  {
                      idproveedor = p.Id,
                      nombre = p.Nombreproveedor,
                      direccion = p.Direccion,
                      telefono = p.Telefono,
                      Rucdni = p.Rucdni
                  }
                  ).First();
            return Json(prov);
        }

        public JsonResult Pasarproducto(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var pro = _context.Productos.Include(p => p.MarcaNavigation).Where(p => p.Id == id && p.IdEmpresas == Idempresa).Select(
                    p => new
                    {
                        idproducto = p.Id,
                        descripcion = p.Descripcion,
                        preciocosto = p.Preciocosto,
                        serie = p.Serie,
                        marca = p.MarcaNavigation.Nombremarca,
                        modelo = p.Modelo,
                        categoria = p.CategoriumNavegation.Nombrecategoria,
                        referencia = p.Referencia,
                        proveedor = p.ProveedorId
                    }
                    ).First();

            return Json(pro);
        }


        public JsonResult LlenarcboTipodocumento(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var bd = _context.Tipodocumentocompras.Where(x => x.Id > id && x.IdEmpresas == Idempresa).ToList();
            var lista = bd.ToList();
            return Json(bd);
        }

        public JsonResult recuperarNrodocumento(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var lista = _context.Tipodocumentos.Where(x => x.Id > 7 && x.IdEmpresas == Idempresa).ToList();
            return Json(lista);

        }
        public JsonResult ActualizaIdDetalle()
        {
            int Idempresa = ObtenerIdEmpresa();

            var registro = _context.Comprascabes.Where(r => r.Id == Envio3 && r.IdEmpresas == Idempresa).First();

            var detalle = _context.Comprasdetalles.Where(d => d.IdVenta == Envio3 && d.IdEmpresas == Idempresa).ToList();
            //        
            foreach (var reg1 in detalle)
            {
                //    reg1.IdVenta = reg;
                //    _context.Inventario2.Update(reg1);
                //    _context.SaveChanges();
            }

            return Json(detalle);
        }

        public IActionResult SeleccionarProducto(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var producto = _context.Productos
                .Where(p => p.Id == id && p.IdEmpresas == Idempresa)
                .Select(p => new
                {
                    id = p.Id,
                    descripcion = p.Descripcion,
                    preciocosto = p.Preciocosto,
                    serie = p.Serie,
                    marca = p.MarcaNavigation.Nombremarca,
                    modelo = p.Modelo,
                    categoria = p.CategoriumNavegation.Nombrecategoria,
                    referencia = p.Referencia,
                    proveedor = p.ProveedorNavigation.Nombreproveedor,
                }).FirstOrDefault();

            return Json(producto);
        }

        public IActionResult CrearPdf()
        {
            int Idempresa = ObtenerIdEmpresa();

            ViewModelComprascabe modelo = _context.Comprascabes.Include(dv => dv.comprasdetalles).Where(v => v.Id == Envio3 && v.IdEmpresas == Idempresa).
                Select(v => new ViewModelComprascabe()
                {
                    TipoDoc = v.TipoDoc,
                    NroDoc = v.NroDoc,
                    CodProv = v.CodProv,
                    Fecha = v.Fecha,
                    NomProv = v.NomProv,
                    Ruc = v.Ruc,
                    SubTotal = v.SubTotal,
                    Igv = v.Impuesto,
                    Total = v.Total,
                    TipoCompra = v.TipoCompra,
                    Situacion = v.Situacion,


                    ComprasDetalles = v.comprasdetalles.Select(dv => new ViewModelComprasDetalle()
                    {
                        IdProducto = dv.IdProducto,
                        Serie = dv.Serie,
                        Referencia = dv.Referencia,
                        Marca = dv.Marca,
                        Modelo = dv.Modelo,
                        Descproducto = dv.Descproducto,
                        Cantidad = dv.Cantidad,
                        Precio = dv.Precio,
                        Importe = dv.Importe,
                    }).ToList()
                }).FirstOrDefault();

            return new ViewAsPdf("CrearPdf", modelo)
            {
                PageSize = Rotativa.AspNetCore.Options.Size.A4,
                PageOrientation = Rotativa.AspNetCore.Options.Orientation.Portrait,
                //             PageMargins = new Rotativa.AspNetCore.Options.Margins(10, 10, 10, 10),
                FileName = $"Venta{modelo.NroDoc}.pdf", // SI QUEREMOS QUE EL ARCHIVO SE DESCARGUE DIRECTAMENTE
            };
        }
    }
}
