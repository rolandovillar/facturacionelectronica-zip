﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class ProductosController : Controller
    {
        private readonly Contexto _context;
        private int _idempresa;  // <-- propiedad que guardarás

        public ProductosController(Contexto context)
        {
            _context = context;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            // Guardar el ID de empresa del usuario logueado
            _idempresa = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }
        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        // GET: ProductosController
        public IActionResult Index()
        {
            int Idempresa = ObtenerIdEmpresa();

          var productos = _context.Productos
          .Where(x => x.IdEmpresas == Idempresa && x.Activo == 1)
         .Include(p => p.MarcaNavigation)  // Incluir la entidad Marca relacionada
         .Include(p => p.CategoriumNavegation)  // Incluir la entidad Categoría relacionada
         .Include(p => p.ProveedorNavigation)  // Incluir la entidad Proveedores relacionada                  // Filtrar solo los registros donde Activo == 1
         .OrderBy(n => n.Descripcion)
         .ToList();
            return View(productos);
        }

        public ActionResult Create()
        {
            int Idempresa = ObtenerIdEmpresa();
            // Obtener lista de marcas
            var marcas = _context.Marcas
                .Where(x =>  x.IdEmpresas == Idempresa)
                .OrderBy(x => x.Nombremarca).ToList();

            // Obtener lista de categorías
            var categorias = _context.Categoria
                .Where(x => x.IdEmpresas == Idempresa)
                .OrderBy(x => x.Nombrecategoria ?? string.Empty).ToList();
            if (categorias == null)
            {
                // Manejar el caso en que las categorías no se carguen correctamente
                // Por ejemplo, puedes registrar un mensaje de error o redirigir a una página de error
                return RedirectToAction("Error");
            }
            // Obtener lista de proveedores
            var proveedores = _context.Proveedors.Where(x => x.IdEmpresas == Idempresa).OrderBy(x => x.Nombreproveedor).ToList();

            // Pasar las listas a la vista
            ViewBag.Marcas = new SelectList(marcas, "Id", "Nombremarca");
            ViewBag.Categorias = new SelectList(categorias, "Id", "Nombrecategoria");
            ViewBag.Proveedores = new SelectList(proveedores, "Id", "Nombreproveedor");

            return View();
        }

        // POST: ProductosController/Create
        [HttpPost]
        public JsonResult Create([FromForm] Producto producto)
        {
            int Idempresa = ObtenerIdEmpresa();

            producto.IdEmpresas = Idempresa;

            var reg = 0;

            // producto.ProveedorId = int.Parse(producto.ProveedorId);
            producto.Activo = 1;
            _context.Add(producto);
            _context.SaveChanges();

            reg = 1;
            return Json(reg);

        }
        // GET: ProductosController/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return BadRequest(); // o RedirectToAction("Index");
            }

            int Idempresa = ObtenerIdEmpresa();

            var producto = _context.Productos
              .Where(x => x.Id == id && x.IdEmpresas == Idempresa)
              .Include(p => p.MarcaNavigation)
              .Include(p => p.CategoriumNavegation)
              .Include(p => p.ProveedorNavigation)
              .FirstOrDefault();

            if (producto == null)
            {
                return NotFound();
            }

            // Cargar opciones para el select de Marca
            var marcas = _context.Marcas.Where(x => x.IdEmpresas == Idempresa).OrderBy(x => x.Nombremarca)
                .Select(m => new SelectListItem
                {
                    Value = m.Id.ToString(),
                    Text = m.Nombremarca
                })
                .ToList();

            // Cargar opciones para el select de Categoría
            var categorias = _context.Categoria.Where(x => x.IdEmpresas == Idempresa).OrderBy(x => x.Nombrecategoria)
                .Select(c => new SelectListItem
                {
                    Value = c.Id.ToString(),
                    Text = c.Nombrecategoria
                })
                .ToList();

            var proveedores = _context.Proveedors.Where(x => x.IdEmpresas == Idempresa).OrderBy(x => x.Nombreproveedor)
                .Select(c => new SelectListItem
                {
                    Value = c.Id.ToString(),
                    Text = c.Nombreproveedor
                })
                .ToList();

            ViewBag.Marcas = marcas;
            ViewBag.Categorias = categorias;
            ViewBag.Proveedores = proveedores;

            return View(producto);
        }

        // POST: ProductosController/Edit/
        [HttpPost]

        public IActionResult Edit(Producto producto)
        {
            int Idempresa = ObtenerIdEmpresa();

            producto.IdEmpresas = Idempresa;
            var reg = 0;
            producto.Activo = 1;
            _context.Update(producto);
            _context.SaveChanges();

            reg = 1;
            //  return Json(reg);
            return RedirectToAction(nameof(Index));
        }

        // GET: ProductosController/Delete/5
        public ActionResult Delete(int id)
        {
            int Idempresa = ObtenerIdEmpresa();

            var prod = _context.Productos.Where(x => x.Id == id && x.IdEmpresas == Idempresa).FirstOrDefault();

            // Cargar opciones para el select de Marca
            var marcas = _context.Marcas
                .Where(x => x.IdEmpresas == Idempresa)
                .Select(m => new SelectListItem
                {
                    Value = m.Id.ToString(),
                    Text = m.Nombremarca
                })
                .ToList();

            // Cargar opciones para el select de Categoría
            var categorias = _context.Categoria
                .Where(x => x.IdEmpresas == Idempresa)
                .Select(c => new SelectListItem
                {
                    Value = c.Id.ToString(),
                    Text = c.Nombrecategoria
                })
                .ToList();

            var proveedores = _context.Proveedors
                .Where(x => x.IdEmpresas == Idempresa)
                .Select(c => new SelectListItem
                {
                    Value = c.Id.ToString(),
                    Text = c.Nombreproveedor
                })
                .ToList();

            ViewBag.Marcas = marcas;
            ViewBag.Categorias = categorias;
            ViewBag.Proveedores = proveedores;

            return View(prod);
        }

        // POST: ProductosController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            int Idempresa = ObtenerIdEmpresa();

            try
            {
                var prod = _context.Productos.Where(p => p.Id == id && p.IdEmpresas == Idempresa).FirstOrDefault();
                prod.Activo = 0;
                _context.Update(prod);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

    }
}
