﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Facturacionelectronica.Models.ViewModels;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Xml.Linq;
using Facturacionelectronica.Models;
using Facturacionelectronica.Models.ViewModelsJson;
using System.Text;
using System.Security.Claims;

namespace SistemaWebOncovip.Controllers
{
    public class GeneraJsonController : Controller
    {
        private readonly Contexto _context;
        private readonly IWebHostEnvironment _hostingEnvironment;
        static int Envio3;
        public GeneraJsonController(Contexto context)
        {
            _context = context;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> GeneraJson(int Envio3)
        {
            int Idempresa = ObtenerIdEmpresa();

            string horaActual = DateTime.Now.ToString("HH:mm:ss");
            // obtengo cabecera de factura
            Facturacabe facturacabe = _context.Facturacabes.Where(f => f.Id == Envio3 && f.IdEmpresas == Idempresa).First();
            // Extrayendo datos de la empresa
            var empresa1 = _context.Empresas.Where(e => e.Id == Idempresa).First();

            // Obtener los detalles de la factura desde la base de datos
            var listadetalles = _context.Facturadetalles.Where(d => d.Facturacabeid == Envio3 && d.IdEmpresas == Idempresa).ToList();

            string fechad = facturacabe.Fecha.Value.ToString("yyyy-MM-dd");

            var httpClient = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "http://rolandovillar-001-site9.atempurl.com/post.php");

            // Crear instancias de las clases y asignar valores
            var facturaJson = new FacturaJson
            {    
                empresa = new Facturacionelectronica.Models.ViewModelsJson.Empresa
                {
                    ruc = empresa1.RucDni,
                    razon_social = empresa1.NomEmpresa,
                    nombre_comercial = empresa1.NomEmpresa,
                    domicilio_fiscal = empresa1.Distritoemisor,
                    ubigeo = empresa1.CodigoUbigeoemisor,
                    urbanizacion = "-",
                    distrito = empresa1.Distritoemisor,
                    provincia = empresa1.Provinciaemisor,
                    departamento = empresa1.Departamentoemisor,
                    //   modo = empresa1.ConectarSunat,
                    modo = empresa1.ConectarSunat,
                    usu_secundario_produccion_user = empresa1.UserSecundario,
                    usu_secundario_produccion_password = empresa1.PassSecundario
                },
                 cliente = new Facturacionelectronica.Models.ViewModelsJson.Cliente
                {
                    razon_social_nombres = facturacabe.NomCli,
                    numero_documento = facturacabe.Ruc,
                    codigo_tipo_entidad = facturacabe.Tipodocumentocliente,
                    cliente_direccion = facturacabe.DireCli
                },
                venta = new VentaJson
                {
                    serie = facturacabe.LetrayserieSunat,
                    numero = facturacabe.NroDocumento.ToString(),
                    fecha_emision = fechad,
                    hora_emision = horaActual,
                    fecha_vencimiento = "",
                    moneda_id = "1",
                    forma_pago_id = "1",
                    total_gravada = facturacabe.SubTot.ToString(),
                    total_igv = facturacabe.Impuesto.ToString(),
                    total_exonerada = "",
                    total_inafecta = "",
                    tipo_documento_codigo = facturacabe.Tipodocumentosunat,
                    nota = "notas o comentarios"
                },

                items = listadetalles.Select(detalle => new Item
                {
                    producto = detalle.Descprod.ToString(),
                    cantidad = detalle.CanProd.ToString(),
                    precio_base = detalle.Precsinigvsunat.ToString(),
                    codigo_sunat = "-",
                    codigo_producto = (int)detalle.CodProd,
                    codigo_unidad = "NIU",
                    tipo_igv_codigo = "10"
                }).ToList()
            };

            // Serializar la instancia de FacturaJson a JSON
            var jsonString = JsonConvert.SerializeObject(facturaJson);
            //  request.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            // Adjuntar la cadena JSON serializada al cuerpo de la solicitud
            request.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");

            var response = await httpClient.SendAsync(request);
            var responsemensaje = response.RequestMessage;
            var responsecod = response.EnsureSuccessStatusCode();

            if (response.IsSuccessStatusCode)
            {

                // Prepara nombres de archivos
                string filexml = empresa1.RucDni + "-" + facturacabe.Tipodocumentosunat + "-" + facturacabe.NroFac + ".xml";
                string filepdf = empresa1.RucDni + "-" + facturacabe.Tipodocumentosunat + "-" + facturacabe.NroFac + ".pdf";
                string fileqr = facturacabe.Tipodocumentosunat + "-" + facturacabe.NroFac + ".png";
                string filecdr = "R-" + empresa1.RucDni + "-" + facturacabe.Tipodocumentosunat + "-" + facturacabe.NroFac + ".xml";

                // URL de los archivos proporcionados por el JSON
                string xmlUrl = "http://rolandovillar-001-site9.atempurl.com/files/facturacion_electronica/FIRMA/" + filexml;
                string pdfUrl = "http://rolandovillar-001-site9.atempurl.com/files/facturacion_electronica/PDF/" + filepdf;
                string cdrUrl = "http://rolandovillar-001-site9.atempurl.com/files/facturacion_electronica/CDR/" + filecdr;
                string qrUrl = "http://rolandovillar-001-site9.atempurl.com/files/facturacion_electronica/QR/" + fileqr;
                // Carpeta donde se guardarán los archivos
                string folderPathCdr = @"C:\DocumentosSrCautivo\RespuestaCDR";
                string folderPathXml = @"C:\DocumentosSrCautivo\RespuestaXML";
                string folderPathPdf = @"C:\DocumentosSrCautivo\RespuestaPDF";
                string folderPathQr = @"C:\DocumentosSrCautivo\RespuestaQR";

                // Llama a la función para descargar y guardar los archivos
                await DownloadAndSaveFile(cdrUrl, folderPathCdr, filecdr);
                await DownloadAndSaveFile(xmlUrl, folderPathXml, filexml);
                await DownloadAndSaveFile(pdfUrl, folderPathPdf, filepdf);
                await DownloadAndSaveFile(qrUrl, folderPathQr, fileqr);

                Console.WriteLine("Archivos descargados y guardados exitosamente.");
                return Json(response);
            }
            return Json(response);
        }
        // descarga de archivos generados CDR XML PDF QR 
        static async Task DownloadAndSaveFile(string fileUrl, string folderPath, string fileName)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(fileUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        byte[] fileBytes = await response.Content.ReadAsByteArrayAsync();
                        string filePath = Path.Combine(folderPath, fileName);
                        System.IO.File.WriteAllBytes(filePath, fileBytes);
                        Console.WriteLine($"Archivo guardado correctamente: {filePath}");
                    }
                    else
                    {
                        Console.WriteLine($"Error al descargar el archivo: {response.StatusCode}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al descargar y guardar el archivo: {ex.Message}");
            }
        }
        3
    }
}