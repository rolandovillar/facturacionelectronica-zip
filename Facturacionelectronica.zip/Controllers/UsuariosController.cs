﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Security.Cryptography;

namespace Facturacionelectronica.Controllers
{
    public class UsuariosController : Controller
    {

        private readonly Contexto _context;
        private int _idempresa;  // <-- propiedad que guardarás

        public UsuariosController(Contexto context)
        {
            _context = context;

        }

        // Se ejecuta antes de cualquier acción
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            // Guardar el ID de empresa del usuario logueado
            _idempresa = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }
        public async Task<IActionResult> Index()
        {

            return View(await _context.Usuarios
            .Where(c => c.IdEmpresas == _idempresa)
            .OrderBy(c => c.Nombre)
            .ToListAsync());
        }

        // GET: UsuariosController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UsuariosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Usuario usuario)
        {
            try
            {
                usuario.IdEmpresas = _idempresa;

                // Verificar si el correo ya está registrado en la misma empresa
                bool correoExistente = await _context.Usuarios
                    .AnyAsync(u => u.Correo == usuario.Correo && u.IdEmpresas == _idempresa);

                if (correoExistente)
                {
                    ModelState.AddModelError("Correo", "Este correo ya está registrado en esta empresa.");
                    return View(usuario);
                }

                // Cifrar la contraseña
                usuario.Claves = CifrarContraseña(usuario.Claves);

                _context.Add(usuario);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(usuario);
            }
        }
        private string CifrarContraseña(string contraseña)
        {
            byte[] sal = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(sal);
            }

            string hash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: contraseña,
                salt: sal,
                prf: KeyDerivationPrf.HMACSHA512,
                iterationCount: 100_000,
                numBytesRequested: 256 / 8));

            return $"{Convert.ToBase64String(sal)}${hash}";
        }

        // GET: UsuariosController/Edit/5
        public ActionResult Edit(int id)
        {
            var usuario = _context.Usuarios.Where(f => f.Idusuario == id && f.IdEmpresas == _idempresa).FirstOrDefault();


            return View(usuario);
        }

        // POST: UsuariosController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Usuario usuario)
        {
            var usuariox = _context.Usuarios
                .FirstOrDefault(f => f.Idusuario == id && f.IdEmpresas == _idempresa);

            if (usuariox == null) return NotFound();

            try
            {
                usuariox.Nombre = usuario.Nombre;
                usuariox.Correo = usuario.Correo;
                usuariox.Roles = usuario.Roles;

                // Solo actualiza la clave si se modificó (puedes mejorar esta lógica si quieres verificar que venga cifrada)
                if (!string.IsNullOrWhiteSpace(usuario.Claves))
                {
                    usuariox.Claves = CifrarContraseña(usuario.Claves);
                }

                _context.Update(usuariox);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(usuario);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var usuario = await _context.Usuarios.Where(f => f.Idusuario == id && f.IdEmpresas == _idempresa).FirstOrDefaultAsync();

            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario); // Si tienes una vista para confirmación
        }

        // POST: Usuarios/Delete/5
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var usuario = await _context.Usuarios.Where(f => f.Idusuario == id && f.IdEmpresas == _idempresa).FirstOrDefaultAsync();
            if (usuario != null)
            {
                _context.Usuarios.Remove(usuario);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
