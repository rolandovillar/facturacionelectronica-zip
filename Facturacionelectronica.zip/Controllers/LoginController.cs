﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Myvas.AspNetCore.Email;
using Facturacionelectronica.Models.ViewModels;
using System.Security.Claims;
using System.Security.Cryptography;

namespace Facturacionelectronica.Controllers
{
    public class LoginController : Controller
    {
        private readonly Contexto _context;
        private readonly UserManager<Usuario> _userManager;
        private readonly SignInManager<Usuario> _signInManager; // Agregado SignInManager
        private readonly IEmailSender _emailSender;
        private readonly UserSession _userSession;

        public LoginController(IEmailSender emailSender, Contexto context, UserSession userSession)
        {
            _emailSender = emailSender;
            _context = context;
            _userSession = userSession;
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> ValidarUsario(string correo, string password)
        {
            // Buscar el usuario por correo
            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.Correo == correo);

            if (usuario != null && VerificarContraseña(password, usuario.Claves))
            {
                // Crear los claims de autenticación
                var claims = new List<Claim>
        {
                   new Claim(ClaimTypes.Name, usuario.Nombre ?? string.Empty),
                   new Claim("Correo", usuario.Correo ?? string.Empty),
                   new Claim(ClaimTypes.Role, usuario.Roles ?? "USUARIO"),
                   new Claim(ClaimTypes.NameIdentifier, usuario.IdEmpresas.ToString()) // Aquí ponemos el IdEmpresa
        };

                // Crear la identidad con los claims
                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var principal = new ClaimsPrincipal(identity);

                // Iniciar sesión
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                return RedirectToAction("Index", "Home");
            }

            // Si las credenciales son incorrectas
            ModelState.AddModelError(string.Empty, "Usuario o contraseña incorrectos.");
            return View("Index");
        }

        // Método para verificar contraseña:

        [AllowAnonymous]
        public static bool VerificarContraseña(string contraseñaIngresada, string contraseñaCifrada)
        {
            var partes = contraseñaCifrada.Split('$');
            if (partes.Length != 2) return false;

            var salt = Convert.FromBase64String(partes[0]);
            var hashEsperado = partes[1];

            var hashIngresado = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: contraseñaIngresada,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA512,
                iterationCount: 100_000,
                numBytesRequested: 256 / 8));

            return hashIngresado == hashEsperado;
        }


        // Método para restablecer contraseña
        public IActionResult ForgotPassword() => View();

        [HttpPost]
        public async Task<IActionResult> ForgotPassword(string correo)
        {
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Correo == correo);

            if (usuario == null)
            {
                // Puedes mostrar un mensaje genérico o redirigir
                return RedirectToAction("ForgotPasswordConfirmation");
            }

            // Generar token y fecha de expiración
            var token = Guid.NewGuid();
            usuario.TokenRestitucion = token;
            usuario.FechaRestitucion = DateTime.UtcNow.AddHours(1); // Expira en 1 hora

            _context.Usuarios.Update(usuario);
            await _context.SaveChangesAsync();

            var enlace = Url.Action("ResetPassword", "Login", new { token = token }, Request.Scheme);
            await EnviarCorreoRestablecimiento(correo, enlace);

            return RedirectToAction("ForgotPasswordConfirmation");
        }

        [HttpGet]
        public IActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        private async Task EnviarCorreoRestablecimiento(string correo, string enlace)
        {
            var subject = "Restablecimiento de Contraseña";
            var body = $@"
        <p>Hola,</p>
        <p>Para restablecer su contraseña, haga clic en el siguiente enlace:</p>
        <p><a href='{enlace}'>Restablecer Contraseña</a></p>
        <p>Este enlace expirará en 1 hora.</p>";

            await _emailSender.SendEmailAsync(correo, subject, body);
        }

        // Restablecer la contraseña
        [HttpGet]
        public async Task<IActionResult> ResetPassword(string token)
        {
            if (string.IsNullOrEmpty(token))
                return RedirectToAction("Error");

            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.TokenRestitucion.ToString() == token);

            if (usuario == null || usuario.FechaRestitucion < DateTime.UtcNow)
                return RedirectToAction("Error");

            var model = new ResetPasswordModel
            {
                Email = usuario.Correo,
                Token = token
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> ResetPassword(ResetPasswordModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u =>
                u.Correo == model.Email && u.TokenRestitucion.ToString() == model.Token);

            if (usuario == null || usuario.FechaRestitucion < DateTime.UtcNow)
                return RedirectToAction("Error");

            // Cifrar la nueva contraseña
            usuario.Claves = CifrarContraseña(model.Password);

            // Invalidar token
            usuario.TokenRestitucion = null;
            usuario.FechaRestitucion = null;

            _context.Usuarios.Update(usuario);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        public static string CifrarContraseña(string contraseña)
        {
            byte[] sal = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(sal);
            }

            // Derivar subclave
            string hash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: contraseña,
                salt: sal,
                prf: KeyDerivationPrf.HMACSHA512,
                iterationCount: 100_000,
                numBytesRequested: 256 / 8));

            // Retornar sal y hash combinados
            return $"{Convert.ToBase64String(sal)}${hash}";
        }

        [HttpGet]
        public IActionResult Logout()
        {
            // Lógica para cerrar sesión, por ejemplo:
            // HttpContext.SignOutAsync();
            return RedirectToAction("Login");
        }
    }
}
