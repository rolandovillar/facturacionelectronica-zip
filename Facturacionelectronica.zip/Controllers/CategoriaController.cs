﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class CategoriaController : Controller
    {
        private readonly Contexto _context;

        private int _idempresa;  // <-- propiedad que guardarás

        public CategoriaController(Contexto context)
        {
            _context = context;
        }

        // Se ejecuta antes de cualquier acción
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            // Guardar el ID de empresa del usuario logueado
            _idempresa = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }
        public IActionResult Index()
        {
            var categoria = _context.Categoria
            .Where(c => c.IdEmpresas == _idempresa)
            .OrderBy(c => c.Nombrecategoria)
            .ToList();

            return View(categoria);
        }

        public IActionResult Create()
        {
            return View();
        }

        // POST: Clientes/Create
        [HttpPost]
        public async Task<IActionResult> Create(Categoria categoria)
        {
            bool nombreExistente = await _context.Categoria.AnyAsync(c => c.Nombrecategoria == categoria.Nombrecategoria && c.IdEmpresas == _idempresa);

            if (nombreExistente is true)
            {
                ViewData["ErrorNombre"] = "El nombre ya está en uso.";

                return View(categoria);
                //   ModelState.AddModelError("Nombre", "El nombre ya está en uso.");
            }


            // Validar si hay errores de validación en el modelo
            if (!ModelState.IsValid)
            {
                return View(categoria);
            }

            categoria.IdEmpresas = _idempresa;
            // Si no hay errores de validación, guardar el cliente en la base de datos
            _context.Add(categoria);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: Categoria/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Categoria == null)
            {
                return NotFound();
            }

            var categoria = await _context.Categoria.FindAsync(id);
            if (categoria == null)
            {
                return NotFound();
            }
            return View(categoria);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Categoria categoria)
        {
            if (id != categoria.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    categoria.IdEmpresas = _idempresa;

                    _context.Update(categoria);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CategoriumExists(categoria.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(categoria);
        }

        // GET: Clientes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Categoria == null)
            {
                return NotFound();
            }

            var categoria = await _context.Categoria
                .FirstOrDefaultAsync(m => m.Id == id && m.IdEmpresas == _idempresa && m.IdEmpresas == _idempresa);
            if (categoria == null)
            {
                return NotFound();
            }

            return View(categoria);
        }

        // POST: Clientes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Categoria == null)
            {
                return Problem("Entity set 'Facturaelectronica.Categoria'  is null.");
            }
            var categoria = await _context.Categoria.FindAsync(id);
            if (categoria != null)
            {
                _context.Categoria.Remove(categoria);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CategoriumExists(int id)
        {
            return (_context.Categoria?.Any(e => e.Id == id)).GetValueOrDefault();
        }

    }
}
