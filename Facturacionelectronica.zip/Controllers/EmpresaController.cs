﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class EmpresaController : Controller
    {
        private readonly Contexto _context;

        private int _idempresa;  // <-- propiedad que guardarás

        public EmpresaController(Contexto context)
        {
            _context = context;
        }

        // Se ejecuta antes de cualquier acción
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            // Guardar el ID de empresa del usuario logueado
            _idempresa = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }
        public IActionResult Index()
        {
            var empresa = _context.Empresas
               .Where(p => p.Id == _idempresa)
               .FirstOrDefault();

            // Si no hay registros, devolver un objeto vacío en lugar de null
            if (empresa == null)
            {
                empresa = new Empresa(); // Devuelve un objeto vacío para evitar errores en la vista
            }

            return View(empresa);
        }

        // GET: EmpresaController/Details/5
        public ActionResult Details(int id)
        {

            return View();
        }

        // GET: EmpresaController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmpresaController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmpresaController/Edit/5
        public ActionResult Edit(int? id)
        {
            var empresa = _context.Empresas.Find(id);

            return View(empresa);
        }

        // POST: ProductosController/Edit/
        [HttpPost]

        public IActionResult Edit(Empresa empresa)
        {
            var reg = 0;
            _context.Update(empresa);
            _context.SaveChanges();

            reg = 1;
            //  return Json(reg);
            return RedirectToAction(nameof(Index));
        }

        // GET: EmpresaController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: EmpresaController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
