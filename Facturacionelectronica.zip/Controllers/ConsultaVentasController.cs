﻿using Facturacionelectronica.Models;
using Facturacionelectronica.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rotativa.AspNetCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class ConsultaVentasController : Controller
    {
        Contexto ctx;
        static string inicio;
        static string fin;
        public ConsultaVentasController(Contexto _ctx)
        {
            ctx = _ctx;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        public IActionResult Index()
        {
            int Idempresa = ObtenerIdEmpresa();

            var Ventas = ctx.Facturacabes
                .Where(p => p.IdEmpresas == Idempresa)
                 .OrderBy(d => d.Id)
                 .ToList();

            return View(Ventas);
        }

        [HttpGet]
        public IActionResult VerDetalles(int id)
        {
            int Idempresa = ObtenerIdEmpresa();
            try
            {
                var detalles = ctx.Facturadetalles
                    .Where(d => d.Facturacabeid == id && d.IdEmpresas == Idempresa)
                    .Select(d => new
                    {
                        tipdoc = d.TipDoc,
                        nrofac = d.NroFac,
                        descprod = d.Descprod,
                        serie = d.Serie,
                        marca = d.Marca,
                        modelo = d.Modelo,
                        cantidad = d.CanProd,
                        precio = d.Punitprod,
                        importe = d.Total,
                    })
                    .ToList();

                return Json(detalles);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Error al obtener los detalles de la factura", mensaje = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> FiltrarFactura(DateTime? fechaInicio, DateTime? fechaFin)
        {
            int idEmp = ObtenerIdEmpresa();

            if (!fechaInicio.HasValue || !fechaFin.HasValue)
                return BadRequest("Debe seleccionar ambas fechas.");

            var lista = await ctx.Facturacabes
                .Where(x =>
                    x.Fecha.HasValue &&
                    x.Fecha.Value.Date >= fechaInicio.Value.Date &&
                    x.Fecha.Value.Date <= fechaFin.Value.Date &&
                    x.IdEmpresas == idEmp
                )
                .OrderBy(x => x.Fecha)
                .ToListAsync();

            if (!lista.Any())
                return Content("<p class='text-danger'>No se encontraron registros en este rango de fechas.</p>");

            return PartialView("_TablaCabeceraFactura", lista);
        }

        public IActionResult GenerarPdf(DateTime? fechaInicio, DateTime? fechaFin)
        {
            int Idempresa = ObtenerIdEmpresa();

            inicio = fechaInicio.Value.ToString("dd/MM/yyyy");
            fin = fechaFin.Value.ToString("dd/MM/yyyy");

            var facturas = ctx.Facturacabes
                .Where(d => d.Fecha >= fechaInicio.Value && d.Fecha <= fechaFin.Value && d.IdEmpresas == Idempresa)
                .OrderBy(d => d.Fecha)
                .ToList();

            var modelo = new VentafacturasFechasViewModel
            {
                RangoFechas = $"DESDE {inicio} HASTA EL {fin}",
                Facturas = facturas
            };

            return new ViewAsPdf("GenerarPdf", modelo)
            {
                FileName = $"Reporte_{fechaInicio.Value.ToString("yyyyMMdd")}_a_{fechaFin.Value.ToString("yyyyMMdd")}.pdf",
                PageSize = Rotativa.AspNetCore.Options.Size.A4,
            };
        }

        public IActionResult ImprimirTicket(int id)
        {

            int Idempresa = ObtenerIdEmpresa();
            var empresa = ctx.Empresas.First(e => e.Id == Idempresa);

            // Obtener el logo y su tipo MIME
            var logoData = ctx.Imagens
                .Where(i => i.IdEmpresa == Idempresa)
                .Select(i => new { i.Imagen1, i.MimeType })
                .FirstOrDefault();

            string imageDataUrl = "";

            if (logoData?.Imagen1 != null && !string.IsNullOrEmpty(logoData.MimeType))
            {
                var base64 = Convert.ToBase64String(logoData.Imagen1);
                imageDataUrl = $"data:{logoData.MimeType};base64,{base64}";
            }

            ViewModelFacturaCabecs modelo = ctx.Facturacabes.Include(dv => dv.Facturadetalles).Where(v => v.Id == id && v.IdEmpresas == Idempresa).
                Select(v => new ViewModelFacturaCabecs()
                {
                    Id = v.Id,
                    Nombreempresaemisora = empresa.NomEmpresa,
                    Rucemisor = empresa.RucDni,
                    Direccionemisor = empresa.Direccion,
                    Provinciaemisor = empresa.Provinciaemisor,
                    Distritoemisor = empresa.Distritoemisor,
                    Telefonoemisor = empresa.Telefono,
                    NomCli = v.NomCli,
                    Ruc = v.Ruc,
                    NroFac = v.NroFac,
                    TipDoc = v.TipDoc,
                    Fecha = v.Fecha,
                    Hora = v.Hora,
                    Neto = v.Neto,
                    Igv = v.Impuesto,
                    SubTot = v.SubTot,
                    Tipodocumentosunat = v.Tipodocumentosunat,
                    Qr = v.Qr,
                    LogoBase64 = imageDataUrl, // Pasar la imagen Base64 al modelo

                    Facturadetalles = v.Facturadetalles.Select(dv => new DetalleFactura()
                    {
                        CodProd = (int)dv.CodProd,
                        DescProd = dv.Descprod,
                        CanProd = (int)dv.CanProd,
                        PunitProd = (decimal)dv.Punitprod,
                        Total = (decimal)dv.Total,
                        Serie = dv.Serie,
                        Modelo = dv.Modelo,
                        Marca = dv.Marca,
                    }).ToList()
                }).FirstOrDefault();

            return new ViewAsPdf("CrearPdfTicket", modelo)
            {
                PageSize = Rotativa.AspNetCore.Options.Size.A7,
                PageOrientation = Rotativa.AspNetCore.Options.Orientation.Portrait,
                PageMargins = new Rotativa.AspNetCore.Options.Margins(3, 3, 3, 3), // Ajustar los márgenes según sea necesario
                CustomSwitches = "--page-width 80mm --page-height 297mm --dpi 300 --image-dpi 300 --disable-smart-shrinking --print-media-type"
                // FileName = $"Junta{modelo.Descripcion}.pdf", // SI QUEREMOS QUE EL ARCHIVO SE DESCARGUE DIRECTAMENTE
            };
        }
    }
}
