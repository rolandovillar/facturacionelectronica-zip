﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Facturacionelectronica.Models.ViewModels;
using System.Security.Cryptography;

namespace Facturacionelectronica.Controllers
{
    [AllowAnonymous]
    public class RegistrarseController : Controller
    {
        private readonly Contexto _context;

        public RegistrarseController(Contexto context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult Registrar([FromForm] RegistroViewModel modelo)
        {
            // Verifica los valores que llegan al servidor
            Console.WriteLine($"NomEmpresa: {modelo.NomEmpresa}, Direccion: {modelo.Direccion}, Correo: {modelo.Correo}, NombreUsuario: {modelo.NombreUsuario}, Clave: {modelo.Clave}");

            // Validación de los datos del modelo
            if (!ModelState.IsValid)
            {
                return Json(new { success = false, message = "Datos inválidos." });
            }

            try
            {
                // Cifrar la contraseña antes de guardarla
                string claveCifrada = CifrarContraseña(modelo.Clave);

                // Crear y poblar la entidad Empresa
                var empresa = new Empresa
                {
                    NomEmpresa = modelo.NomEmpresa,
                    Direccion = modelo.Direccion,
                    Correo = modelo.Correo,
                    NombreUsuario = modelo.NombreUsuario,
                    Clave = claveCifrada, // Almacenar la clave cifrada
                    Rol = "ADMINISTRADOR"
                };

                // Añadir la empresa al contexto
                _context.Empresas.Add(empresa);
                // Guardar la empresa para obtener el Id generado
                _context.SaveChanges();

                // Crear y poblar la entidad Usuario
                var usuario = new Usuario
                {
                    Nombre = modelo.NombreUsuario,
                    Correo = modelo.Correo,
                    Roles = "ADMINISTRADOR",   // Asignar el rol por defecto
                    IdEmpresas = empresa.Id,   // Relacionamos el usuario con la empresa
                    Claves = claveCifrada      // Almacenar la clave cifrada en el usuario
                };

                // Añadir el usuario al contexto
                _context.Usuarios.Add(usuario);

                // Guardar los cambios en la base de datos
                _context.SaveChanges();

                return Json(new { success = true, redirectTo = Url.Action("Index", "Login") });
            }
            catch (Exception ex)
            {
                // Loguea el error
                Console.WriteLine($"Error al guardar la entidad: {ex.Message}");
                // También puedes devolver la excepción al frontend para ver más detalles
                return Json(new { success = false, message = ex.Message });
            }
        }

        // Método para cifrar la contraseña
        private string CifrarContraseña(string contraseña)
        {
            byte[] sal = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(sal);
            }

            // Derivar subclave
            string hash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: contraseña,
                salt: sal,
                prf: KeyDerivationPrf.HMACSHA512,
                iterationCount: 100_000,
                numBytesRequested: 256 / 8));

            // Retornar sal y hash combinados
            return $"{Convert.ToBase64String(sal)}${hash}";
        }
    }
}
