﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class LogosController : Controller
    {
        private readonly Contexto _context;
        private readonly IWebHostEnvironment _env;
        private int _idempresa;

        public LogosController(Contexto context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
            _idempresa = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }

        [HttpGet]
        public IActionResult UploadLogo()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadLogo(IFormFile logo)
        {
            if (logo == null || logo.Length == 0)
            {
                ModelState.AddModelError("logo", "Seleccione un archivo válido.");
                return View();
            }

            var ext = Path.GetExtension(logo.FileName).ToLower();
            if (ext != ".png" && ext != ".jpg" && ext != ".jpeg")
            {
                ModelState.AddModelError("logo", "Solo se permiten archivos .png o .jpg");
                return View();
            }

            using var memoryStream = new MemoryStream();
            await logo.CopyToAsync(memoryStream);
            var imageBytes = memoryStream.ToArray();

            var anterior = _context.Imagens.FirstOrDefault(x => x.IdEmpresa == _idempresa);
            if (anterior != null)
            {
                _context.Imagens.Remove(anterior);
            }

            var nuevaImagen = new Imagen
            {
                Imagen1 = imageBytes,
                MimeType = logo.ContentType,
                IdEmpresa = _idempresa
            };

            _context.Add(nuevaImagen);
            await _context.SaveChangesAsync();

            TempData["Message"] = "Logo actualizado correctamente.";
            return RedirectToAction("UploadLogo");
        }
    }
}
