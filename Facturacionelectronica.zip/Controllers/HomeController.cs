using System.Diagnostics;
using System.Security.Claims;
using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Facturacionelectronica.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly Contexto _context;

        public HomeController(ILogger<HomeController> logger, Contexto context)
        {
            _logger = logger;
            _context = context;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0;
            }
            return empresaId;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ObtenerLogo()
        {
            int empresaId = ObtenerIdEmpresa();

            var imagen = _context.Imagens.FirstOrDefault(i => i.IdEmpresa == empresaId);
            if (imagen != null && imagen.Imagen1 != null)
            {
                return File(imagen.Imagen1, imagen.MimeType);
            }

            // Imagen por defecto si no se encuentra
            var rutaImagenPorDefecto = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "image", "logo.png");
            var bytesPorDefecto = System.IO.File.ReadAllBytes(rutaImagenPorDefecto);
            return File(bytesPorDefecto, "image/png");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}