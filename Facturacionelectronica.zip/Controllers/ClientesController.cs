﻿using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class ClientesController : Controller
    {
        private int _idempresa;  // <-- propiedad que guardarás
        private readonly Contexto _context;

        public ClientesController(Contexto context)
        {
            _context = context;
        }
        // Se ejecuta antes de cualquier acción
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            // Guardar el ID de empresa del usuario logueado
            _idempresa = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }
        public async Task<IActionResult> Index()
        {

            var clientes = await _context.Clientes
                .Where(p => p.IdEmpresas == _idempresa)
                .OrderBy(x => x.Nombrecliente).ToListAsync();

            return View(clientes);
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Clientes == null)
            {
                return NotFound();
            }

            var cliente = await _context.Clientes
                .FirstOrDefaultAsync(m => m.Id == id && m.IdEmpresas == _idempresa);

            if (cliente == null)
            {
                return NotFound();
            }

            return View(cliente);
        }

        // GET: Clientes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Clientes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Cliente cliente)
        {
            if (!ModelState.IsValid)
            {
                return View(cliente);
            }

            var existe = _context.Clientes
                .FirstOrDefault(c =>
                    (c.Nombrecliente == cliente.Nombrecliente ||
                    c.Rucdni == cliente.Rucdni) &&
                    c.IdEmpresas == _idempresa);                   // se agrego el filtro para empresas

            if (existe != null)
            {
                if (existe.Nombrecliente == cliente.Nombrecliente)
                    ModelState.AddModelError(nameof(cliente.Nombrecliente),
                        "El nombre del cliente ya existe.");
                else
                    ModelState.AddModelError(nameof(cliente.Rucdni),
                        "El documento del cliente ya existe.");

                // IMPORTANT: devolver la vista con el mismo modelo para ver los errores
                return View(cliente);

            }

            cliente.IdEmpresas = _idempresa;
            cliente.Activo = 1;

            _context.Add(cliente);
            _context.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        // GET: Clientes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Clientes == null)
            {
                return NotFound();
            }

            var cliente = await _context.Clientes.Where(x => x.Id == id && x.IdEmpresas == _idempresa).FirstAsync();
            if (cliente == null)
            {
                return NotFound();
            }
            return View(cliente);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Cliente cliente)
        {
            if (id != cliente.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    cliente.Activo = 1;
                    cliente.IdEmpresas = _idempresa;
                    _context.Update(cliente);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClienteExists((int)cliente.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cliente);
        }

        // GET: Clientes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Clientes == null)
            {
                return NotFound();
            }

            var cliente = await _context.Clientes
                 .FirstOrDefaultAsync(m => m.Id == id && m.IdEmpresas == _idempresa);

            if (cliente == null)
            {
                return NotFound();
            }

            return View(cliente);
        }

        // POST: Clientes/Delete/5
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cliente = await _context.Clientes
                 .FirstOrDefaultAsync(m => m.Id == id && m.IdEmpresas == _idempresa);

            if (cliente != null)
            {
                cliente.Activo = 0;
                cliente.IdEmpresas = _idempresa;
                _context.Update(cliente);

            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClienteExists(int id)
        {
            return _context.Clientes.Any(e => e.Id == id && e.IdEmpresas == _idempresa);
        }
    }
}
