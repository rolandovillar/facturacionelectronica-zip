﻿using Facturacionelectronica.Models.ViewModels;
using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class CertificadosController : Controller
    {
        private readonly Contexto _context;

        public CertificadosController(Contexto context)
        {
            _context = context;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(idEmpresaClaim, out int empresaId) ? empresaId : 0;
        }

        [HttpGet]
        public IActionResult Subir()
        {
            int idEmpresa = ObtenerIdEmpresa();
            var empresa = _context.Empresas.FirstOrDefault(e => e.Id == idEmpresa);
            if (empresa == null) return NotFound("Empresa no encontrada.");

            var viewModel = new CertificadoDigitalViewModel
            {
                IdEmpresa = empresa.Id,
                EmpresaRUC = empresa.RucDni
            };
            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Subir(CertificadoDigitalViewModel model)
        {
            int idEmpresa = ObtenerIdEmpresa();

            var empresa = _context.Empresas.FirstOrDefault(e => e.Id == idEmpresa);


            if (!ModelState.IsValid) return View(model);

            if (!model.ServerPem.FileName.EndsWith(".pem", StringComparison.OrdinalIgnoreCase) ||
                !model.ServerKeyPem.FileName.EndsWith(".pem", StringComparison.OrdinalIgnoreCase))
            {
                ModelState.AddModelError("", "Solo se permiten archivos .pem.");
                return View(model);
            }

            if (model.ServerPem.Length > 1024 * 1024 || model.ServerKeyPem.Length > 1024 * 1024)
            {
                ModelState.AddModelError("", "El tamaño máximo permitido es 1 MB.");
                return View(model);
            }

            try
            {
                byte[] serverPemBytes;
                using (var ms = new MemoryStream())
                {
                    await model.ServerPem.CopyToAsync(ms);
                    serverPemBytes = ms.ToArray();
                }

                byte[] serverKeyPemBytes;
                using (var ms = new MemoryStream())
                {
                    await model.ServerKeyPem.CopyToAsync(ms);
                    serverKeyPemBytes = ms.ToArray();
                }

                var certificado = new CertificadoDigital
                {
                    EmpresaRUC = empresa.RucDni,
                    ServerPem = serverPemBytes,
                    ServerKeyPem = serverKeyPemBytes,
                    IdEmpresa = idEmpresa,
                    NombreArchivoCertificado = model.ServerPem.FileName,
                    FechaCarga = DateTime.UtcNow, // aunque ya tiene valor por defecto
                    Entorno = "Producción" // si aplica, o ajusta según sea necesario
                };

                certificado.EmpresaRUC = empresa.RucDni;
                certificado.IdEmpresa = idEmpresa;

                _context.CertificadosDigitales.Add(certificado);
                await _context.SaveChangesAsync();

                TempData["Mensaje"] = "Certificado subido correctamente.";
                return RedirectToAction("Subir");
            }
            catch
            {
                ModelState.AddModelError("", "Ocurrió un error al procesar el certificado.");
                return View(model);
            }
        }
    }
}