﻿using Facturacionelectronica.Models;
using Facturacionelectronica.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rotativa.AspNetCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class DetalleComprasController : Controller
    {
        private readonly Contexto ctx;
        static string inicio;
        static string fin;
        public DetalleComprasController(Contexto _ctx)
        {
            ctx = _ctx;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        public async Task<IActionResult> Index()
        {
            int Idempresa = ObtenerIdEmpresa();

            var detalles = await ctx.Comprasdetalles
                .Where(d => d.IdEmpresas == Idempresa)
                .OrderBy(d => d.Id)
                .ToListAsync();

            return View(detalles);
        }

        // Filtrar detalles por fecha
        public async Task<IActionResult> FiltrarDetalles(DateTime? fechaInicio, DateTime? fechaFin)
        {
            int Idempresa = ObtenerIdEmpresa();

            if (!fechaInicio.HasValue || !fechaFin.HasValue)
            {
                return BadRequest("Debe seleccionar ambas fechas.");
            }

            var detalles = await ctx.Comprasdetalles
                .Where(d => d.Fecha >= fechaInicio.Value && d.Fecha <= fechaFin.Value && d.IdEmpresas == Idempresa)
                .OrderBy(d => d.Fecha)
                .ToListAsync();

            if (!detalles.Any())
            {
                return Content("<p class='text-danger'>No se encontraron registros en este rango de fechas.</p>");
            }

            return PartialView("_TablaDetalles", detalles);
        }
        public IActionResult GenerarPdf(DateTime? fechaInicio, DateTime? fechaFin)
        {
            int Idempresa = ObtenerIdEmpresa();

            inicio = fechaInicio.Value.ToString("dd/MM/yyyy");
            fin = fechaFin.Value.ToString("dd/MM/yyyy");

            var detalles = ctx.Comprasdetalles
                .Where(d => d.Fecha >= fechaInicio.Value && d.Fecha <= fechaFin.Value && d.IdEmpresas == Idempresa)
                .OrderBy(d => d.Fecha)
                .ToList();

            var modelo = new ComprasdetallesFechasViewModel
            {
                RangoFechas = $"DESDE {inicio} HASTA EL {fin}",
                Detalles = detalles
            };

            return new ViewAsPdf("GenerarPdf", modelo)
            {
                FileName = $"ReporteCompras_{fechaInicio.Value.ToString("yyyyMMdd")}_a_{fechaFin.Value.ToString("yyyyMMdd")}.pdf",
                PageSize = Rotativa.AspNetCore.Options.Size.A4,
            };
        }
    }
}
