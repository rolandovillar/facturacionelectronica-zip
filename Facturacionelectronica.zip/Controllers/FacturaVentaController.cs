﻿using Facturacionelectronica.Models.ViewModels;
using Facturacionelectronica.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Rotativa.AspNetCore;
using System.Security.Claims;
using QRCoder;

namespace Facturacionelectronica.Controllers
{
    public class FacturaVentaController : Controller
    {
        private readonly Contexto _context;

        static int Envio3;
        public int reg = 0;
        public FacturaVentaController(Contexto context)
        {
            _context = context;

        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        public IActionResult Index()
        {
            int Idempresa = ObtenerIdEmpresa();

            var Clientes = _context.Clientes.Where(x => x.IdEmpresas == Idempresa).ToList();
            ViewBag.Filtrados = Clientes;

            var pro = _context.Productos.Where(x => x.IdEmpresas == Idempresa)
             .Include(m => m.MarcaNavigation)
             .Include(p => p.CategoriumNavegation) // Incluir la propiedad de navegación de Categorium
             .Select(p => new
             {
                 Id = p.Id,
                 Descripcion = p.Descripcion,
                 Referencia = p.Referencia,
                 Serie = p.Serie,
                 Categoria = p.CategoriumNavegation.Nombrecategoria,
                 Preciocosto = p.Preciocosto,
                 Precioventa = p.Precioventa,
                 Stock = p.Stock,
                 Marca = p.MarcaNavigation.Nombremarca,
                 Modelo = p.Modelo,
                 Proveedor = p.ProveedorNavigation.Nombreproveedor,
             }).ToList();

            ViewBag.Productos = pro;

            // Obtener lista de marcas
            var marcas = _context.Marcas.Where(x => x.IdEmpresas == Idempresa).ToList();

            // Obtener lista de categorías
            var categorias = _context.Categoria.Where(x => x.IdEmpresas == Idempresa).ToList();
            if (categorias == null)
            {
                // Manejar el caso en que las categorías no se carguen correctamente
                // Por ejemplo, puedes registrar un mensaje de error o redirigir a una página de error
                return RedirectToAction("Error");
            }
            // Obtener lista de proveedores
            var proveedores = _context.Proveedors.Where(x => x.IdEmpresas == Idempresa).ToList();

            // Pasar las listas a la vista
            ViewBag.Marcas = new SelectList(marcas, "Id", "Nombremarca");
            ViewBag.Categorias = new SelectList(categorias, "Id", "Nombrecategoria");
            ViewBag.Proveedores = new SelectList(proveedores, "Id", "Nombreproveedor");

            var recepcion = _context.Recepcionequipos.Where(x => x.IdEmpresas == Idempresa).ToList();
            ViewBag.Recepcion = recepcion;

            return View();
        }

        [HttpGet]
        public IActionResult ObtenerProductos([FromQuery] string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return PartialView("_ProductoSearchPartial", new List<Producto>());
            }

            term = term.Trim().ToUpper();

            // Obtener el IdEmpresas del usuario logueado
            int Idempresa = ObtenerIdEmpresa();

            var productos = _context.Productos
                .Include(p => p.MarcaNavigation)
                .Where(p => p.IdEmpresas == Idempresa &&
                            (EF.Functions.Like(p.Descripcion.ToUpper(), $"{term}%") ||
                             EF.Functions.Like((p.Serie ?? "").ToUpper(), $"{term}%")))
                .Select(p => new Producto
                {
                    Id = p.Id,
                    Descripcion = p.Descripcion,
                    Stock = p.Stock,
                    Precioventa = p.Precioventa,
                    Serie = p.Serie,
                    Modelo = p.Modelo,
                    MarcaNavigation = new Marca { Nombremarca = p.MarcaNavigation.Nombremarca }
                })
                .Take(15)
                .ToList();

            return PartialView("_ProductoSearchPartial", productos);
        }

        public IActionResult Cargarempresa([FromQuery] int? id)
        {
            id = 1;
            var lista = _context.Empresas.Where(p => p.Id == id).Select(
                p => new
                {
                    id = p.Id,
                    nombreempresaemisor = p.NomEmpresa,
                    direccionemisor = p.Direccion,
                    rucemisor2 = p.RucDni,
                    provinciaemisor = p.Provinciaemisor,
                    distritoemisor = p.Distritoemisor,
                    telefonoemisor = p.Telefono,
                }).First();
            return Json(lista);
        }
        public IActionResult ObtenerNumeroCorrelativo([FromQuery] int? tipo)
        {
            int Idempresa = ObtenerIdEmpresa();

            int tipoDoc = tipo ?? 4; // Si 'tipo' es nulo, asigna 4 por defecto

            var lista = _context.Tipodocumentos
                .Where(p => p.Cod == tipoDoc && p.IdEmpresas == Idempresa)
                .Select(p => new
                {
                    id = p.Id,
                    nroserie = p.NroSerie,
                    ultimo = p.Ultimo + 1,
                    igv = p.Impuesto,
                    idsunat = p.Idsunat,
                    letrasunat = p.Letrasunat
                })
                .FirstOrDefault(); // Usar FirstOrDefault para evitar errores si no hay datos

            if (lista == null)
            {
                return Json(new { error = "No se encontró el número correlativo para el tipo de documento." });
            }

            return Json(lista);
        }

        [HttpGet]
        public JsonResult ObtenerClientes()
        {
            // Obtener el IdEmpresas del usuario logueado
            int Idempresa = ObtenerIdEmpresa();

            var clientes = _context.Clientes.Select(c => new
            {
                nombre = c.Nombrecliente,
                ruc = c.Rucdni,
            }).ToList();

            return Json(clientes);
        }

        [HttpPost]
        public IActionResult GuardarVenta([FromBody] ViewModelFacturaCabecs model)
        {
            int Idempresa = ObtenerIdEmpresa();

            if (model == null)
            {
                return BadRequest("El modelo es nulo");
            }

            var emisor = _context.Empresas.Where(d => d.Id == 1).First();

            string qrContent = $"{emisor.RucDni}\n{model.NroFac}\n{model.Neto}\n{emisor.NomEmpresa}\n{model.NomCli}\n{model.Fecha.Value.ToString("dd/MM/yyyy")}";

            // Crear el código QR
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(qrContent, QRCodeGenerator.ECCLevel.Q);
            PngByteQRCode qrCode = new PngByteQRCode(qrCodeData);
            byte[] qrCodeImage = qrCode.GetGraphic(5);
            string qrBase64 = Convert.ToBase64String(qrCodeImage);

            // actualiza numero de documento
            var obj2 = _context.Tipodocumentos.Where(p => p.Documento == model.TipDoc && p.IdEmpresas == Idempresa).FirstOrDefault();

            int ultimonroxx = (int)model.NroDocumento;
            obj2.Ultimo = ultimonroxx;
            _context.Update(obj2);
            _context.SaveChanges();
            //-------------------------------------------
            TimeSpan horaDelDia = DateTime.Now.TimeOfDay;

            TimeOnly timeParaBaseDeDatos = new TimeOnly(horaDelDia.Hours, horaDelDia.Minutes, horaDelDia.Seconds);

            // Crear la cabecera de la factura (Facturacabe)
            Facturacabe facturaCab = new Facturacabe
            {
                NroFac = model.NroFac,
                CodCli = model.CodCli,
                NomCli = model.NomCli,
                DireCli = model.DireCli,
                Ruc = model.Ruc,
                TipDoc = model.TipDoc,
                NroDocumento = model.NroDocumento,
                Fecha = model.Fecha,
                Fechapago = model.Fecha,
                Formapago = model.Formapago,
                Neto = model.Neto,
                Hora = timeParaBaseDeDatos,
                Vuelto = model.Vuelto,
                PagoEfectivo = model.PagoEfectivo,
                PagoTarjeta = model.PagoTarjeta,
                Qr = qrBase64,
                IdEmpresas = Idempresa,

                // Asigna otros campos según necesites
            };

            _context.Facturacabes.Add(facturaCab);
            _context.SaveChanges();

            var ultimoRegistro = _context.Facturacabes.Where(x => x.IdEmpresas == Idempresa).OrderByDescending(f => f.Id).FirstOrDefault();

            Envio3 = ultimoRegistro.Id;


            if (model?.Facturadetalles == null || model.Facturadetalles.Count == 0)
            {
                return BadRequest("No se recibieron detalles de factura.");
            }

            Console.WriteLine($"Detalles recibidos: {model.Facturadetalles.Count}");


            // Guardar los detalles (Facturadetalle)
            foreach (var item in model.Facturadetalles)
            {

                Facturadetalle detalle = new Facturadetalle
                {
                    Facturacabeid = facturaCab.Id,
                    CodCli = model.CodCli,
                    NomCli = model.NomCli,
                    NroFac = facturaCab.NroFac,
                    CodProd = item.CodProd,
                    CanProd = item.CanProd,
                    Descprod = item.DescProd,
                    Punitprod = item.PunitProd,
                    Total = item.Total,
                    Serie = item.Serie,
                    Marca = item.Marca,
                    Fecha = model.Fecha,
                    IdEmpresas = Idempresa,
                    //  Preciosinimpuesto = (decimal)Preciosinimpuesto2,
                    //  Porcentajeimpuesto = Porcentajeimpuesto2,
                };
                _context.Facturadetalles.Add(detalle);

                // Buscar el producto por Id
                var producto = _context.Productos.Where(p => p.Id == detalle.CodProd && p.IdEmpresas == Idempresa).FirstOrDefault();

                // Actualizar stock
                producto.Stock -= detalle.CanProd ?? 0;
                _context.Productos.Update(producto);

                _context.SaveChanges();

                var productoinventario = _context.Productos.Where(p => p.Id == detalle.CodProd && p.IdEmpresas == Idempresa).FirstOrDefault();

                // Crear la nueva instancia de Inventario
                var nuevoinventario = new Inventario
                {
                    Idproducto = item.CodProd,
                    Descproducto = detalle.Descprod,
                    Cantidadventas = (decimal)(detalle.CanProd ?? 0),
                    Cantidadcompras = 0,
                    Stock = (decimal)productoinventario.Stock,  // Convertimos Stock a decimal
                    Fecha = DateTime.Now,           // O la fecha que necesites
                    Documento = "VENTAS",
                    Nrodocumento = detalle.NroFac,
                    Marca = detalle.Marca,
                    IdEmpresas = Idempresa,
                    ComprasdetalleId = detalle.Id,
                };

                // Agregar el nuevo inventario
                _context.Inventarios.Add(nuevoinventario);
            }

            // Calcular el impuesto total sumando el campo Preciosinimpuesto de todos los detalles
            var totalImpuesto = _context.Facturadetalles
                .Where(fd => fd.Facturacabeid == facturaCab.Id && fd.IdEmpresas == Idempresa)
                .Sum(fd => fd.Precsinigvsunat);

            _context.SaveChanges();

            //----------------------------------------------------------------------------------------------------------------------------
            return Ok(new { mensaje = "Venta guardada con éxito", facturaId = facturaCab.Id });

        }

        public IActionResult CrearPdf(int facturaId)
        {
            Envio3 = facturaId;

            int Idempresa = ObtenerIdEmpresa();
            var empresa = _context.Empresas.First(e => e.Id == Idempresa);

            // Obtener el logo y su tipo MIME
            var logoData = _context.Imagens
                .Where(i => i.IdEmpresa == Idempresa)
                .Select(i => new { i.Imagen1, i.MimeType })
                .FirstOrDefault();

            string imageDataUrl = "";

            if (logoData?.Imagen1 != null && !string.IsNullOrEmpty(logoData.MimeType))
            {
                var base64 = Convert.ToBase64String(logoData.Imagen1);
                imageDataUrl = $"data:{logoData.MimeType};base64,{base64}";
            }

            var modelo = _context.Facturacabes
                .Include(dv => dv.Facturadetalles)
                .Where(v => v.Id == Envio3 && v.IdEmpresas == Idempresa)
                .Select(v => new ViewModelFacturaCabecs
                {
                    Id = v.Id,
                    Nombreempresaemisora = empresa.NomEmpresa,
                    Rucemisor = empresa.RucDni,
                    Direccionemisor = empresa.Direccion,
                    Provinciaemisor = empresa.Provinciaemisor,
                    Distritoemisor = empresa.Distritoemisor,
                    Telefonoemisor = empresa.Telefono,
                    NomCli = v.NomCli,
                    Ruc = v.Ruc,
                    NroFac = v.NroFac,
                    TipDoc = v.TipDoc,
                    Fecha = v.Fecha,
                    Fechapago = v.Fechapago,
                    Hora = v.Hora,
                    Neto = v.Neto,
                    Vuelto = v.Vuelto,
                    PagoEfectivo = v.PagoEfectivo,
                    PagoTarjeta = v.PagoTarjeta,
                    Tipopago = v.Tipopago,
                    Tipodocumentosunat = v.Tipodocumentosunat,
                    Qr = v.Qr,
                    LogoBase64 = imageDataUrl,
                    Usuario = v.Usuario,
                    Facturadetalles = v.Facturadetalles.Select(dv => new DetalleFactura
                    {
                        CodProd = (int)dv.CodProd,
                        DescProd = dv.Descprod,
                        CanProd = (int)dv.CanProd,
                        PunitProd = (decimal)dv.Punitprod,
                        Total = (decimal)dv.Total,
                        Serie = dv.Serie,
                        Marca = dv.Marca,
                    }).ToList()
                }).FirstOrDefault();

            return new ViewAsPdf("CrearPdf", modelo)
            {
                PageSize = Rotativa.AspNetCore.Options.Size.A7,
                PageOrientation = Rotativa.AspNetCore.Options.Orientation.Portrait,
                PageMargins = new Rotativa.AspNetCore.Options.Margins(3, 3, 3, 3),
                CustomSwitches = "--page-width 80mm --page-height 297mm --dpi 300 --image-dpi 300 --disable-smart-shrinking --print-media-type",
                FileName = $"Venta{modelo.NroFac}.pdf"
            };
        }
    }
}
