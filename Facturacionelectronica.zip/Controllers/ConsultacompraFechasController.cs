﻿using Facturacionelectronica.Models;
using Facturacionelectronica.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rotativa.AspNetCore;
using System.Security.Claims;

namespace Facturacionelectronica.Controllers
{
    public class ConsultacompraFechasController : Controller
    {
        private readonly Contexto _context;
        static string inicio;
        static string fin;
        static string fechapag;
        decimal total;
        public ConsultacompraFechasController(Contexto context)
        {

            _context = context;
        }

        private int ObtenerIdEmpresa()
        {
            var idEmpresaClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmpresaClaim) || !int.TryParse(idEmpresaClaim, out int empresaId))
            {
                return 0; // o puedes lanzar error si quieres
            }
            return empresaId;
        }
        public IActionResult Index()
        {
            int Idempresa = ObtenerIdEmpresa();

            var report = _context.Comprascabes
                .Where(x => x.IdEmpresas == Idempresa)
                .OrderBy(p => p.Id).ToList();
            return View(report);

        }
        // Filtrar detalles por fecha
        public async Task<IActionResult> FiltrarCompras(DateTime? fechaInicio, DateTime? fechaFin)
        {
            if (!fechaInicio.HasValue || !fechaFin.HasValue)
            {
                return BadRequest("Debe seleccionar ambas fechas.");
            }

            var cabeceras = await _context.Comprascabes
                .Where(d => d.Fecha >= fechaInicio.Value && d.Fecha <= fechaFin.Value)
                .OrderBy(d => d.Fecha)
                .ToListAsync();

            if (!cabeceras.Any())
            {
                return Content("<p class='text-danger'>No se encontraron registros en este rango de fechas.</p>");
            }

            return PartialView("_TablaCabeceraCompras", cabeceras);
        }

        public IActionResult GeneraPdf(DateTime? fechaInicio, DateTime? fechaFin)
        {
            inicio = fechaInicio.Value.ToString("dd/MM/yyyy");
            fin = fechaFin.Value.ToString("dd/MM/yyyy");

            var facturas = _context.Comprascabes
                .Where(d => d.Fecha >= fechaInicio.Value && d.Fecha <= fechaFin.Value)
                .OrderBy(d => d.Fecha)
                .ToList();

            var modelo = new ComprasFechasViewModel
            {
                RangoFechas = $"DESDE {inicio} HASTA EL {fin}",
                Compras = facturas
            };

            return new ViewAsPdf("GeneraPdf", modelo)
            {
                FileName = $"Reporte_{fechaInicio.Value.ToString("yyyyMMdd")}_a_{fechaFin.Value.ToString("yyyyMMdd")}.pdf",
                PageSize = Rotativa.AspNetCore.Options.Size.A4,
            };
        }
    }
}
