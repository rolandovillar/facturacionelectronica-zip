using Microsoft.EntityFrameworkCore;
using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Rotativa.AspNetCore;
using Myvas.AspNetCore.Email;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Facturacionelectronica.Models;
using Facturacionelectronica.Models.Servicios;

var builder = WebApplication.CreateBuilder(args);

// Servicios de correo electr�nico
builder.Services.AddEmail(options =>
{
    options.SmtpServerAddress = builder.Configuration["EmailSettings:SmtpServerAddress"];
    options.SmtpServerPort = int.Parse(builder.Configuration["EmailSettings:SmtpServerPort"]);
    options.SenderAccount = builder.Configuration["EmailSettings:SenderAccount"];
    options.SenderPassword = builder.Configuration["EmailSettings:SenderPassword"];
    options.SenderDisplayName = builder.Configuration["EmailSettings:SenderDisplayName"];
});

// Agregar servicios MVC con pol�tica de autorizaci�n global
builder.Services.AddControllersWithViews(options =>
{
    var policy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
    options.Filters.Add(new AuthorizeFilter(policy));
});

// Base de datos
builder.Services.AddDbContext<Contexto>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// Autenticaci�n con cookies
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Login/Index";
        options.AccessDeniedPath = "/Login/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(60);
        options.SlidingExpiration = true;
    });

builder.Services.AddSingleton<EncryptionService>(provider =>
{
    var config = provider.GetRequiredService<IConfiguration>();
    var key = config["EncryptionKey"] ?? throw new Exception("EncryptionKey no configurada.");
    return new EncryptionService(key);
});

builder.Services.AddScoped<CertificadoService>();

// Servicios adicionales
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<UserSession>();

var app = builder.Build();

// Pipeline de ejecuci�n
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

// Localizaci�n
var supportedCultures = new[] { new CultureInfo("es-ES") };
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("es-ES"),
    SupportedCultures = supportedCultures,
    SupportedUICultures = supportedCultures
});

// Rutas
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Registrarse}/{action=Index}/{id?}"
);

// Configuraci�n para generaci�n de PDFs
RotativaConfiguration.Setup(app.Environment.WebRootPath, "Rotativa");

app.Run();