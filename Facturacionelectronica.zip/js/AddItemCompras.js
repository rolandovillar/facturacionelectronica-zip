﻿
var cont = 0; 

// Función para seleccionar el producto y agregarlo a la tabla
function seleccionarProducto(id, descripcion, referencia, serie, preciocosto, marca, modelo) {
    cont++; // Incrementa contador para cada fila

    var fila = `<tr id="item-${cont}">
                <td>${id}</td>
                <td>${descripcion}</td>
                <td>
                    <input type="text" class="form-control form-control-sm" value="${referencia}" id="serie-${cont}" />
                </td>
                <td>
                    <input type="text" class="form-control form-control-sm" value="${serie}" id="serie-${cont}" />
                </td>
                <td>
                    <input type="text" class="form-control form-control-sm" value="${marca}" id="marca-${cont}" />
                </td>
                <td>
                    <input type="text" class="form-control form-control-sm" value="${modelo}" id="modelo-${cont}" />
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm col-cantidad" value="1" min="1"
                    onchange="calcularTotal(${cont})" id="cantidad-${cont}" />
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm col-precio" value="${preciocosto}"
                    onchange="calcularTotal(${cont})" id="preciocosto-${cont}" />
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm col-importe" value="${preciocosto}" id="importe-${cont}" readonly />
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm col-descuento" value="0" id="descuento-${cont}" />
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm col-canon" value="0" id="canon-${cont}" />
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm col-igic" value="7" id="igic-${cont}" />
                </td>
                <td>${preciocosto}</td> 
                <td>
                    <button type="button" class="btn btn-danger btn-sm" onclick="eliminarItem(${cont})">Eliminar</button>
                </td>
            </tr>`;

    $("#tabproductos tbody").append(fila);

    $("#item-" + cont).find('input[type="number"], input[type="text"]').each(function () {
        $(this).addClass("form-control-sm");
        $(this).css("width", "100%");
        $(this).css("box-sizing", "border-box");
    });

    $('#form-modalproducto').modal('hide');
}

function eliminarItem(cont) {
    $("#item-" + cont).remove();
}

function calcularTotal(cont) {
    // Capturamos los valores desde los inputs
    var cantidad = parseFloat($("#cantidad-" + cont).val()) || 0;
    var precio = parseFloat($("#preciocosto-" + cont).val()) || 0;
    var descuento = parseFloat($("#descuento-" + cont).val()) || 0;

    // Calculamos el importe bruto (cantidad x precio)
    var importeBruto = cantidad * precio;

    // Aplicamos descuento si existe
    var importeConDescuento = importeBruto;
    if (descuento > 0) {
        importeConDescuento = importeBruto - (importeBruto * (descuento / 100));
    }

    // Redondeamos a dos decimales
    importeConDescuento = Math.round(importeConDescuento * 100) / 100;

    // Mostramos el nuevo importe en el input correspondiente
    $("#importe-" + cont).val(importeConDescuento);
}

document.addEventListener("DOMContentLoaded", function () {
    // Obtener el botón de grabar
    const botonGrabar = document.getElementById("btgrabar");

    // Asociar el evento click al botón
    botonGrabar.addEventListener("click", function () {
        console.log("Botón 'Grabar' clickeado");

        // Validar proveedor
        var proveedor = document.getElementById("nombre").value;
        if (!proveedor) { // Corregido el paréntesis de cierre
            document.getElementById("nombre").focus();
            alert('FALTA PROVEEDOR... Seleccione un proveedor!');
            return;
        }

        // Validar documento
        var documento = document.getElementById("cboDocumento").value;
        if (documento === "0") {
            document.getElementById("cboDocumento").focus();
            alert('FALTA DOCUMENTO... Seleccione un tipo de documento!');
            return;
        }

        // Validar número de documento
        var nroDocumento = document.getElementById("txtNroDoc").value.trim();
        if (!nroDocumento) {
            document.getElementById("txtNroDoc").focus();
            alert('FALTA NÚMERO DE DOCUMENTO... Escriba el número de documento!');
            return;
        }

        // Validar fecha
        var fecha = document.getElementById("fecha").value.trim();
        if (!fecha) {
            document.getElementById("fecha").focus();
            alert('FALTA FECHA... Seleccione una fecha!');
            return;
        }

        // Validar total importe documento
        var totalimporte = document.getElementById("txttotaldocumento").value;
        if (!totalimporte || totalimporte === "0") {
            document.getElementById("txttotaldocumento").focus();
            alert('FALTA INGRESAR EL IMPORTE TOTAL DEL DOCUMENTO... !');
            return;
        }

        // Confirmar antes de enviar
        var confirmacion = confirm('¿Está seguro de que desea guardar?');
        if (confirmacion) {
            // Recoger datos del formulario
            // Recoger los valores correctamente
            var tipoDocumento = document.getElementById("cboDocumento").value;  // Selecciona el valor, no el objeto
            var nroDocumento = document.getElementById("txtNroDoc").value;

            var fecha = document.getElementById("fecha").value || "";

            var idproveedor = parseInt(document.getElementById("idproveedor").value);  // Asegurarse de que sea un número
            var nomprov = document.getElementById("nombre").value;
            var tipoPago = document.getElementById("cbotipopago").value; // Selecciona el valor de "TipoCompra"
            var formaPago = document.getElementById("cboformapago").value;
            var ruc = document.getElementById("ruc").value;
            var subtotal = parseFloat(document.getElementById("txtSubTotal").value); // Asegúrate de que sea número
            var impuesto = parseFloat(document.getElementById("txtTotalIgv").value); // Asegúrate de que sea número
            var total = parseFloat(document.getElementById("txttotaldocumento").value); // Asegúrate de que sea número

            // Imprimir los valores en la consola para verificar si todo es correcto
            console.log("Datos que se van a enviar:");
            console.log("TipoDoc:", tipoDocumento);
            console.log("NroDoc:", nroDocumento);
            console.log("Fecha:", fecha);
            console.log("NomProv:", nomprov);
            console.log("CodProv:", idproveedor);
            console.log("TipoCompra:", tipoPago);
            console.log("Formapago:", formaPago);
            console.log("Ruc:", ruc);
            console.log("SubTotal:", subtotal);
            console.log("Impuesto:", impuesto);
            console.log("Total:", total);

            // Crear objeto FormData
            var formData = new FormData();
            formData.append("TipoDoc", tipoDocumento);
            formData.append("NroDoc", nroDocumento);
            formData.append("Fecha", fecha);
            formData.append("NomProv", nomprov);
            formData.append("CodProv", idproveedor);
            formData.append("TipoCompra", tipoPago);
            formData.append("Formapago", formaPago);
            formData.append("Ruc", ruc);
            formData.append("SubTotal", subtotal);
            formData.append("Impuesto", impuesto);
            formData.append("Total", total);

            // Enviar datos al servidor con AJAX
            $.ajax({
                type: "POST",
                url: registrarUrl,  // Cambia esta URL según el controlador y acción de tu backend
                data: formData,
                contentType: false,
                processData: false,
                success: function (response) {
                    console.log(response);
               //     alert("grabo cabecera, ahora pasamos a detalles")
                    grabarDetalles(response);
                    // Aquí puedes manejar la respuesta del servidor
                },
                error: function (xhr, status, error) {
                    alert('Hubo un error inesperado. Intenta nuevamente.');
                }
            });
        }
    });
});
// Función para mostrar alertas con Bootstrap 5
function showAlert(message, type) {
    var alertDiv = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>`;
    $("#alert-container").html(alertDiv); // Asegúrate de tener un div con id="alert-container" donde mostrar las alertas
}

function grabarDetalles(response) {
    var detalles = [];

    $("#tabproductos tbody tr").each(function () {
        var documento = document.getElementById("cboDocumento").value;
        var nroDocumento = document.getElementById("txtNroDoc").value.trim();
        var proveedor = document.getElementById("nombre").value;
        var cabeceraid = response;  // El ID de la empresa se obtiene de la respuesta de la cabecera
        var idProducto = $(this).find("td").eq(0).text().trim();  // El ID del producto está en la primera columna
        var descripcion = $(this).find("td").eq(1).text().trim();  // Descripción del producto
        var referencia = $(this).find("td").eq(2).find('input').val();
        var serie = $(this).find("td").eq(3).find('input').val();
        var marca = $(this).find("td").eq(4).find('input').val();
        var modelo = $(this).find("td").eq(5).find('input').val();

        var cantidad = parseFloat($(this).find("td").eq(6).find('input').val());
        var precio = parseFloat($(this).find("td").eq(7).find('input').val());
        var importe = parseFloat($(this).find("td").eq(8).find('input').val());
        var descuento = parseFloat($(this).find("td").eq(9).find('input').val());
        var canon = parseFloat($(this).find("td").eq(10).find('input').val());
        var igic = parseFloat($(this).find("td").eq(11).find('input').val());

        // Verificar si alguno de los datos es incorrecto
        if (!idProducto || !cantidad || !precio) {
            console.error('Faltan datos en el producto', {
                idProducto: idProducto,
                cantidad: cantidad,
                precio: precio
            });
        }

        // Ahora que tenemos los valores, los agregamos al objeto detalles
        detalles.push({
            Documento: documento,
            NumeroFactura: nroDocumento,
            NomProv: proveedor,
            ComprascabeId: cabeceraid,  // Usamos el ID de la cabecera
            IdProducto: idProducto,
            Descproducto: descripcion,
            Referencia: referencia,
            Marca: marca,
            Modelo: modelo,
            Serie: serie,
            Cantidad: cantidad,
            Precio: precio,
            Importe: importe,  // Usamos el total como importe
            Porcentajedescuento: descuento,
            Canon: canon,
            PorcentajeIgic: igic
        });
    });

    // Verificar que detalles no esté vacío
    if (detalles.length === 0) {
        console.error("No se encontraron detalles para guardar.");
        alert('No se encontraron detalles para guardar.');
        return;  // No enviar la solicitud si no hay detalles
    }

    // Mostrar los datos antes de enviarlos al servidor para depuración
    console.log("Datos de los detalles a enviar:", detalles);


    // alert("Revisar el log");

    // Enviar los detalles al servidor
    $.ajax({
        type: "POST",
        url: Urlcomprasdetalle,  // URL para grabar los detalles
        contentType: 'application/json',
        data: JSON.stringify(detalles),  // Convertir los detalles a JSON
        success: function (response) {
            // alert('Detalles guardados correctamente');
            alert('Compras Guardado Correctamente .......');
        },
        error: function (error) {
            console.error('Error al guardar los detalles:', error);
            alert('Hubo un error al guardar los detalles');
        }
    });
}