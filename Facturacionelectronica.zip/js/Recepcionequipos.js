
    // Realizar una solicitud AJAX para obtener los datos del paciente por su ID
function seleccionarCliente(id) {
        $.ajax({
            type: "GET",
            url: "/RecepcionEquipos/seleccionarCliente?id=" + id,
            success: function (data) {
                // Aquí ya tienes los datos del cliente recibidos desde el servidor (en `data`)
                // Entonces llenas los campos de tu vista principal
                $('#idcliente').val(data.id);
                $('#dni').val(data.rucdni);
                $('#nombre').val(data.nombrecliente);
                $('#telefono').val(data.telefono);

                // Luego cierras el modal
                cargarRecepciones(data.id); // Opcional, si quieres cargar más info 
                document.getElementById("cerrarventanamodalclientes").click();   // Cerrar el modal  
            },
            error: function () {
                alert('Error al obtener los datos del paciente.');
            }
        });
}

function cerrarventanamodalclientes() {
    var modal = bootstrap.Modal.getInstance(document.getElementById('modalClientes'));
    if (modal) {
        modal.hide();
    }
}

function cargarRecepciones(idPaciente) {
    $.ajax({
        url: '/RecepcionEquipos/PasarRecepciones',
        type: 'GET',
        data: { id: idPaciente },
        success: function (historiaClinica) {
            var html = '';
            $.each(historiaClinica, function (index, registro) {

                var fechaFormateada = new Date(registro.fechaatencion).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });

                html += '<tr>';
                html += '<td>' + registro.id + '</td>';
                html += '<td>' + registro.tipoconsulta + '</td>';
                html += '<td>' + fechaFormateada + '</td>';
                html += '<td>' + registro.marca + '</td>';
                html += '<td>' + registro.modelo + '</td>';
                html += '<td>' + registro.serie + '</td>';
                html += '<td class="hidden">' + registro.sintomas + '</td>';
                html += '<td class="hidden">' + registro.diagnostico + '</td>';
                html += '<td class="hidden">' + registro.recomendacion + '</td>';
                html += '<td class="hidden">' + registro.reparaciones + '</td>';
                html += '<td class="hidden">' + registro.nrocomprobante + '</td>';
                html += '<td class="hidden">' + registro.totalimporte + '</td>';
                html += '<td class="hidden">' + registro.acuentaefectivo + '</td>';
                html += '<td class="hidden">' + registro.acuentatarjeta + '</td>';
                html += '<td class="hidden">' + registro.saldo + '</td>';
                html += '</tr>';
            });
            $('#historiaMedicaTableBody').html(html);

            // Agregar evento de clic a las filas de la tabla
            $('#historiaMedicaTableBody tr').click(function () {
                // Obtener los datos de la fila seleccionada
                var rowData = $(this).find('td');
                var tipoconsulta = $(rowData[1]).text(); // Obtener el valor de la primera columna
                var marca = $(rowData[3]).text(); // Obtener el valor de la primera columna
                var modelo = $(rowData[4]).text(); // Obtener el valor de la primera columna
                var serie = $(rowData[5]).text(); // Obtener el valor de la primera columna
                var sintomas = $(rowData[6]).text(); // Obtener el valor de la primera columna
                var diagnostico = $(rowData[7]).text(); // Obtener el valor de la segunda columna
                var recomendaciones = $(rowData[8]).text(); // Obtener el valor de la tercera columna
                var reparacion = $(rowData[9]).text(); // Obtener el valor de la cuarta columna
                var nrorecepcion = $(rowData[10]).text(); // Obtener el valor del nro de recepcion
                var totalimporte = $(rowData[11]).text(); // Obtener el valor del nro de recepcion
                var acuentaefectivo = $(rowData[12]).text(); // Obtener el valor del nro de recepcion
                var acuentatarjeta = $(rowData[13]).text(); // Obtener el valor del nro de recepcion
                var saldo = $(rowData[14]).text(); // Obtener el valor del nro de recepcion

                // Rellenar los campos correspondientes con los datos obtenidos
                $('#tipoConsulta').val(tipoconsulta);
                $('#marca').val(marca);
                $('#modelo').val(modelo);
                $('#serie').val(serie);
                $('#sintomas').val(sintomas);
                $('#diagnostico').val(diagnostico);
                $('#recomendacion').val(recomendaciones);
                $('#reparacion').val(reparacion); 
                $('#nrorecepcion').val(nrorecepcion);
                // se agrega total importe y saldo en la ventana modal
                $('#totalAmount').val(totalimporte);
                $('#saldo').val(saldo);
            });
        },
        error: function (error) {
            console.log(error);
        }
    });
}

function guardarRecepcion() {
    var nombre = $('#nombre').val();
    var tipoequipo = $('#tipoequipo').val();
    var sintomas = $('#sintomas').val();

    if (nombre == "") {
        alert("UTILICE EL BOTON 'SELECCIONE CLIENTE'");
        return;
    } 

    if (tipoequipo == "Seleccione un tipo") {
        alert("INGRESE UN TIPO DE EQUIPO");
        return;
    }

    if (sintomas == "") {
        alert("INGRESE ALGUN SINTOMA DEL EQUIPO ");
        return;
    } 
 
  //  if (confirm("¿Desea ingresar pagos a cuenta?")) {
  //      // Mostrar la ventana modal de modalidad de pago
  //      $('#paymentModal').modal('show');
  //  } else {
  //      // Guardar el documento directamente si no desea ingresar pagos a cuenta 
  // 
  //      btnContinuar();
  //  }

    if (confirm("¿Desea ingresar pagos a cuenta?")) {
        let modal = new bootstrap.Modal(document.getElementById('paymentModal'));
        modal.show();
    } else {
        btnContinuar();
    }
}

function guardarclientenuevo() {

    var dni = $('#dni').val();
    var nombre = $('#nombre').val();
    var telefono = $('#telefono').val();
 
    var frmCli = new FormData();
    frmCli.append("Rucdni", dni);
    frmCli.append("Nombrecliente", nombre);
    frmCli.append("Telefono", telefono);

    $.ajax({
        type: "POST",
        url: "/RecepcionEquipos/GuardarClienteNuevo",
        data: frmCli,
        contentType: false,
        processData: false,
        success: function (data) {
            if (data != 0) {
      //          continuarguardando();
            }
        }
    });
}

// Función para manejar el clic en el botón "Continuar"
function btnContinuar() {

    var nuevoCliente = $('#nuevoCliente').is(':checked');

    if (nuevoCliente == true) {
        guardarclientenuevo();
                    // Deshabilitar el checkbox después de guardar los datos
            $('#nuevoCliente').prop('disabled', true);
    } 
    // Cerrar la ventana modal de pago
    // $('#paymentModal').modal('hide');

    var modalElement = document.getElementById('paymentModal');
    var modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
        modalInstance.hide();
    }

    // Continuar con la lógica de guardado del formulario
    // Aquí puedes llamar a la función que maneja el guardado del formulario principal
    continuarguardando();
}

// Función para manejar el guardado del formulario principal
function continuarguardando() {


    var nrocomprobante = $('#nrorecepcion').val();
    var idcliente = $('#idcliente').val();
    var fechaOriginal = document.getElementById("fecha").value;
    var fechaFormateada = formatearFecha(fechaOriginal);
    var dni = $('#dni').val();
    var nombre = $('#nombre').val();
    var telefono = $('#telefono').val();
    var marca = $('#marca').val();
    var modelo = $('#modelo').val();
    var serie = $('#serie').val();
    var sintomas = $('#sintomas').val();
    var diagnostico = $('#diagnostico').val();
    var recomendacion = $('#recomendacion').val();
    var reparacion = $('#reparacion').val();
    var tipoconsulta = $('#tipoConsulta').val();

    // Validación de importes: convertir a 0 si están vacíos o nulos
    var totalimporte = $('#totalAmount').val() || 0;
    var efectivo = $('#conefectivo').val() || 0;
    var tarjeta = $('#contarjeta').val() || 0;
    var saldo = $('#saldo').val() || 0;

    // Convertir a número para evitar problemas con cadenas
    totalimporte = parseFloat(totalimporte) || 0;
    efectivo = parseFloat(efectivo) || 0;
    tarjeta = parseFloat(tarjeta) || 0;
    saldo = parseFloat(saldo) || 0;

    var tipoequipo = $('#tipoequipo').val();

    saldo = totalimporte - (efectivo + tarjeta);

    var frmCab = new FormData();
    frmCab.append("Nrocomprobante", nrocomprobante);
    frmCab.append("Codigocli", idcliente);
    frmCab.append("Fechaatencion", fechaFormateada);
    frmCab.append("Dni", dni);
    frmCab.append("Nombre", nombre);
    frmCab.append("Telefono", telefono);
    frmCab.append("Marca", marca);
    frmCab.append("Modelo", modelo);
    frmCab.append("Serie", serie);
    frmCab.append("Sintomas", sintomas);
    frmCab.append("Diagnostico", diagnostico);
    frmCab.append("Recomendaciones", recomendacion);
    frmCab.append("Reparaciones", reparacion);
    frmCab.append("Tipoconsulta", tipoconsulta);
    frmCab.append("Totalimporte", totalimporte);
    frmCab.append("Acuentaefectivo", efectivo);
    frmCab.append("Acuentatarjeta", tarjeta);
    frmCab.append("Saldo", saldo);
    frmCab.append("Tipoequipo", tipoequipo);
    
    $.ajax({
        type: "POST",
        url: "/Recepcionequipos/GuardaRecepcionequipos",
        data: frmCab,
        contentType: false,
        processData: false,
        success: function (data) {
            if (data != 0) {
                alert("Recepción del Equipo Guardada Correctamente");
                // Cierra la ventana modal después de guardar la cita
                imprimirRecepcion(data); // `data` debería ser el ID retornado por el servidor

              //  window.location.href = "/home";
            } else {
                alert("Ocurrió un error al Grabar Cabecera");
            }
        }
    });
}

function imprimirRecepcion(envioId) {

    // Construir la URL del controlador
    var url = "/RecepcionEquipos/CrearPdf?envioId=" + envioId;

    // Abrir la URL en una nueva pestaña o ventana para generar el PDF
    window.open(url, "_blank");

    // Esperar 3 segundos y redirigir a la página principal
    setTimeout(function () {
        window.location.href = "/RecepcionEquipos/Index";
    }, 3000); // 3000 ms = 3 segundos

}


// Función para actualizar la suma de los importes y el saldo
function updateSum() {
    // Obtener los valores de los campos conefectivo y contarjeta
    let conefectivo = parseFloat(document.getElementById('conefectivo').value) || 0;
    let contarjeta = parseFloat(document.getElementById('contarjeta').value) || 0;

    // Calcular la suma de los importes
    let sumaImportes = conefectivo + contarjeta;

    // Actualizar el campo sumasimportes con la suma calculada
    document.getElementById('sumasimportes').value = sumaImportes.toFixed(2);

    // Calcular el saldo
    let totalAmount = parseFloat(document.getElementById('totalAmount').value) || 0;
    let saldo = totalAmount - sumaImportes;

    // Actualizar el campo saldo (vuelto)
    document.getElementById('saldo').value = saldo.toFixed(2);
}


// Agregar eventos de entrada para los campos conefectivo y contarjeta
document.getElementById('totalAmount').addEventListener('input', updateSum);
document.getElementById('conefectivo').addEventListener('input', updateSum);
document.getElementById('contarjeta').addEventListener('input', updateSum);

function formatearFecha(fecha) {
    var partes = fecha.split("/"); // Dividir la fecha por "/"
    var dia = partes[0]; // Obtener el día
    var mes = partes[1]; // Obtener el mes
    var año = partes[2]; // Obtener el año

    // Convertir día y mes a cadenas para asegurar que se pueda acceder a su longitud
    dia = dia.toString();
    mes = mes.toString();

    // Asegurarse de que cada parte de la fecha tenga dos dígitos
    if (dia.length === 1) {
        dia = "0" + dia;
    }
    if (mes.length === 1) {
        mes = "0" + mes;
    }

    // Formatear la fecha como "yyyy-mm-dd"
    return año + "-" + mes + "-" + dia;
}

// Obtener todas las filas de la tabla con la clase "table-hover"
var rows = document.querySelectorAll('.table-hover tbody tr');
// Obtener el botón "Guardar Consulta" por su ID
var btnGuardarConsulta = document.getElementById("btnguardarHistoriaclinica");
// Iterar sobre cada fila y agregar un controlador de eventos clic
rows.forEach(function (row) {
    row.addEventListener('click', function () {
        // Quitar la clase "selected" de todas las filas
        
        rows.forEach(function (row) {
            row.classList.remove('selected');
        });
        // Agregar la clase "selected" a la fila clicada
        this.classList.add('selected');
        btnGuardarConsulta.disabled = true;
    });
});

function cerrarVentana() {
    // Mostrar un mensaje de confirmación al usuario
    var confirmacion = confirm("¿Estás seguro de que deseas cerrar esta ventana?");
    // Si el usuario confirma, cerrar la ventana
    if (confirmacion) {
        // Redirigir al usuario a la página de inicio (Home)
        window.location.href = "/home";
    }
}

function refrescarVentana() {
    // Actualizar la ventana actual
    window.location.reload();
}

function pagosacuenta(){

    var totalimporte = $('#importe').val();
    $('#totalAmount').val(totalimporte);
}
