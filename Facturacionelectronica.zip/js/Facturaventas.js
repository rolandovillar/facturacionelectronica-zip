﻿
    // Asociar el evento click al botón GRABAR PRODUCTO NUEVO
function grabarproductonuevo() {
    var serie = document.getElementById("serieproducto").value.trim();
    var descripcion = document.getElementById("descripcionproducto").value.trim();
    var marca = parseInt(document.getElementById("marcaproducto").value);
    var categoria = parseInt(document.getElementById("categoriaproducto").value);
    var proveedor = parseInt(document.getElementById("proveedorproducto").value);
    var precioventa = parseFloat(document.getElementById("precioventa").value || 0);
    var modelo = document.getElementById("modeloproducto").value;
    var hoy = new Date().toISOString().split('T')[0]; // Formato 'aaaa-MM-dd'

    if (!serie || !descripcion || marca === 0 || categoria === 0 || proveedor === 0) {
        Swal.fire('Error', 'Faltan datos obligatorios.', 'error');
        return;
    }

    var producto = {
        Descripcion: descripcion,
        Serie: serie,
        Precioventa: precioventa,
        Preciocosto: 0,
        CategoriaId: categoria,
        MarcaId: marca,
        Fechavencimiento: hoy,
        Unidadmedida: "UND",
        ProveedorId: proveedor,
        Modelo: modelo,
        Activo: 1,
        Stock: 0
    };

    $.ajax({
        type: "POST",
        url: "/FacturaVenta/GuardarProducto",
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify(producto),
        success: function (data) {
            if (data !== 0) {
                Swal.fire('Producto Ingresado', 'Puedes continuar.', 'success').then(() => {
                    nuevoproductoindex();
                    resetModal();
                });
            } else {
                Swal.fire('Error', 'Hubo un error al guardar el producto.', 'error');
            }
        },
        error: function (xhr, status, error) {
            console.error("Error en la solicitud AJAX:", xhr.responseText);
            Swal.fire('Error', `Detalles del error: ${xhr.responseText}`, 'error');
        }
    });
}

function verificarCliente(urlVerificar) {
    // Obtener el valor del campo nroRucDni
    var nroRucDni = $('#nroRucDni').val();

    // Verificar si el campo está vacío o no contiene un número válido de dígitos
    if (!nroRucDni || !(/^\d{8}(?:\d{3})?$/.test(nroRucDni))) {
        alert("Ingrese un número de documento válido del cliente con 8 o 11 dígitos.");
        return; // Salir de la función si el número de documento no es válido
    }
    // Realizar una solicitud AJAX para verificar si existe en la base de datos de clientes
    $.ajax({
        url: urlVerificar,
        type: 'POST',
        data: { nroRucDni: nroRucDni },
        success: function (response) {
            // Aquí puedes manejar la respuesta según lo que necesites
            if (response.existe) {
                alert('El cliente existe en la base de datos.');
            } else {
                buscaenapi(nroRucDni);

            }
        },
        error: function (xhr, status, error) {
            console.error(error);
        }
    });
}
var cont=0

function btnAddItem() {
    var idprod = document.getElementById("idproducto").value;
    var nombreProducto = document.getElementById("nombreproducto").value;
    var cantidad = document.getElementById("cantidad").value;
    var precio = document.getElementById("precio").value;
    var serie = document.getElementById("serie").value;
    var modelo = document.getElementById("modelo").value;
    var marca = document.getElementById("marca").value;
    var proveedor = document.getElementById("proveedor").value;
    var igv = document.getElementById("igv").value;
    var igv2 = 1 + (igv / 100);
    var presinigv = (precio / igv2).toFixed(2);

    if (idprod === "" || nombreProducto === "" || cantidad === "" || precio === "" ) {
        Swal.fire({
            icon: 'error',
            title: 'Datos incompletos',
            text: 'Por favor, complete todos los campos del producto antes de añadirlo a la tabla.',
        });
        return;
    }

    cont++;
    var total = (parseFloat(cantidad) * parseFloat(precio)).toFixed(2);

    var fila = `
                <tr>
                    <td>${cont}</td>
                    <td>${serie}</td>
                    <td>${nombreProducto}</td>
                    <td>${cantidad}</td>
                    <td>${precio}</td>
                    <td>${total}</td>
                    <td><button type="button" class="btn btn-danger btn-sm" onclick="eliminarFila(this)">Eliminar</button></td>
                    <td>${presinigv}</td>
                    <td>${modelo}</td>
                    <td>${marca}</td>
                    <td>${proveedor}</td>
                    <td>${idprod}</td>
                    </tr>`;

    $('#tabproductos tbody').append(fila);
    limpiarCampos();
    leertabla();
}
function limpiarCampos() {

    document.getElementById("nombreproducto").value = "";
    document.getElementById("cantidad").value = "1";
    document.getElementById("precio").value = "";
    document.getElementById("serie").value = "";
    document.getElementById("marca").value = "";
    document.getElementById("modelo").value = "";
    document.getElementById("proveedor").value = "";
}

// captura Id del registro a eliminar
function eliminarFila(btn) {
    var fila = btn.parentNode.parentNode;
    fila.parentNode.removeChild(fila);
    reordenarFilas();
    leertabla();
}
function reordenarFilas() {
    var filas = document.querySelectorAll('#tabproductos tbody tr');
    cont = 0;
    filas.forEach(function (fila) {
        cont++;
        fila.children[0].textContent = cont;
    });
}

listar();
// Lenar Combo Tipo de Documento
function listar() {
    document.getElementById("btgrabar2").disabled = true;
    document.getElementById("btimpri1").hidden = true;

}
//Seleccionar cliente  en ventana modal
btSeleccionar = (url) => {
    $.ajax({
        type: 'POST',
        url: url,
        contentType: false,
        processData: false,
        cache: false,
        success: function (data) {
            document.getElementById("idcliente").value = data.id,
                document.getElementById("nombre").value = data.nombre,
                document.getElementById("direccion").value = data.direccion,
                document.getElementById("ruc").value = data.dniRuc,
                document.getElementById("tipodocumentocliente").value = data.tipodocumentocliente,
                document.getElementById("Cerrar").click()
        }
    });
},
    //Detalles de Factura para ventana modal 
    btSelecdetalle = (url) => {
        $.ajax({
            type: 'GET',
            url: url,
            contentType: false,
            processData: false,
            cache: false,
            success: function (data) {

            }
        });
    },
 
//  borra contenido de text 
function borrarDatos1() {
    // Poner en blanco los casilleros de producto
    $('#idproducto').val('');
    $('#nombreproducto').val('');
    $('#cantidad').val('1');
    $('#precio').val('');
    $('#serie').val('');
    $('#modelo').val('');
    $('#marca').val('');
    $('#proveedor').val('');
}
// lee la tabla para totalizar importes 
function leertabla() {
    var subtot = 0.00;
    var total2 = 0.00;
    var igv = parseFloat(document.getElementById("igv").value) || 0;
    var igv2 = 1 + (igv / 100);

    if ($('#tabproductos tbody tr').length === 0) {
        document.getElementById('txtTotalDocumento').value = "0.00";
        document.getElementById('txtTotalIgv').value = "0.00";
        document.getElementById('txtSubTotal').value = "0.00";
    } else {
        $('#tabproductos tbody tr').each(function () {
            var totalitem = parseFloat($(this).find("td").eq(5).html()) || 0;
            total2 += totalitem;
        });

        subtot = (total2 / igv2).toFixed(2);
        var igv1 = (total2 - subtot).toFixed(2);

        document.getElementById('txtTotalDocumento').value = total2.toFixed(2);
        document.getElementById('txtTotalIgv').value = igv1;
        document.getElementById('txtSubTotal').value = subtot;
    }

    var boton = document.getElementById('btgrabar2');
    boton.disabled = (total2 == 0);
}

function btngrabar() {

    var tipodoc1 = document.getElementById("nombre").value;
    if (tipodoc1 == "") {
        $("#btnbuscliente").focus();
        Swal.fire({
            icon: 'error',
            title: 'Seleccione un Cliente  ...',
            text: 'Precione Boton Buscar Cliente!',
        });
    }
    else {
        Swal.fire({

            title: 'Esta seguro de Guardar Datos del Documento?',
            text: "luego no puede modificar los datos!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, deseo guardar.'

        }).then((result) => {

                if (result.value) {
                    // Mostrar el modal de pago antes de guardar
                    showPaymentModal();
                }

                // Mostrar spinner de carga
              //  Swal.fire({
              //      title: 'Guardando Datos...',
              //      html: '<i class="fa fa-spinner fa-spin"></i> Espere un momento por favor.',
              //      showCancelButton: false,
              //      showConfirmButton: false,
              //      allowOutsideClick: false,
              //      allowEscapeKey: false,
              //      allowEnterKey: false
              //  });
               btncontinuar();
        });
    }
}
function btncontinuar() {
    var totalimporte = parseFloat(document.getElementById("totalAmount").value) || 0;
    var conefectivo = parseFloat(document.getElementById("conefectivo").value) || 0;
    var contarjeta = parseFloat(document.getElementById("contarjeta").value) || 0;
    var saldo = parseFloat(document.getElementById("saldo").value) || 0;
    var sumasimportes = parseFloat(document.getElementById("sumasimportes").value) || 0;

    if (sumasimportes == 0) {
        alert("INGRESE EL IMPORTE VALIDO PARA ESTA FACTURA");
        return;
    }

    if (saldo < 0) {
        alert("IMPORTE INGRESADO NO PUEDE SER MAYOR AL SALDO A PAGAR");
        return;
    }
    agregarcabecera();
}

// Función para mostrar el modal de pago
function showPaymentModal() {

    // Mostrar el modal
    $('#paymentModal').modal('show');
    
    var totalfactura = document.getElementById("txtTotalDocumento").value;
    // Mostrar el monto total en el modal
     document.getElementById("totalAmount").value = totalfactura;
 
}


function agregarcabecera() {
    //  alert("estoy en agregar cabecera");
    var frmCab = new FormData();   
    var documentoemisor = document.getElementById("rucemisor").value;
    var idcliente = document.getElementById("idcliente").value;
    var nombre = document.getElementById("nombre").value;
    var direcc = document.getElementById("direccion").value;
    var ruc = document.getElementById("ruc").value;
    var serie = document.getElementById("txtNroserie").value;
    var combo = document.getElementById("cboDocumento");
    var documento = combo.options[combo.selectedIndex].text;
    var nrodocumento = document.getElementById("txtNroDoc").value;
    var serieFactura = document.getElementById("letrayseriesunat").value;
    var nrorecepcion = document.getElementById("nrorecepcion").value;
    var idrecepcion = document.getElementById("idrecepcion").value;
    var total = document.getElementById("txtTotalDocumento").value;
    var tipopago = document.getElementById("cbotipopago").value;
    var nroseriefactura = document.getElementById("nrodocumentosunat").value;
    var letradocumento = document.getElementById("letrasunat").value;
    var letrayseriesunat = document.getElementById("letrayseriesunat").value;
    var tipodocumentosunat = document.getElementById("idsunat").value;
    var tipodocumentocliente = document.getElementById("tipodocumentocliente").value;
    var situacion = "";
    var saldo = 0;
    var acuenta = 0;
    if (tipopago == "CONTADO") {
        situacion = "PAGADO";
        saldo = 0;
        acuenta = total;
    } else {
        situacion = "PENDIENTE";
        acuenta = 0;
        saldo = total;
    }
    var formapago = document.getElementById("cboformapago").value;
    //   var telefonos = document.getElementById("telefono").value;
    var subtotal = document.getElementById("txtSubTotal").value;
    var igv = document.getElementById("txtTotalIgv").value;
    var fecha = document.getElementById("datepicker").value;
    var newdate = fecha.split("-").reverse().join("-");
    saldo = parseFloat(saldo).toFixed(2);
    subtotal = parseFloat(subtotal).toFixed(2);
    igv = parseFloat(igv).toFixed(2);
    acuenta = parseFloat(acuenta).toFixed(2);
    var qr = `${documentoemisor} ${igv} ${subtotal} ${nrodocumento} ${ruc}`;
    var serie = document.getElementById("serie").value;
    var modelo = document.getElementById("modelo").value;
    var marca = document.getElementById("marca").value;
    var pagoefectivo = document.getElementById("conefectivo").value;
    var pagotarjeta = document.getElementById("contarjeta").value;
    // var vuelto = document.getElementById("vuelto").value;


    //  alert("estoy en agregar cabecera 2");
    var frmCab = new FormData();
    frmCab.append("CodCli", idcliente);
    frmCab.append("NomCli", nombre);
    frmCab.append("DireCli", direcc);
    frmCab.append("Ruc", ruc);
    frmCab.append("TipDoc", documento);
    frmCab.append("NroDocumento", nrodocumento);
    frmCab.append("NroFac", nroseriefactura);
    frmCab.append("NroSerieFactura", serieFactura);
    frmCab.append("LetraDocumento", letradocumento);
    frmCab.append("LetrayserieSunat", serieFactura);
    frmCab.append("Tipodocumentosunat", tipodocumentosunat);
    frmCab.append("Tipodocumentocliente", tipodocumentocliente);
    //  frmCab.append("Telefono", telefonos);
    frmCab.append("Formapago", formapago);
    frmCab.append("Tipopago", tipopago);
    frmCab.append("SubTot", subtotal);
    frmCab.append("Igv", igv);
    frmCab.append("Neto", total);
    frmCab.append("Acuenta", acuenta);
    frmCab.append("Saldo", saldo);
    frmCab.append("Fecha", newdate);
    frmCab.append("Situacion", situacion);
    frmCab.append("Idrecepcion", idrecepcion);
    frmCab.append("Nrorecepcion", nrorecepcion);
    frmCab.append("Serie", serie);
    frmCab.append("Modelo", modelo);
    frmCab.append("Marca", marca);
    frmCab.append("PagoEfectivo", pagoefectivo);
    frmCab.append("PagoTarjeta", pagotarjeta);

    var qrData = "CIF: " + document.getElementById("rucemisor").value + "\nImpuesto: " + document.getElementById("txtTotalIgv").value + "\nNeto: " + document.getElementById("txtSubTotal").value + "\nDocumento Cliente: " + document.getElementById("ruc").value;
    frmCab.append("Qr", qrData);

    //   frmCab.append("Idhabilitado", 1);
    //   alert("estoy en agregar cabecera 3");
    $.ajax({
        type: "POST",
        url: "/FacturaVenta/Create",
        data: frmCab,
        contentType: false,
        processData: false,
        success: function (data) {
            if (data != 0) {
                Ordenartalles();
            } else {
                alert("Ocurrio un error al Grabar Cabecera");
            }
        },
    });
}
function Ordenartalles() {
    // Llama a agregardetalles con una función de callback para agregarDetallesFinales
    agregardetalles();
}

function agregardetalles() {
    console.log("Entró a la función agregardetalles()");
    // ordena campos para guardarlos en detalle facturas
    $('#tabproductos tbody tr').each(function () {
        var nroseriefactura = document.getElementById("nrodocumentosunat").value;
        var combo = document.getElementById("cboDocumento");
        var documento = combo.options[combo.selectedIndex].text;
        var numerofactura = document.getElementById("txtNroDoc").value;
        var serie = $(this).find("td").eq(1).html();
        var descproducto = $(this).find("td").eq(2).html();
        var cantidad = parseFloat($(this).find("td").eq(3).html());
        var precio = parseFloat($(this).find("td").eq(4).html());
        var importe = parseFloat($(this).find("td").eq(5).html());
        var precsinigv = parseFloat($(this).find("td").eq(7).html());
        var marca = $(this).find("td").eq(9).html();
        var modelo = $(this).find("td").eq(8).html();
        var idproducto = parseFloat($(this).find("td").eq(11).html());
        var fecha = document.getElementById("datepicker").value;
        var newdate = fecha.split("-").reverse().join("-");
        var idcliente = document.getElementById("idcliente").value;
        var nombre = document.getElementById("nombre").value;

        var formData = new FormData();
        formData.append("NroFac", nroseriefactura);
        formData.append("TipDoc", documento);
        formData.append("NroSerieFactura", numerofactura);
        formData.append("Fecha", newdate);
        formData.append("CodProd", idproducto);
        formData.append("DescProd", descproducto);
        formData.append("CanProd", cantidad);
        formData.append("PunitProd", precio);
        formData.append("Total", importe);
        formData.append("CodCli", idcliente);
        formData.append("NomCli", nombre);
        formData.append("precsinigvsunat", precsinigv);
        formData.append("Serie", serie);
        formData.append("Marca", marca);
        formData.append("Modelo", modelo);
      //  formData.append("CodigoproductoSunat", codigosunat);

        $.ajax({
            type: "POST",
            url: "/FacturaVenta/VentaDetalle",
            data: formData,
            contentType: false,
            processData: false,
            success: function (data) {
                if (data != 0) {

                    //  envios(data);
                    agregarDetallesFinales(data);

                } else {
                    alert("Ocurrio un error en guardar documento");
                }
            },
        });
    });
}

//envio de Factura para facturacion electronica 
//function envios(envio3) {
//    $.ajax({
//        type: 'POST',
//        url: "/GeneraJson/GeneraJson",
//        data: { envio3: envio3 },
//        success: function (data) {
//            agregarDetallesFinales(envio3);
//        }
//    });
//}

function agregarDetallesFinales(envio3) {
    // Tu lógica para agregardetalles aquí
    // Después de completar, llama al callback
    Swal.fire({
        //   position: 'center',
        icon: 'success',
        title: 'Has logrado guardar el Documento de Venta.',
        showConfirmButton: true, // Mostrar el botón de confirmación
        allowOutsideClick: false // Evita que el usuario cierre el mensaje haciendo clic fuera de él
    }).then((result) => {
        if (result.isConfirmed) {
            imprimirFactura(); // Llama a la función de impresión
            // Si el usuario hace clic en "Aceptar", recarga la página
            location.reload();
        }
    });

  //  $.ajax({
  //      type: 'POST',
  //      url: "/GeneracionFacturas/Grabacdr",
  //      data: { envio3: envio3 },
  //      success: function (data) {
  //          //  agregarDetallesFinales(envio3);
  //      }
  //  });
}
function imprimirFactura() {
    // Obtener la URL del enlace
    var url = "\CrearPdf";

    // Abrir la URL en una nueva pestaña
    var win = window.open(url, '_blank');

    // Esperar un momento antes de imprimir para asegurar que la página se cargue completamente
    setTimeout(function () {
        win.print(); // Imprimir la página en la nueva pestaña
    }, 1000); // Ajusta el tiempo de espera según sea necesario
}

function buscaenapi(buscaenapi) {
    var nrorucdni = $('#nroRucDni').val();

    $.ajax({
        url: "/FacturaVenta/Buscadnirucapi",
        method: 'POST',
        data: { rucdni: nrorucdni },
        success: function (response) {
            if (response.digitos == 0) {
                alert("DOCUMENTO NO EXISTE ..... INGRESE UN DOCUMENTO VALIDO ...");
                return
            }
            // Procesar la respuesta de la API y asignar el nombre y la dirección a los campos correspondientes
            if (response.digitos == 8) {
                $('#nombreCliente').val(response.nombrecliente);
                // Obtener el botón por su id
                var boton = document.getElementById("btnBuscarclinew");
                // Deshabilitar el botón
                boton.disabled = true;
                deshabilitarCampos()

            } if (response.digitos == 11) {
                $('#nombreCliente').val(response.nombrecliente);
                $('#direccionsunat').val(response.direccion);
                $('#ubigeo').val(response.codigoubigeocliente);
                $('#estado').val(response.estado);
                $('#departamentosunat').val(response.departamentocliente);
                $('#provinciasunat').val(response.provinciacliente);
                $('#distritosunat').val(response.distritocliente);
                // Obtener el botón por su id
                var boton = document.getElementById("btnBuscarclinew");
                // Deshabilitar el botón
                deshabilitarCampos()
                boton.disabled = true;
            } if (response.digitos == 0) {
                alert("Corrija el numero Documento , no se encuentra en SUNAT");
            }

        },
    });
}
function borrarCampos() {
    // Tu código para borrar los campos aquí
    var campos = document.getElementsByClassName("borrar2");
    for (var i = 0; i < campos.length; i++) {
        campos[i].value = ""; // Limpia el valor de cada campo
    }
    var campoNroRucDni = document.getElementById('nroRucDni');
    campoNroRucDni.disabled = false;
}

// Obtener referencia al campo nroRucDni y al botón btnBuscarclinew
var campoNroRucDni = document.getElementById('nroRucDni');
var botonBuscar = document.getElementById('btnBuscarclinew');

// Agregar evento input al campo nroRucDni
campoNroRucDni.addEventListener('input', function () {
    // Verificar si el campo tiene entre 8 y 11 dígitos y si tiene algún valor
    if (/^\d{8,11}$/.test(campoNroRucDni.value.trim())) {
        // Si cumple con la longitud y tiene algún valor, habilitar el botón
        botonBuscar.disabled = false;
    } else {
        // Si está vacío, deshabilitar el botón
        botonBuscar.disabled = true;
    }
});

function deshabilitarCampos() {
    // Obtener todos los elementos de entrada de texto con la clase "borrar2"
    var camposTexto = document.querySelectorAll('.borrar2');

    // Recorrer todos los campos de texto y deshabilitarlos
    camposTexto.forEach(function (campo) {
        campo.disabled = true;
    });
}

function btnGuardarnuevocliente() {
    // Capturar los datos del formulario modal
    var formData = new FormData();
    var dniruc = document.getElementById("nroRucDni").value;
    var digitos;
    var tipodocumentocliente;

    var nombrenuevo = document.getElementById("nombreCliente").value;
    var direccion = document.getElementById("direccionsunat").value;
    var codigoubigeocliente = document.getElementById("ubigeo").value;
   //var estado = document.getElementById("estado").value;
    var departamentocliente = document.getElementById("departamentosunat").value;
    var provinciacliente = document.getElementById("provinciasunat").value;
    var distritocliente = document.getElementById("distritosunat").value;

    formData.append("Rucdni", dniruc);
    formData.append("Nombrecliente", nombrenuevo);
    formData.append("Direccion", direccion);
    formData.append("Codigoubigeocliente", codigoubigeocliente);
    //formData.append("Estado", estado);
    formData.append("Departamentocliente", departamentocliente);
    formData.append("Provinciacliente", provinciacliente);
    formData.append("Distritocliente", distritocliente);
    formData.append("Activo", 1);
  //  formData.append("Digitos", digitos);
  //  formData.append("Tipodocumentocliente", tipodocumentocliente);

    // Realizar la solicitud AJAX al controlador
    $.ajax({
        method: 'POST',
        url: "/FacturaVenta/GuardarClienteNuevo",
        data: formData,
        contentType: false,
        processData: false,
        success: function (data) {

            alert("Cliente nuevo agregado Exitosamente");
            // Pasa cliente nuevo en la vista principal
            nuevocliaindex();
            //      // Cierra el modal
            resetModalclinuevo();
            //  } else {
            //      alert("Error al agregar el cliente. Por favor, inténtelo de nuevo.");
            //  }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("Error en la solicitud: ", textStatus, errorThrown);
            alert("Se produjo un error al intentar agregar el cliente. Por favor, inténtelo de nuevo.");
        }
    });
}

function nuevocliaindex() {
    $.ajax({
        url: "/FacturaVenta/PasarNuevoCliente",
        method: 'POST',
        success: function (data) {
            if (data != null) {
                alert("Nuevo cliente ingresado exitosamente");
                document.getElementById("idcliente").value = data.id;
                document.getElementById("nombre").value = data.nombrecliente;
                document.getElementById("direccion").value = data.direccion;
                document.getElementById("ruc").value = data.rucdni;
                document.getElementById("tipodocumentocliente").value = data.tipodocumentocliente;
                $('#modalAgregarCliente').modal('hide');
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("Error en la solicitud: ", textStatus, errorThrown);
            alert("Se produjo un error al intentar pasar el nuevo cliente. Por favor, inténtelo de nuevo.");
        }
    });
}

function mostrarFormularioNuevoProducto() {
    $('#modalNuevoProducto').modal('show');
}

$(document).ready(function () {
    $('#btnGuardarProducto').click(function () {
        var formData = $('#formNuevoProducto').serialize();

        $.ajax({
            type: 'POST',
            url: '/GeneracionFacturas/GuardarProducto',
            data: formData,
            success: function (data) {
                if (data != null) {
                    alert('Producto guardado exitosamente.');

                    nuevoproductoindex();
                    $('#modalNuevoProducto').modal('hide');

                } else {
                    alert('Producto no se pudo guardar en base de datos ....    revisar');
                   return
                }
                // Opcional: Actualizar la lista de productos sin recargar la página
                // Aquí puedes hacer una llamada AJAX para obtener la lista actualizada de productos y refrescar la parte relevante del DOM
            },
        });
    });
});

function nuevoproductoindex() {
    $.ajax({
        url: "/FacturaVenta/PasarNuevoProducto",
        method: 'POST',
        success: function (data) {
            if (data) {
                alert("Nuevo Producto ingresado exitosamente");

                // Asignar valores a los campos del formulario
                document.getElementById("idproducto").value = data.id;
                document.getElementById("nombreproducto").value = data.descripcion;
                document.getElementById("precio").value = data.precioventa;
                document.getElementById("serie").value = data.serie;
                document.getElementById("modelo").value = data.modelo;
                document.getElementById("proveedor").value = data.proveedor;
                document.getElementById("marca").value = data.marca;

                // Ocultar el modal
                $('#modalNuevoProducto').modal('hide');

                // Esperar un momento para enfocar el botón "Adiciona Item"
                setTimeout(function () {
                    document.getElementById("btnAddItem2").focus();
                }, 500);
            }
        },
        error: function (xhr, status, error) {
            console.error("Error al procesar la solicitud:", error);
            alert("Hubo un error al obtener el producto. Por favor, inténtelo de nuevo.");
        }
    });
}

$(document).ready(function () {
    // Función para actualizar sumasimportes y saldo
    function updateSums() {
        var efectivo = parseFloat($('#conefectivo').val()) || 0;
        var tarjeta = parseFloat($('#contarjeta').val()) || 0;
        var totalAmount = parseFloat($('#totalAmount').val()) || 0;

        var sumasImportes = efectivo + tarjeta;
        var saldo = totalAmount - sumasImportes;

        $('#sumasimportes').val(sumasImportes.toFixed(2));
        $('#saldo').val(saldo.toFixed(2));
    }

    // Actualizar valores al cambiar conefectivo o contarjeta
    $('#conefectivo, #contarjeta').on('input', function () {
        updateSums();
    });

    // Inicializar sumas y saldo al mostrar el modal
    $('#paymentModal').on('shown.bs.modal', function () {
        updateSums();
    });
});

function seleccionarRecepcion(id, nro, tipoDocumento) {
    // Pasar los valores a los campos de la vista principal
    $('#idrecepcion').val(id);
    $('#nrorecepcion').val(nro);
    $('#tipodocumentorecepcion').val(tipoDocumento);

    // Cerrar el modal
    document.getElementById("Cerrarrecepcion").click();
  //  $('#modalrecepcion').modal('hide');
}
function resetModal() {
    $('#modalNuevoProducto').modal('hide');
    $('.modal-backdrop').remove();
    $('body').removeClass('modal-open'); // Limpia cualquier clase residual
}

function resetModalclinuevo() {
    $('#modalNuevoProducto').modal('hide');
    $('.modal-backdrop').remove();
    $('body').removeClass('modal-open'); // Limpia cualquier clase residual
}