﻿function actualizaRecepcion() {

    var nrocomprobante = $('#Nrocomprobante').val();
    var id = $('#id').val();
    var idcliente = $('#idcliente').val();
    var fechaOriginal = document.getElementById("datepicker").value;
    var fechaFormateada = formatearFecha(fechaOriginal);
    var dni = $('#dni').val();
    var nombre = $('#nombre').val();
    var telefono = $('#telefono').val();
    var marca = $('#marca').val();
    var modelo = $('#modelo').val();
    var serie = $('#serie').val();
    var sintomas = $('#sintomas').val();
    var diagnostico = $('#diagnostico').val();
    var recomendacion = $('#recomendacion').val();
    var reparacion = $('#reparacion').val();
    var tipoconsulta = $('#tipoConsulta').val();
    var tipoequipo = $('#tipoequipo').val();

    var frmCab = new FormData();
    frmCab.append("Id", id);
    frmCab.append("Nrocomprobante", nrocomprobante);
    frmCab.append("Codigocli", idcliente);
    frmCab.append("Fechaultimapago", fechaFormateada);
    frmCab.append("Dni", dni);
    frmCab.append("Nombre", nombre);
    frmCab.append("Telefono", telefono);
    frmCab.append("Marca", marca);
    frmCab.append("Modelo", modelo);
    frmCab.append("Serie", serie);
    frmCab.append("Sintomas", sintomas);
    frmCab.append("Diagnostico", diagnostico);
    frmCab.append("Recomendaciones", recomendacion);
    frmCab.append("Reparaciones", reparacion);
    frmCab.append("Tipoconsulta", tipoconsulta);
    frmCab.append("Tipoequipo", tipoequipo);

    $.ajax({
        type: "POST",
        url: "/EditarRecepcion/ActualizaRecepcionequipos",
        data: frmCab,
        contentType: false,
        processData: false,
        success: function (data) {
            if (data != 0) {
                alert("Actualización del Equipo Guardada Correctamente");
                // Cierra la ventana modal después de guardar la cita
                $('#CerrarNew').click();
            } else {
                alert("Ocurrió un error al Grabar Cabecera");
            }
        }
    });
}

function refrescarVentana() {
    // Actualizar la ventana actual
    window.location.reload();
}
//function pagosacuenta() {
 //  var id = $('#id').val();
 //  var totalimporte = $('#importe').val();
 //  var saldo = $('#saldo2').val();
 //  var conefectivo = 0;
 //  var contarjeta = 0;
 //  var sumasimportes = 0;
 //  $('#totalAmount').val(totalimporte);
 //  $('#saldo').val(saldo);
 //  $('#conefectivo').val(conefectivo);
 //  $('#contarjeta').val(contarjeta);
    //  $('#sumasimportes').val(sumasimportes);
//}
    function recuperardatos(element) {
        // Obtener el ID del registro desde el atributo data-id del enlace
        var id = element.getAttribute("data-id");

        // Realizar una petición AJAX para recuperar los datos
        $.ajax({
            type: "GET",
            url: "/EditarRecepcion/Recuperardato",
            data: { id: id },
            success: function (response) {
                // Asignar los valores recibidos a los campos del modal    idrecepcion   Nrocomprobante
                $('#idrecepcion').val(response.id);
                $('#nombre').val(response.nombre);
                $('#nrocomprobante').val(response.nrocomprobante);
                $('#totalAmount').val(response.totalimporte);
                $('#saldo').val(response.saldo);

                if (response.saldo == 0) {
                    // Habilitar el botón "Continuar"
                    document.getElementById('continuar').disabled = true;
                    document.getElementById('conefectivo').disabled = true;
                    document.getElementById('contarjeta').disabled = true;
                } else {
                    document.getElementById('conefectivo').disabled = false;
                    document.getElementById('contarjeta').disabled = false;
                }

                cargarPagos(response.id);
            },
            error: function () {
                alert("Error al cargar los detalles del pago.");
            }
        });

        // La apertura del modal se gestiona automáticamente con `data-toggle`
    }


function cerrarVentana() {
    // Mostrar un mensaje de confirmación al usuario
    var confirmacion = confirm("¿Estás seguro de que deseas cerrar esta ventana?");
    // Si el usuario confirma, cerrar la ventana
    if (confirmacion) {
        // Redirigir al usuario a la página de inicio (Home)
        window.location.href = "/home";
    }
}

function formatearFecha(fecha) {
    var partes = fecha.split("/"); // Dividir la fecha por "/"
    var dia = partes[0]; // Obtener el día
    var mes = partes[1]; // Obtener el mes
    var año = partes[2]; // Obtener el año

    // Convertir día y mes a cadenas para asegurar que se pueda acceder a su longitud
    dia = dia.toString();
    mes = mes.toString();

    // Asegurarse de que cada parte de la fecha tenga dos dígitos
    if (dia.length === 1) {
        dia = "0" + dia;
    }
    if (mes.length === 1) {
        mes = "0" + mes;
    }

    // Formatear la fecha como "yyyy-mm-dd"
    return año + "-" + mes + "-" + dia;
}

// Obtener todas las filas de la tabla con la clase "table-hover"
var rows = document.querySelectorAll('.table-hover tbody tr');
// Obtener el botón "Guardar Consulta" por su ID
var btnGuardarConsulta = document.getElementById("btnguardarHistoriaclinica");
// Iterar sobre cada fila y agregar un controlador de eventos clic

// Función para actualizar la suma de los importes y el saldo
function updateSum() {

        let saldofijo = parseFloat(document.getElementById('saldo').value);

    // Obtener los valores de los campos conefectivo y contarjeta
    let conefectivo = parseFloat(document.getElementById('conefectivo').value) || 0;
    let contarjeta = parseFloat(document.getElementById('contarjeta').value) || 0;
  //  let saldofijo = parseFloat(document.getElementById('saldo').value) || 0;
    let saldo = parseFloat(document.getElementById('saldo').value) || 0;
    // Calcular la suma de los importes
    let sumaImportes = conefectivo + contarjeta;

    // Actualizar el campo sumasimportes con la suma calculada, redondeado a dos decimales
    document.getElementById('sumasimportes').value = sumaImportes.toFixed(2);

    // Calcular el Nuevo saldo
    let totalAmount = parseFloat(document.getElementById('totalimporte').value) || 0;
    let saldo2 = saldofijo - sumaImportes;
    document.getElementById('nuevosaldo').value = saldo2.toFixed(2);

    if (sumaImportes > saldo) {

        alert("SUMA DE IMPORTES ES MAYOR QUE EL SALDO ......... correjir");
        // Desactivar el botón "Continuar"
        document.getElementById('continuar').disabled = true;
        return
    } else {
        document.getElementById('continuar').disabled = false;
        
    }

    // Si la suma de importes es válida (menor o igual al saldo y mayor o igual a cero)
    if (sumaImportes >= 0) {
        // Habilitar el botón "Continuar"
        document.getElementById('continuar').disabled = false;
    } else {
        // Desactivar el botón "Continuar" si la suma es negativa
        document.getElementById('continuar').disabled = true;
    }
   
}


// Agregar eventos de entrada para los campos conefectivo y contarjeta
document.getElementById('totalimporte').addEventListener('input', updateSum);
document.getElementById('conefectivo').addEventListener('input', updateSum);
document.getElementById('contarjeta').addEventListener('input', updateSum);

function cargarPagos(id) {
    $.ajax({
        url: "/EditarRecepcion/Recuperapagosacuenta/" + id,
        method: 'GET',
        success: function (data) {
            let pagosTableBody = $('#pagosTableBody');
            pagosTableBody.empty();

            data.forEach(function (pago) {
                let row = `
                    <tr>
                        <td>${pago.id}</td>
                        <td>${new Date(pago.fechaPago).toLocaleDateString()}</td>
                        <td>${pago.acuentaefectivo.toFixed(2)}</td>
                        <td>${pago.acuentatarjeta.toFixed(2)}</td>
                        <td>${pago.saldo.toFixed(2)}</td>
                        <td><button class="btn btn-danger btn-sm">Eliminar</button></td>
                    </tr>
                `;
                pagosTableBody.append(row);
            });
        },
        error: function (xhr, status, error) {
            console.error('Error al cargar los pagos:', error);
        }
    });
}

function abrirModalPrecio(id) {
    $.get("/ModificaPrecioRecepcion/PasarModificaprecio", { id: id }, function (data) {
        if (data) {
            $("#recepcionId").val(data.id);
            $("#totalimporte").val(data.totalimporte.toFixed(2));
            $("#conefectivo").val(data.acuentaefectivo.toFixed(2));
            $("#contarjeta").val(data.acuentatarjeta.toFixed(2));

            let pagado = data.acuentaefectivo + data.acuentatarjeta;
            let nuevoSaldo = data.totalimporte - pagado;

            $("#saldo").val(nuevoSaldo.toFixed(2));
        }
    }).fail(function () {
        alert("Error al cargar datos de la recepción.");
    });
}

function actualizarprecio() {
    var id = $('#recepcionId').val(); // ← corrección aquí
    var totalAmount = $('#totalimporte').val();
    var acuentaefectivo = $('#conefectivo').val();
    var acuentatarjeta = $('#contarjeta').val();
    var sumasdinero = acuentaefectivo + acuentatarjeta;
    // var saldo = $('#saldo').val();
    var saldo = $('#saldo').val();

    $.ajax({
        url: "/ModificaPrecioRecepcion/actualizarprecio/",
        type: 'POST',
        data: {
            id: id,
            totalimporte: totalAmount,
            saldo: saldo
        },
        success: function (response) {
            if (response.success) {
                alert("Datos actualizados correctamente.");
                $('#paymentModal2').modal('hide');
                location.reload();
            } else {
                alert("Error al actualizar los datos.");
            }
        },
        error: function () {
            alert("Ocurrió un error al actualizar los datos.");
        }
    });
}
function confirmarYGrabar() {
    // Mostrar una ventana de confirmación al usuario
    var confirmacion = confirm("¿Estás seguro de que deseas continuar con el pago?");

    if (confirmacion) {
        // Si el usuario confirma, ejecutar la función grabarpago()
        grabarpago();
    } else {
        // Si el usuario cancela, no hacer nada
        console.log("El usuario canceló la acción.");
    }
}

function grabarpago() {
    // Obtener los valores de los campos conefectivo y contarjeta
    var id = $('#idrecepcion').val();
    var conefectivo = parseFloat(document.getElementById('conefectivo').value) || 0;
    var contarjeta = parseFloat(document.getElementById('contarjeta').value) || 0;
    var nuevosaldo = parseFloat(document.getElementById('nuevosaldo').value) || 0;

    var frmCab = new FormData();
    frmCab.append("Id", id);
    frmCab.append("Acuentaefectivo", conefectivo);
    frmCab.append("Acuentatarjeta", contarjeta);
    frmCab.append("Saldo", nuevosaldo);

    $.ajax({
        type: "POST",
        url: "/EditarRecepcion/Ejecutarpagos",
        data: frmCab,
        contentType: false,
        processData: false,
        success: function (data) {
            if (data != 0) {
                alert("Pagos realizados Guardada Correctamente");
                // Cierra la ventana modal después de guardar la cita
                $('#CerrarNew').click();
                // Reiniciar los campos a cero
                $('#idrecepcion').val(0);         // Reinicia el campo 'idrecepcion'
                $('#conefectivo').val(0);         // Reinicia el campo 'conefectivo'
                $('#contarjeta').val(0);          // Reinicia el campo 'contarjeta'
                $('#nuevosaldo').val(0);          // Reinicia el campo 'nuevosaldo'

                // Si tienes otros campos que también quieras resetear, puedes agregar aquí:
                $('#sumasimportes').val(0);       // Reinicia el campo 'sumasimportes', si aplica
                $('#saldo').val(0);     
                // Redirigir a la página Index
                location.reload(); 

            } else {
                alert("Ocurrió un error al Grabar Cabecera");
            }
        }
    });

    // Aquí va tu código para grabar el pago
    console.log("Pago grabado correctamente.");
    // Puedes hacer una llamada AJAX o cualquier otra acción que desees al grabar el pago.
}

// setear campos (en cero los campos )
function reiniciacampos()
{
    $('#idrecepcion').val(0);         // Reinicia el campo 'idrecepcion'
    $('#conefectivo').val(0);         // Reinicia el campo 'conefectivo'
    $('#contarjeta').val(0);          // Reinicia el campo 'contarjeta'
    $('#nuevosaldo').val(0);          // Reinicia el campo 'nuevosaldo'

    // Si tienes otros campos que también quieras resetear, puedes agregar aquí:
    $('#sumasimportes').val(0);       // Reinicia el campo 'sumasimportes', si aplica
    $('#saldo').val(0);
}