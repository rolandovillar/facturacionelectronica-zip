﻿document.addEventListener("DOMContentLoaded", function () {
    // Obtener el botón
    const botonCrearProducto = document.getElementById("btgrabar2");

    // Asociar el evento click al botón
    botonCrearProducto.addEventListener("click", function () {
        console.log("Botón 'Crear producto' clickeado");

        // Validar serie
        var serie = document.getElementById("serie").value.trim();
        if (!serie) {
            document.getElementById("serie").focus();
            Swal.fire({
                icon: 'error',
                title: 'FALTA SERIE DEL PRODUCTO...',
                text: 'Escriba un producto!',
            });
            return;
        }

        // Validar descripción
        var descripcion = document.getElementById("descripcion").value.trim();
        if (!descripcion) {
            document.getElementById("descripcion").focus();
            Swal.fire({
                icon: 'error',
                title: 'FALTA DESCRIPCIÓN DEL PRODUCTO...',
                text: 'Escriba un producto!',
            });
            return;
        }

        // Validar marca
        var marca = document.getElementById("marca").value;
        if (marca === "Seleccione") {
            document.getElementById("marca").focus();
            Swal.fire({
                icon: 'error',
                title: 'FALTA MARCA DEL PRODUCTO...',
                text: 'Seleccione una marca del producto!',
            });
            return;
        }

        // Validar categoría
        var categoria = document.getElementById("categoria").value;
        if (categoria === "0") {
            document.getElementById("categoria").focus();
            Swal.fire({
                icon: 'error',
                title: 'FALTA SELECCIONAR UNA CATEGORÍA...',
                text: 'Seleccione una categoría!',
            });
            return;
        }

        // Validar proveedor
        var proveedor = document.getElementById("proveedor").value;
        if (proveedor === "0") {
            document.getElementById("proveedor").focus();
            Swal.fire({
                icon: 'error',
                title: 'SELECCIONE A UN PROVEEDOR...',
                text: 'Seleccione un PROVEEDOR!',
            });
            return;
        }

        // Confirmar antes de enviar
        Swal.fire({
            title: '¿Está seguro de que desea guardar el producto?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, guardar!',
            cancelButtonText: 'No, cancelar',
        }).then((result) => {
            if (result.isConfirmed) {
                // Recoger datos del formulario
                var serie = document.getElementById("serie").value;
                var preciocosto = document.getElementById("preciocosto").value || 0;
                var precioventa = document.getElementById("precioventa").value || 0;
                var stock = document.getElementById("stock").value || 0;
                var impuesto = document.getElementById("porcentajeimpuesto").value || 0;
                var marca = document.getElementById("marca");
                var selectmarca = marca?.options[marca.selectedIndex]?.text || "";
                var categoria = parseInt(document.getElementById("categoria").value || 0);
                var fechavencimiento = document.getElementById("fechavencimiento").value || "";
                var unidadmedida = document.getElementById("unidadmedida").value || "";
                var referencia = document.getElementById("referencia").value || "";
                var codproductosunat = document.getElementById("codproductosunat").value || "";
                var codproveedor = document.getElementById("proveedor").value;
                var modelo = document.getElementById("modelo").value;

             //   if (impuesto <= 0) {
             //       alert("Ingresar Impuesto del Producto");
             //       document.getElementById("porcentajeimpuesto").focus();
             //       return;
             //   }

                // Crear objeto FormData
                var frmProd = new FormData();
                frmProd.append("Descripcion", descripcion);
                frmProd.append("Serie", serie);
                frmProd.append("Stock", stock);
                frmProd.append("PorcentajeImpuesto", impuesto);
                frmProd.append("Preciocosto", preciocosto);
                frmProd.append("Precioventa", precioventa);
                frmProd.append("CategoriaId", categoria);
                frmProd.append("MarcaId", marca.value); // Aquí va MarcaId
                frmProd.append("Fechavencimiento", fechavencimiento);
                frmProd.append("Codproductosunat", codproductosunat);
                frmProd.append("Unidadmedida", unidadmedida);
                frmProd.append("ProveedorId", codproveedor);
                frmProd.append("Referencia", referencia);
                frmProd.append("Modelo", modelo);

                // Enviar datos al servidor con AJAX
                $.ajax({
                    type: "POST",
                    url: "/Productos/Create",
                    data: frmProd,
                    processData: false, // Evitar que jQuery procese el objeto FormData
                    contentType: false, // Evitar que jQuery configure automáticamente el Content-Type
                    success: function (data) {
                        if (data != 0) {
                            Swal.fire('Producto Ingresado', 'Revisa en la lista de productos.', 'success');
                            window.location.href = "/Productos/Index";
                        } else {
                            Swal.fire('Error', 'Ups... Hubo un error al guardar el producto.', 'error');
                        }
                    },
                });
            }
        });
    });
});

function editarProducto() {
    // Validaciones
    var serie = document.getElementById("serie").value.trim();
    if (!serie) {
        Swal.fire('Error', 'Debe ingresar una Serie para el producto.', 'error');
        document.getElementById("serie").focus();
        return;
    }

    var descripcion = document.getElementById("descripcion").value.trim();
    if (!descripcion) {
        Swal.fire('Error', 'Debe ingresar una descripción para el producto.', 'error');
        document.getElementById("descripcion").focus();
        return;
    }

    var marca = document.getElementById("marca").value;
    if (marca === "") {
        Swal.fire('Error', 'Debe seleccionar una marca.', 'error');
        document.getElementById("marca").focus();
        return;
    }

    var categoria = document.getElementById("categoria").value;
    if (categoria === "") {
        Swal.fire('Error', 'Debe seleccionar una categoría.', 'error');
        document.getElementById("categoria").focus();
        return;
    }

    var proveedor = document.getElementById("proveedor").value;
    if (proveedor === "") {
        Swal.fire('Error', 'Debe seleccionar un proveedor.', 'error');
        document.getElementById("proveedor").focus();
        return;
    }

    // Recoger datos del formulario
    var frmProd = new FormData();
    frmProd.append("Id", document.querySelector("[name='Id']").value);
    frmProd.append("Descripcion", descripcion);
    frmProd.append("Serie", document.getElementById("serie").value);
    frmProd.append("PorcentajeImpuesto", document.getElementById("porcentajeimpuesto").value);
    frmProd.append("Referencia", document.getElementById("referencia").value);
    frmProd.append("Preciocosto", document.getElementById("preciocosto").value || 0);
    frmProd.append("Precioventa", document.getElementById("precioventa").value || 0);
    frmProd.append("Stock", document.getElementById("stock").value || 0);
    frmProd.append("MarcaId", marca);
    frmProd.append("CategoriaId", categoria);
    frmProd.append("ProveedorId", proveedor);
    frmProd.append("Unidadmedida", document.getElementById("unidadmedida").value || "UND");
    frmProd.append("Fechavencimiento", document.getElementById("fechavencimiento").value || "");
    frmProd.append("Modelo", document.getElementById("modelo").value);

    // Confirmación
    Swal.fire({
        title: '¿Está seguro de editar este producto?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, editar',
        cancelButtonText: 'No, cancelar',
    }).then((result) => {
        if (result.isConfirmed) {
            // AJAX
            $.ajax({
                type: "POST",
                url: "/Productos/Edit",
                data: frmProd,
                processData: false,
                contentType: false,
                success: function (data) {
                    if (data !== 0) {
                        Swal.fire('Producto actualizado', 'El producto ha sido editado con éxito.', 'success').then(() => {
                            window.location.href = "/Productos/Index";
                        });
                    } else {
                        Swal.fire('Error', 'Ocurrió un problema al editar el producto.', 'error');
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.error("Error en la solicitud AJAX:", textStatus, errorThrown);
                    Swal.fire('Error', 'Hubo un error en la edición. Inténtelo de nuevo.', 'error');
                }
            });
        }
    });
}