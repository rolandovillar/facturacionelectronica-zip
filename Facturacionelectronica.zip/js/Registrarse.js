﻿$(document).ready(function () {
    // Al hacer clic en el botón de guardar
    $("#btnGuardar").click(function () {
        var nombreempresa = $("#nomempresa").val().trim();
        var direccion = $("#direccion").val().trim();
        var email = $("#email").val().trim();
        var password = $("#password").val().trim();
        var confirmar = $("#confirmarclaves").val().trim();

        // Validaciones de los campos antes de enviar los datos
        if (!nombreempresa || !direccion || !email || !password || !confirmar) {
            showAlert('error', 'Complete todos los campos.');
            return;
        }

        if (password !== confirmar) {
            showAlert('error', 'Las contraseñas no coinciden.');
            return;
        }

        if (password.length < 6) {
            showAlert('error', 'La contraseña debe tener al menos 6 caracteres.');
            return;
        }

        // Mostrar los datos en consola antes de enviarlos
        console.log("Datos que se enviarán al servidor:");
        console.log("NomEmpresa:", nombreempresa);
        console.log("Direccion:", direccion);
        console.log("Correo:", email);
        console.log("NombreUsuario:", $("#usuario").val());
        console.log("Clave:", password);

        // Mostrar el modal de confirmación
        $('#confirmModal').modal('show');
    });

    // Al hacer clic en "Confirmar" en el modal de confirmación
    $("#confirmBtn").click(function () {
        var nombreempresa = $("#nomempresa").val().trim();
        var direccion = $("#direccion").val().trim();
        var email = $("#email").val().trim();
        var password = $("#password").val().trim();

        // Crear FormData para enviar los datos
        var formData = new FormData();
        formData.append("NomEmpresa", nombreempresa);
        formData.append("Direccion", direccion);
        formData.append("NombreUsuario", $("#usuario").val());
        formData.append("Correo", email);
        formData.append("Clave", password);

        // Enviar la solicitud AJAX
        $.ajax({
            type: "POST",
            url: registrarUrl, // Asegúrate de que esta URL sea correcta
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                // Respuesta exitosa
                showAlert('success', 'Registro completado exitosamente.');

                // Espera 3 segundos antes de redirigir
                setTimeout(function () {
                    window.location.href = response.redirectTo;
                }, 3000);
            },
            error: function (xhr, status, error) {
                console.error("Error al registrar:", error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error inesperado al registrar.'
                });
            }
        });

        // Cerrar el modal de confirmación
        $('#confirmModal').modal('hide');
    });

    // Función para mostrar alertas de Bootstrap
    function showAlert(type, message) {
        const alertContainer = document.getElementById('alertContainer');
        alertContainer.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    }
});