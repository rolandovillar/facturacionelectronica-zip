﻿document.addEventListener('DOMContentLoaded', function () {
    cargarempresa();
});

function cargarempresa() {
    var idempresa = 1;

    $.ajax({
        url: '/FacturaVenta/Cargarempresa',
        method: 'GET',
        data: { id: idempresa }, // Envía el id de la empresa al servidor
        dataType: 'json',
        success: function (response) {
            // Actualiza los campos de cabecera del ticket con los valores recibidos
            var rucemisor2 = response.rucemisor2;
            $('#rucemisor2').val(rucemisor2);
            // Construir la dirección concatenada
            // Construir dirección en dos líneas
            var direccionCompleta = response.direccionemisor + "\n" +
                response.provinciaemisor + " - " + response.distritoemisor;
            $('#direccionemisor').text(direccionCompleta);
            var telefonoemisor = response.telefonoemisor;
            $('#telefonoemisor').val(telefonoemisor);
        },
        error: function (error) {
            console.error('Error al obtener la empresa emisora:', error);
        }
    });

}

document.addEventListener('DOMContentLoaded', function () {
    // Selecciona todos los labels dentro de la clase .btn-group-toggle
    const tipoDocLabels = document.querySelectorAll('.btn-group-toggle label');

    tipoDocLabels.forEach(label => {
        label.addEventListener('click', function () {
            const radio = this.querySelector('input[type="radio"]');

            if (radio) {
                // Desmarcar todos los labels
                tipoDocLabels.forEach(lbl => lbl.classList.remove('active'));

                // Marcar el radio como seleccionado
                radio.checked = true;
                radio.dispatchEvent(new Event('change'));

                // Agregar la clase active al label seleccionado
                this.classList.add('active');
            }
        });
    });

    // Evento change para capturar cuando cambia el radio
    document.querySelectorAll('input[name="tipoDocumento"]').forEach(radio => {
        radio.addEventListener('change', function () {
            obtenerNumeroCorrelativo(this.value);
        });
    });

    // Llama a la función para el radio seleccionado por defecto al cargar la página
    const selectedRadio = document.querySelector('input[name="tipoDocumento"]:checked');
    if (selectedRadio) {
        obtenerNumeroCorrelativo(selectedRadio.value);
    }
});

//  // Calcular el vuelto al ingresar el pago en efectivo
//  $(document).on('input', '#pagoEfectivo', function () {
//      calcularVuelto();
//  });

// Función para obtener el número correlativo
function obtenerNumeroCorrelativo(tipoDocumento) {
    $.ajax({
        url: '/FacturaVenta/ObtenerNumeroCorrelativo',
        method: 'GET',
        data: { tipo: tipoDocumento }, // Envía el tipo de documento al servidor
        dataType: 'json',
        success: function (response) {
            // Actualiza los campos con los valores recibidos
            $('#txtNroserie').val(response.nroserie);
            $('#txtNroDoc').val(response.ultimo);
     //       $('#igv').val(response.igv);
            $('#idsunat').val(response.idsunat);
            $('#letrasunat').val(response.letrasunat);
            //  $('#letrayseriesunat').val(response.letrasunat + response.nroserie);
            // let numeroCompleto = String(response.ultimo).padStart(8, '0');
            let numeroCompleto = String(response.ultimo);
            let seriecompleta = response.letrasunat + response.nroserie;
            document.getElementById("numeroCorrelativo").value = seriecompleta + "-" + numeroCompleto;
            let numerotiket = seriecompleta + "-" + numeroCompleto;

            if (response.idsunat == 1) {
                $('#documentodeventa').text('FACTURA');
                $('#NroDocumento').text(numerotiket);
            }

            if (response.idsunat == 3) {
                $('#documentodeventa').text('BOLETA');
                $('#NroDocumento').text(numerotiket);
            }

            if (response.idsunat == 999) {
                $('#documentodeventa').text('TICKET');
                $('#NroDocumento').text(numerotiket);
            }

            // Obtener el contenido del  con id="totalFactura" ,  vienen de un span
            const totalValue = parseFloat(document.getElementById("totalFactura").value);

            document.getElementById("NroDocumento").textContent = document.getElementById("numeroCorrelativo").value;

            // Verificar si el valor es un número antes de asignarlo
            if (!isNaN(totalValue)) {
                document.getElementById('montoCobrar').value = totalValue.toFixed(2);
                document.getElementById('montoCobrar2').value = totalValue.toFixed(2);
                document.getElementById('importeEfectivo').value = totalValue.toFixed(2);
            } else {
                console.error("totalFactura no es un número válido.");
            }
        },
        error: function (error) {
            console.error('Error al obtener el número correlativo:', error);
        }
    });
}

document.getElementById('btnFinalizarVenta').addEventListener('click', function () {
    console.log("🔹 Botón 'Finalizar Venta' presionado...");

    $("#modalComprobante").modal("show");

    const pedidoTable = document.getElementById('detalleFactura');
    if (!pedidoTable || pedidoTable.rows.length === 0) {
        console.error("❌ No hay productos en la tabla detalleFactura.");
        alert("No hay productos en la factura.");
        return;
    }

    const tablaPedidos = document.getElementById('tablaPedidos');
    if (!tablaPedidos) {
        console.error("❌ No existe el contenedor 'tablaPedidos' en el HTML.");
        return;
    }

    // Limpiar filas anteriores
    tablaPedidos.innerHTML = '';

    // Agregar nuevas filas al <tbody> existente
    Array.from(pedidoTable.rows).forEach((row, index) => {
        if (row.cells.length < 7) {
            console.warn(`⚠️ Fila ${index} incompleta, se omite.`);
            return;
        }

        const id = row.cells[0].textContent.trim();
        const nombre = row.cells[1].querySelector('input')?.value.trim() || row.cells[1].textContent.trim();
        const precio = row.cells[2].querySelector('input')?.value.trim() || row.cells[2].textContent.trim();
        const serie = row.cells[3].textContent.trim();
        const marca = row.cells[4].textContent.trim();
        const cantidad = row.cells[5].querySelector('input')?.value.trim() || row.cells[5].textContent.trim();
        const subtotal = row.cells[6].textContent.trim();

        if ([nombre, precio, cantidad, subtotal].some(v => v === '')) {
            console.error(`❌ Faltan valores en la fila ${index}. Se ignora.`);
            return;
        }

        console.log(`✅ Producto ${index + 1}: ${cantidad}x ${nombre} - €${precio} - Subtotal: €${subtotal}`);

        const newRow1 = document.createElement('tr');
        newRow1.innerHTML = `
            <td style="padding: 4px; font-size:12px;">${cantidad}</td>
            <td style="padding: 4px; word-wrap: break-word; max-width: 150px; font-size:12px;">${nombre}</td>
            <td style="padding: 4px; font-size:13px;">${precio}</td>
            <td style="padding: 4px; font-size:13px;">${subtotal}</td>
        `;
        tablaPedidos.appendChild(newRow1);

        const newRow2 = document.createElement('tr');
        newRow2.innerHTML = `
            <td colspan="4" class="text-center" style="font-size: 12px; padding: 2px;">
                <strong>Marca:</strong> ${marca} | <strong>Serie:</strong> ${serie}
            </td>
        `;
        tablaPedidos.appendChild(newRow2);
    });

    // Actualizar totales
    const totalPedido = parseFloat(document.getElementById("totalFactura").value) || 0;
    const totalFormateado = totalPedido.toFixed(2);



    document.getElementById("montoCobrar").value = totalFormateado;
    document.getElementById("montoCobrar2").value = totalFormateado;
    document.getElementById("importeEfectivo").value = totalFormateado;
    document.getElementById("totalFactura2").value = totalFormateado;


    document.getElementById("NroDocumento").textContent = document.getElementById("numeroCorrelativo").value;

    console.log("✅ Ticket generado exitosamente.");
});

document.addEventListener('DOMContentLoaded', function () {
    const input = document.getElementById('buscarCliente');
    const datalist = document.getElementById('listaClientes');


    // Obtener los elementos del DOM para el cálculo del vuelto e importe a pagar
    const montoCobrar = document.getElementById("montoCobrar"); // 'montoCobrar' es un span, por lo que usamos textContent
    const importeEfectivoInput = document.getElementById('importeEfectivo'); // 'importeEfectivo' es un input, por lo que usamos .value
    const importetarjetaInput = document.getElementById('montoTarjeta'); // 'montoTarjeta' es un input, por lo que usamos .value
    // Función para calcular el vuelto
    function calcularVuelto() {

        const monto = parseFloat(montoCobrar.value) || 0; // Monto a cobrar
        const importeEfectivo = parseFloat(importeEfectivoInput.value) || 0; // Importe efectivo ingresado
        const importeTarjeta = parseFloat(importetarjetaInput.value) || 0; // Importe efectivo ingresado
        const vuelto = (importeTarjeta + importeEfectivo) - monto; // Calcula el vuelto
        const vueltoInput = vuelto.toFixed(2); // Formatea el vuelto con dos decimales

        // Muestra el vuelto calculado en el campo "vuelto"
        document.getElementById("vuelto").value = vueltoInput;

        // Opcional: Mostrar alert para depuración
        //   alert("Monto: " + monto + ", Efectivo: " + importeEfectivo + ", Tarjeta: " + importeTarjeta + ", Vuelto: " + vuelto);
    }
    // Agregar eventos para recalcular el vuelto cuando cambien los valores
    importeEfectivoInput.addEventListener('input', calcularVuelto);
    importetarjetaInput.addEventListener('input', calcularVuelto);
});


// FINALIZA LA VENTA TOTAL DEL PEDIDO , GENERANDO EL DOCUMENTO DE VENTA 

$(document).on("click", "#btnFinalizarVentaModal", function () {

    const nombreCliente = document.getElementById("buscarCliente2").value.trim();

    if (nombreCliente === "") {
        alert("Por favor, seleccione un cliente antes de finalizar la venta.");
        // También puedes enfocar el campo:
        document.getElementById("buscarCliente2").focus();
        return; // Evita que continúe si no hay cliente
    }


    // Mostrar mensaje de confirmación
    if (confirm("¿Está seguro de que desea finalizar la venta y grabar el documento de venta?")) {

        // Aquí preparas los datos que deseas enviar al controlador.
        // Por ejemplo, puedes obtener los datos de la cabecera y de los detalles de la venta.
        // Esto es un ejemplo; adapta los datos a tu caso.
        // Obtener el valor del radio seleccionado

        var docVentaVal = document.querySelector("input[name='tipoDocumento']:checked").value;

        var docVentaText = "";

        if (docVentaVal === "1") {
            docVentaText = "FACTURA";
        } else if (docVentaVal === "3") {
            docVentaText = "BOLETA";
        } else if (docVentaVal === "4") {
            docVentaText = "TICKET";
        }

        var datosVenta = {
            // TipDoc: $("input[name='tipoDocumento']:checked").val(), // Tipo de documento seleccionado
            TipDoc: docVentaText,
            NroFac: $("#NroDocumento").text().trim(),                // Número de documento (desde un span)
            NroDocumento: $("#txtNroDoc").val().trim(),              // Solo el Numero de la factura (desde un input)
            CodCli: parseInt($("#idcliente").val()) || null,
            NomCli: $("#buscarCliente2").val().trim(),               // Nombre del cliente (desde un span)
            DireCli: $("#direccionCliente").text().trim(),           // Dirección del cliente (asegúrate de tener este campo)
            Ruc: $("#documentoCliente").text().trim(),               // RUC/DNI del cliente (desde un span)
            Formapago: $("#metodoPago").val().trim(),
            Fecha: new Date(),                                       // Fecha de emisión
            Neto: parseFloat($("#totalFactura").val()) || 0,                // Total (si #total es un input)
            PagoEfectivo: parseFloat($("#importeEfectivo").val()) || 0,                // Total (si #total es un input)
            PagoTarjeta: parseFloat($("#montoTarjeta").val()) || 0,                // Total (si #total es un input)
            Vuelto: parseFloat($("#vuelto").val()) || 0,                // Total (si #total es un input)
            Facturadetalles: obtenerDetallesporFacturar() // ⬅️ Cambiado a "Facturadetalles"                // Array con los detalles del pedido
        };

        console.log("Datos enviados:", JSON.stringify(datosVenta)); // 👈 Verifica en la consola antes de enviar
        $.ajax({

            url: '/FacturaVenta/GuardarVenta',
            type: 'POST',
            data: JSON.stringify(datosVenta),
            contentType: 'application/json',
            processData: false, // Asegura que jQuery no altere los datos
            success: function (response) {

                // Abrir la ventana de impresión del ticket (CrearPdf)
                var urlImpresion = "/FacturaVenta/CrearPdf?facturaId=" + response.facturaId; // Asegúrate de que 'facturaId' se retorne en la respuesta
                var ventanaImpresion = window.open(urlImpresion, "_blank");

                envios(response.facturaId);

                alert("Se Guardo la Venta Correctamente .......")

                // Esperar un momento para que se genere el PDF y luego redirigir al Index
                setTimeout(function () {
                    window.location.href = '/FacturaVenta/Index';
                }, 3000); // ⬅️ Espera 3 segundos antes de redirigir
            },
            error: function (error) {
                alert("Error al guardar el documento de venta");
                console.error("Error:", error);
            }
        });
    }
});

//envio datos de Factura para generar el JSON
function envios(envio3) {
    $.ajax({
        type: 'POST',
        url: "/GeneraJson/GeneraJson",
        data: { envio3: envio3 },
        success: function (data) {

            alert("Se Guardo la Venta Correctamente .......")

            // Esperar un momento para que se genere el PDF y luego redirigir al Index
            setTimeout(function () {
                window.location.href = '/FacturaVenta/Index';
            }, 3000); // ⬅️ Espera 3 segundos antes de redirigir
        }
    });
}


// Ejemplo de función para extraer los detalles del pedido desde la tabla de pedidos
function obtenerDetallesporFacturar() {
    var detalles = [];

    var codcli = parseInt($("#idcliente").val()) || null;
    var nomcli = $("#buscarCliente2").val().trim(); // Nombre del cliente

    $("#detalleFactura tr").each(function () {
        var $row = $(this);

        var id = $row.find("td:eq(0)").text().trim();
        var $nombreInput = $row.find(".nombre");
        var $precioInput = $row.find(".precio");
        var $cantidadInput = $row.find(".cantidad");

        if ($nombreInput.length === 0 || $precioInput.length === 0 || $cantidadInput.length === 0) {
            console.warn("❌ Faltan inputs en la fila, se ignora.");
            return;
        }

        var descripcion = $nombreInput.val().trim();
        var precio = parseFloat($precioInput.val()) || 0;
        var cantidad = parseFloat($cantidadInput.val()) || 1;
        var serie = $row.find("td:eq(3)").text().trim();
        var marca = $row.find("td:eq(4)").text().trim();
        var subtotal = parseFloat($row.find("td:eq(6)").text().replace(/[^\d.-]/g, '')) || 0;

        detalles.push({
            CodCli: codcli,
            NomCli: nomcli,
            CodProd: id,
            CanProd: cantidad,
            DescProd: descripcion,
            PunitProd: precio,
            Total: subtotal,
            Serie: serie,
            Marca: marca
        });
    });

    console.log("Detalles extraídos:", detalles);
    return detalles;
}