﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Tipodocumento
{
    public int Id { get; set; }

    public int? Cod { get; set; }

    public string? Documento { get; set; }

    public string? NroSerie { get; set; }

    public int? Ultimo { get; set; }

    public decimal? Impuesto { get; set; }

    public string? Idsunat { get; set; }

    public string? Letrasunat { get; set; }

    public int? Digitos { get; set; }

    public int? IdEmpresas { get; set; }
}
