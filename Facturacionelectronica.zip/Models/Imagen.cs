﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Imagen
{
    public int Id { get; set; }

    public byte[]? Imagen1 { get; set; }

    public int? IdEmpresa { get; set; }

    public string? MimeType { get; set; }
}
