﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Comprascabe
{
    public int Id { get; set; }

    public string? TipoDoc { get; set; }

    public string? NroDoc { get; set; }

    public int? CodProv { get; set; }

    public string? NomProv { get; set; }

    public DateTime? Fecha { get; set; }

    public string? Ruc { get; set; }

    public string? Direccion { get; set; }

    public decimal? SubTotal { get; set; }

    public decimal? Impuesto { get; set; }

    public decimal? Total { get; set; }

    public string? TipoCompra { get; set; }

    public string? Formapago { get; set; }

    public string? Situacion { get; set; }

    public decimal? Igic { get; set; }

    public int? IdEmpresas { get; set; }

    public List<Comprasdetalle> comprasdetalles { get; set; }
}
