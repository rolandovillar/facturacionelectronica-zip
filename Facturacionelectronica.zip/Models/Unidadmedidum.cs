﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Unidadmedidum
{
    public int Id { get; set; }

    public string? Nombreunidadmedida { get; set; }

    public int? IdEmpresas { get; set; }
}
