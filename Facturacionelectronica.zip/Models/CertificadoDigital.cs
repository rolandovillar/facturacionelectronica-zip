﻿namespace Facturacionelectronica.Models
{
    public class CertificadoDigital
    {
        public int Id { get; set; }
        public string EmpresaRUC { get; set; }
        public string Entorno { get; set; }
        public string NombreArchivoCertificado { get; set; }
        public byte[] ServerPem { get; set; }
        public byte[] ServerKeyPem { get; set; }
        public DateTime FechaCarga { get; set; } = DateTime.UtcNow;
        public int IdEmpresa { get; set; }
    }
}
