﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Facturacabe
{
    public int Id { get; set; }

    public string? NroFac { get; set; }

    public int? CodCli { get; set; }

    public DateTime? Fecha { get; set; }

    public DateTime? Fechapago { get; set; }

    public string? Formapago { get; set; }

    public decimal? SubTot { get; set; }

    public decimal? Impuesto { get; set; }

    public decimal? Neto { get; set; }

    public string? TipDoc { get; set; }

    public string? NomCli { get; set; }

    public string? Moneda { get; set; }

    public string? NroGuia { get; set; }

    public string? Situacion { get; set; }

    public decimal? Acuenta { get; set; }

    public decimal? Saldo { get; set; }

    public string? Ruc { get; set; }

    public string? Observacion { get; set; }

    public string? CodVen { get; set; }

    public string? NomVen { get; set; }

    public DateTime? FechaAnulacion { get; set; }

    public string? MesAño { get; set; }

    public string? MesAñoOk { get; set; }

    public string? DireCli { get; set; }

    public string? NroSerieFactura { get; set; }

    public string? NroFacOk { get; set; }

    public decimal? Descuento { get; set; }

    public decimal? NetoPagar { get; set; }

    public string? NumLetras { get; set; }

    public int? Dias { get; set; }

    public string? OrdenCompra { get; set; }

    public string? Simbolo { get; set; }

    public string? Usuario { get; set; }

    public string? PorcIgv { get; set; }

    public string? Telefono { get; set; }

    public string? SituacionComision { get; set; }

    public TimeOnly? Hora { get; set; }

    public DateTime? FechapagoComision { get; set; }

    public int? NroDocumento { get; set; }

    public string? Tipodocumentosunat { get; set; }

    public string? Tipodocumentocliente { get; set; }

    public string? LetraDocumento { get; set; }

    public string? LetrayserieSunat { get; set; }

    public string? Tipopago { get; set; }

    public int? Idrecepcion { get; set; }

    public string? Nrorecepcion { get; set; }

    public string? Qr { get; set; }

    public string? Rucemisor { get; set; }

    public decimal? PagoEfectivo { get; set; }

    public decimal? PagoTarjeta { get; set; }

    public decimal? Vuelto { get; set; }

    public int? IdEmpresas { get; set; }

    public List<Facturadetalle> Facturadetalles { get; set; }
}
