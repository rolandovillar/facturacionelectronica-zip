﻿using System.Security.Cryptography;
using System.Text;

namespace Facturacionelectronica.Models.Servicios
{
        public class EncryptionService
        {
            private readonly byte[] _key;
            private readonly byte[] _iv = new byte[16]; // Considera usar IV aleatorio para mayor seguridad

            public EncryptionService(string encryptionKey)
            {
                _key = Encoding.UTF8.GetBytes(encryptionKey.PadRight(32).Substring(0, 32)); // Asegura longitud 256 bits
            }

            public byte[] Encrypt(byte[] data)
            {
                using var aes = Aes.Create();
                aes.Key = _key;
                aes.IV = _iv;

                using var ms = new MemoryStream();
                using var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write);
                cs.Write(data, 0, data.Length);
                cs.FlushFinalBlock();
                return ms.ToArray();
            }

            public byte[] Decrypt(byte[] encryptedData)
            {
                using var aes = Aes.Create();
                aes.Key = _key;
                aes.IV = _iv;

                using var ms = new MemoryStream(encryptedData);
                using var cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read);
                using var result = new MemoryStream();
                cs.CopyTo(result);
                return result.ToArray();
            }
        }
}
