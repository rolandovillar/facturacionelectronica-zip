﻿namespace Facturacionelectronica.Models.Servicios
{
    public class CertificadoService
    {
        private readonly Contexto _context;
        private readonly EncryptionService _encryptionService;

        public CertificadoService(Contexto context, EncryptionService encryptionService)
        {
            _context = context;
            _encryptionService = encryptionService;
        }

        public async Task<byte[]> ObtenerCertificadoDesencriptadoAsync(int certificadoId)
        {
            var certificado = await _context.CertificadosDigitales.FindAsync(certificadoId);
            if (certificado == null)
                throw new Exception("Certificado no encontrado.");

            return _encryptionService.Decrypt(certificado.ServerPem);
        }
    }
}
