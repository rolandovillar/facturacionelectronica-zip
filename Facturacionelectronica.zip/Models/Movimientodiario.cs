﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Movimientodiario
{
    public int Id { get; set; }

    public string? Comprobante { get; set; }

    public int? Nrocomprobante { get; set; }

    public DateTime? Fecha { get; set; }

    public int? Codcliente { get; set; }

    public string? Nombre { get; set; }

    public decimal? Importeefectivo { get; set; }

    public decimal? Importetarjeta { get; set; }

    public string? Referencia { get; set; }

    public int? IdEmpresas { get; set; }
}
