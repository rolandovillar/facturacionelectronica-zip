﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class TipoEquipo
{
    public int Id { get; set; }

    public string? Nombre { get; set; }

    public int? IdEmpresas { get; set; }
}
