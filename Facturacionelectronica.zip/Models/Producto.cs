﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Producto
{
    public int Id { get; set; }

    public string? Serie { get; set; }

    public string? Descripcion { get; set; }

    public decimal? Preciocosto { get; set; }

    public decimal? Precioventa { get; set; }

    public string? Presentacion { get; set; }

    public int? CategoriaId { get; set; }

    public int? MarcaId { get; set; }

    public string? Modelo { get; set; }

    public DateTime? Fechavencimiento { get; set; }

    public string? Unidadmedida { get; set; }

    public int? ProveedorId { get; set; }

    public string? Posologia { get; set; }

    public string? Referencia { get; set; }

    public int? Stock { get; set; }

    public string? Categoria { get; set; }

    public string? Marca { get; set; }

    public string? Codproductosunat { get; set; }

    public int? Activo { get; set; }

    public decimal? Presiosinimpuesto { get; set; }

    public int? Igic { get; set; }

    public decimal? PorcentajeImpuesto { get; set; }

    public int? IdEmpresas { get; set; }

    public virtual Categoria CategoriumNavegation { get; set; }

    // Relación de navegación a Marca
    public virtual Marca MarcaNavigation { get; set; }

    // Relación de navegación a Proveedor
    public virtual Proveedor ProveedorNavigation { get; set; }
}
