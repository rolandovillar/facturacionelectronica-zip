﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Recepcionequipo
{
    public int Id { get; set; }

    public int? Nrocomprobante { get; set; }

    public string? Nombre { get; set; }

    public int? Codigocli { get; set; }

    public string? Dni { get; set; }

    public DateTime? Fechaatencion { get; set; }

    public DateTime? Fechaultimapago { get; set; }

    public string? Sintomas { get; set; }

    public string? Diagnostico { get; set; }

    public string? Recomendaciones { get; set; }

    public string? Reparaciones { get; set; }

    public string? Tipocita { get; set; }

    public string? Tipoconsulta { get; set; }

    public string? Tipoequipo { get; set; }

    public string? Marca { get; set; }

    public string? Modelo { get; set; }

    public string? Serie { get; set; }

    public string? Telefono { get; set; }

    public decimal? Totalimporte { get; set; }

    public decimal? Acuentaefectivo { get; set; }

    public decimal? Acuentatarjeta { get; set; }

    public decimal? Saldo { get; set; }

    public string? Situacion { get; set; }

    public string? Situacion2 { get; set; }

    public string? Tipodocumento { get; set; }

    public string? Nrofactura { get; set; }

    public int? Idfacturacabe { get; set; }

    public string? Qr { get; set; }

    public int? IdEmpresas { get; set; }
}
