﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Cliente
{
    public int Id { get; set; }
    public string? Nombrecliente { get; set; }

    public string? Rucdni { get; set; }

    public string? Direccion { get; set; }

    public string? Tipodocumentocliente { get; set; }

    public string? Telefono { get; set; }

    public int? Digitos { get; set; }

    public string? Correo { get; set; }

    public string? Distritocliente { get; set; }

    public string? Provinciacliente { get; set; }

    public string? Departamentocliente { get; set; }

    public string? Codigoubigeocliente { get; set; }

    public string? Estado { get; set; }

    public int? Activo { get; set; }

    public int? IdEmpresas { get; set; }
}
