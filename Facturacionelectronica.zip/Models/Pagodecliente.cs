﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Pagodecliente
{
    public int Id { get; set; }

    public string? NroSerie { get; set; }

    public int? NumeroFactura { get; set; }

    public string? TipDoc { get; set; }

    public DateTime? FechaPago { get; set; }

    public DateTime? FechaFactura { get; set; }

    public string? Formapago { get; set; }

    public decimal? Importe { get; set; }

    public decimal? Acuentaefectivo { get; set; }

    public decimal? Acuentatarjeta { get; set; }

    public decimal? Saldo { get; set; }

    public int? CodCli { get; set; }

    public string? NombreCliente { get; set; }

    public int? Idrecepcionequipos { get; set; }

    public int? IdEmpresas { get; set; }
}
