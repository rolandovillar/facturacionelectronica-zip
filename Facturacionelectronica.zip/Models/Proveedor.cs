﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Proveedor
{
    public int Id { get; set; }

    public string? Nombreproveedor { get; set; }

    public string? Rucdni { get; set; }

    public string? Direccion { get; set; }

    public string? Telefono { get; set; }

    public string? Correo { get; set; }

    public int? Activo { get; set; }

    public int? IdEmpresas { get; set; }
}
