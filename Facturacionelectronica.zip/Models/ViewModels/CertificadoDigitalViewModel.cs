﻿using System.ComponentModel.DataAnnotations;

namespace Facturacionelectronica.Models.ViewModels
{
    public class CertificadoDigitalViewModel
    {
        public int IdEmpresa { get; set; }
        public string EmpresaRUC { get; set; }

        [Required]
        public IFormFile ServerPem { get; set; }

        [Required]
        public IFormFile ServerKeyPem { get; set; }
    }
}
