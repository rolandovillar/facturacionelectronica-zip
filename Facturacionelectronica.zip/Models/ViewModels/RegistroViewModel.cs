﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class RegistroViewModel
    {
        public string NomEmpresa { get; set; }
        public string Direccion { get; set; }
        public string NombreUsuario { get; set; }
        public string Clave { get; set; }
        public string Correo { get; set; }
        public string? Rol { get; set; }
    }
}
