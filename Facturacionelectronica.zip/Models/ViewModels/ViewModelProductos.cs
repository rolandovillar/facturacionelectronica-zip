﻿    
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Facturacionelectronica.Models.ViewModels
{
    public class ViewModelProductos
    {
        public int Id { get; set; }
        public string? Desc_prod { get; set; }
        public decimal? Pre_venta { get; set; }

    }
}
