﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class VentadetallesFechasViewModel
    {
        public string RangoFechas { get; set; }
        public List<Facturadetalle> Detalles { get; set; }
    }
}
