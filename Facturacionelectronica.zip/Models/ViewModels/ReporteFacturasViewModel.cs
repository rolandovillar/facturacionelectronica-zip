﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class ReporteFacturasViewModel
    {
        public string? NroFac { get; set; }
        public DateTime Fecha { get; set; }
        public string? NomCli { get; set; }
        public string? DescProd { get; set; }
        public decimal  Importe { get; set; }
        public string? Notacredito { get; set; }
        public string? Situacion { get; set; }
        public string Mes { get; set; }
        public string? Año { get; set; }
    }

    public class ReporteFacturasTotalViewModel
    {
        public List<ReporteFacturasViewModel> Facturas { get; set; }
        public decimal TotalImporte { get; set; }
    }
}
