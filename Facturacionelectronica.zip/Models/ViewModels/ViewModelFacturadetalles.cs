﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class ViewModelFacturadetalles
    {
        public string Id { get; set; }
        public string NroFac { get; set; } = null!;
        public int? CodProd { get; set; }
        public decimal? PunitProd { get; set; }
        public int? CanProd { get; set; }
        public decimal? Total { get; set; }
        public int? CodCli { get; set; }
        public string NomCli { get; set; } = null!;
        public string DescProd { get; set; } = null!;
        public string? Situacion { get; set; }
        public string? CodVen { get; set; }
        public string? NomVen { get; set; }
        public DateTime? FechaAnulacion { get; set; }
        public string? UndMedida { get; set; }
        public string? MesAño { get; set; }
        public decimal? PreUnitDolar { get; set; }
        public decimal? ImporteDolar { get; set; }
        public string? Moneda { get; set; }
        public int facturacabeid { get; set; }
        public string? FormaPago { get; set; }
        public DateTime? Fecha { get; set; }
        public string? MesAñoOk { get; set; }
        public string? TipDoc { get; set; }
        public decimal? TipoCambio { get; set; }
        public decimal? PreCosto { get; set; }
        public decimal? PorcUtil { get; set; }
        public decimal? Utilidad { get; set; }
        public string? Marca { get; set; }
        public string? Simbolo { get; set; }
        public double? PorcDescuento { get; set; }
        public decimal? Descuento { get; set; }
        public decimal? PrecioLista { get; set; }
        public string? Usuario { get; set; }
        public string? Codigobarra { get; set; }
        public string? Imagen { get; set; }
        public TimeOnly? Hora { get; set; }
        public string? Serie { get; set; }
        public string? Modelo { get; set; }
        public string? Historiaclinica { get; set; }
        public string? CodigoProducto { get; set; }
        public string? NroSerieFactura { get; set; }
        public decimal? precsinigvsunat { get; set; }
        public string? FacturacabeNroFac { get; set; }
        public List<Venta> ventas { get; set; }

        // Propiedades para las fechas de inicio y fin
        public string FechaInicio { get; set; }
        public string FechaFin { get; set; }
        public decimal? PorcentajeImpuesto { get; set; }
        public decimal? TotalpreciosinImpuesto { get; set; }

    }

    public class Venta
    {
        public int Id { get; set; }
        public string Cliente { get; set; }
        public DateTime Fecha { get; set; }
        public decimal Total { get; set; }
    }
}
