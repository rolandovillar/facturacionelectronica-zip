﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Facturacionelectronica.Models.ViewModels
{
    public class ViewModelVenta
    {
        public int Id { get; set; }
        public string? TipDoc { get; set; }
        public string? NroFac { get; set; }
        public string? CodCli { get; set; }
        public string? NomCli { get; set; }
        public string? Ruc { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime? Fecha { get; set; }
        public string? Dni { get; set; }
        public string? DireCli { get; set; }
        public decimal? SubTot { get; set; }      
        public decimal? Igv { get; set; }
        public decimal? Neto { get; set; }
        public string? Tipopago { get; set; }
        public string? Telefono { get; set; }
        public string Situacion { get; set; }
        
        public List<ViewModelFacturadetalles> facturadetalles { get; set; }

    }
}
