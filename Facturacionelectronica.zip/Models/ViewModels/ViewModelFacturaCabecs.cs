﻿
using Microsoft.EntityFrameworkCore.Metadata;
using System.IO;
namespace Facturacionelectronica.Models.ViewModels
{
    public class ViewModelFacturaCabecs
    {           
        public int? Id { get; set; }
        public string NroFac { get; set; } = null!;
        public int? CodCli { get; set; }
        public DateTime? Fecha { get; set; }
        public DateTime? Fechapago { get; set; }
        public string? Formapago { get; set; }
        public decimal? SubTot { get; set; }
        public decimal? Igv { get; set; }
        public decimal? Neto { get; set; }
        public string? TipDoc { get; set; }
        public int? NroDocumento { get; set; }
        public string? NomCli { get; set; }
        public string? Moneda { get; set; }
        public string? NroGuia { get; set; }
        public string? Situacion { get; set; }
        public decimal? Acuenta { get; set; }
        public decimal? Saldo { get; set; }
        public string? Ruc { get; set; }
        public string? Observacion { get; set; }
        public string? CodVen { get; set; }
        public string? NomVen { get; set; }
        public DateTime? FechaAnulacion { get; set; }
        public string? MesAño { get; set; }
        public string? MesAñoOk { get; set; }
        public string? DireCli { get; set; }
        public string? NroSerieFactura { get; set; }
        public string? NroFacOk { get; set; }
        public decimal? SubTotDolar { get; set; }
        public decimal? Igvdolar { get; set; }
        public decimal? NetoDolar { get; set; }
        public decimal? Descuento { get; set; }
        public decimal? NetoPagar { get; set; }
        public decimal? TipoCambio { get; set; }
        public string? NumLetras { get; set; }
        public int? Dias { get; set; }
        public string? OrdenCompra { get; set; }
        public string? Simbolo { get; set; }
        public string? Usuario { get; set; }
        public string? PorcIgv { get; set; }
        public string? Telefono { get; set; }
        public string? Telefonoemisor { get; set; }
        public string? SituacionComision { get; set; }
        public string? Dni { get; set; }
        public TimeOnly? Hora { get; set; }
        public DateOnly? FechapagoComision { get; set; }
        public double Importecomision { get; set; }
        public string? Representantelegal { get; set; }
        public string? Domiciliofilcal1 { get; set; }
        public string? Domiciliofilcal2 { get; set; }
        public string? Notacredito { get; set; }
        public string? Tipopago { get; set; }
        public string? Edad { get; set; }
        public decimal? ConTarjeta { get; set; }
        public string? Tipodocumentosunat { get; set; }
        public string? LetraDocumento { get; set; }
        public string? LetrayserieSunat { get; set; }
        public string? Qr { get; set; }
        public string? TipoDocumentoTicket { get; set; }
        public string? Nombreempresaemisora { get; set; }
        public string? Rucemisor { get; set; }
        public string? Direccionemisor { get; set; }
        public string? Provinciaemisor { get; set; }
        public string? Distritoemisor { get; set; }
        public string? Correlativo { get; set; }
        public string? Tipodocumentocliente { get; set; }
        public string? Ubigeo { get; set; }
        public string? Serienotacredito { get; set; }
        public string? Numeronotacredito { get; set; }
        public string? Tipocomprobantesunatnotacredito { get; set; }
        public string? Nombrearchivocdr { get; set; }
        public string? Respuestacdr { get; set; }
        public int? Idrespuesta { get; set; }
        public int? CdrNotaCredito { get; set; }
        public string? Nrorecepcion { get; set; }
        public int? Idrecepcion { get; set; }
        public string? LogoBase64 { get; set; }
        public decimal? PagoEfectivo { get; set; }
        public decimal? PagoTarjeta { get; set; }
        public decimal? Vuelto { get; set; }
        public List<DetalleFactura> Facturadetalles { get; set; }
    }

    public class DetalleFactura
    {
        public int CodProd { get; set; }
        public int CanProd { get; set; }
        public string DescProd { get; set; }
        public decimal PunitProd { get; set; }
        public decimal Total { get; set; }
        public string Serie { get; set; }
        public string Marca { get; set; }
        public string? Modelo { get; set; }      
    }
}

