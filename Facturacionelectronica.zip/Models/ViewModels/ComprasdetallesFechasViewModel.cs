﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class ComprasdetallesFechasViewModel
    {
        public string RangoFechas { get; set; }
        public List<Comprasdetalle> Detalles { get; set; }
    }
}
