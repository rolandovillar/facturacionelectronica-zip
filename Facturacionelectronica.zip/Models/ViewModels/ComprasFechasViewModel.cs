﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class ComprasFechasViewModel
    {
        public string RangoFechas { get; set; }
        public List<Comprascabe> Compras { get; set; }
    }
}
