﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class FacturaViewModel
    {
        public string NroFac { get; set; }
        public DateTime Fecha { get; set; }
        public string NomCli { get; set; }
        public string DescProd { get; set; }
        public decimal Importe { get; set; }
        public string Notacredito { get; set; }
        public string Situacion { get; set; }
    }
}
