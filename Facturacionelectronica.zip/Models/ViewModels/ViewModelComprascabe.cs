﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Facturacionelectronica.Models.ViewModels
{
    public class ViewModelComprascabe
    {
      
        public DateTime? Fecha { get; set; }
        public int Id { get; set; }
        public int? CodProv { get; set; }
        public string? TipoDoc { get; set; }
        public string? NroDoc { get; set; }
        public string? NomProv { get; set; }
        public string? Ruc { get; set; }
        public decimal? SubTotal { get; set; }
        public decimal? Igv { get; set; }
        public decimal? Total { get; set; }
        public string? TipoCompra { get; set; }
        public string? Formapago { get; set; }
        public string? Situacion { get; set; }
        public List<ViewModelComprasDetalle> ComprasDetalles { get; set; }

    }
}
