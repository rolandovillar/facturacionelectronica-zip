﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class WiewModelRecepcionEquipos
    {
        public int? Id { get; set; }
        public int Nrocomoprobante { get; set; }
        public string? Nombre { get; set; }
        public int? Codigocli { get; set; }
        public string? Telefono { get; set; }
        public string? Dni { get; set; }
        public DateTime? Fechaatencion { get; set; }
        public string? Sintomas { get; set; }
        public string? Diagnostico { get; set; }
        public string? Recomendaciones { get; set; }
        public string? Reparaciones { get; set; }
        public string? Tipoconsulta { get; set; }
        public string? Marca { get; set; }
        public string? Modelo { get; set; }
        public string? Serie { get; set; }
        public decimal? Totalimporte { get; set; }
        public decimal? Acuentaefectivo { get; set; }
        public decimal? Acuentatarjeta { get; set; }
        public decimal? Saldo { get; set; }
        public string? Tipoequipo { get; set; }
        public string? Tipodocumento { get; set; }
        public string? Nrofactura { get; set; }
        public int? Idfacturacabe { get; set; }      
        public string? Nombreemisor { get; set; }
        public string? RucdniEmisor { get; set; }
        public string? Direccionemisor { get; set; }
        public string? Provinciaemisor { get; set; }
        public string? Distritoemisor { get; set; }
        public string? Telefonoemisor { get; set; }
        public string? Situacion { get; set; }
        public string? LogoBase64 { get; set; }
        public string? Qr { get; set; }
    }
}
