﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class VentasdetallePdf
    {
        public int Id { get; set; }

        public string? NroFac { get; set; }

        public int? CodProd { get; set; }

        public decimal? PunitProd { get; set; }

        public int? CanProd { get; set; }

        public decimal? Total { get; set; }

        public int? CodCli { get; set; }

        public string? NomCli { get; set; }

        public string? DescProd { get; set; }

        public string? Situacion { get; set; }

        public string? UndMedida { get; set; }

        public DateTime? Fecha { get; set; }

        public string? TipDoc { get; set; }

        public string? Marca { get; set; }

        public string? NroSerieFactura { get; set; }
        public string? Serie { get; set; }
        public string? Modelo { get; set; }

    }
}
