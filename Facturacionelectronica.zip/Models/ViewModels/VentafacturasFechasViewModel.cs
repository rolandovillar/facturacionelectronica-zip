﻿namespace Facturacionelectronica.Models.ViewModels
{
    public class VentafacturasFechasViewModel
    {
            public string RangoFechas { get; set; }
            public List<Facturacabe> Facturas { get; set; }
    }
}
