﻿using Microsoft.AspNetCore.Http;

namespace Facturacionelectronica.Models.ViewModels
{
    public class UploadModel
    {
        public IFormFile MyFile { get; set; }
    }
}
