﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Marca
{
    public int Id { get; set; }

    public string? Nombremarca { get; set; }

    public int? IdEmpresas { get; set; }

    public virtual ICollection<Producto> Productos { get; set; } = new List<Producto>();
}
