﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Usuario
{
    public int Idusuario { get; set; }

    public string? Nombre { get; set; }

    public string? Claves { get; set; }

    public string? Roles { get; set; }

    public string? Correo { get; set; }

    public int? IdEmpresas { get; set; }

    public Guid? TokenRestitucion { get; set; }

    public DateTime? FechaRestitucion { get; set; }
}
