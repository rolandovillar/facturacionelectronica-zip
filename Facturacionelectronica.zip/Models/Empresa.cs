﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Empresa
{
    public int Id { get; set; }

    public string? NomEmpresa { get; set; }

    public string? Direccion { get; set; }

    public string? Nrofiscal { get; set; }

    public string? RucDni { get; set; }

    public string? Telefono { get; set; }

    public string? Correo { get; set; }

    public string? Versionubl { get; set; }

    public string? Versionestdoc { get; set; }

    public string? Pais { get; set; }

    public string? Enterecaudador { get; set; }

    public string? Moneda { get; set; }

    public string? SimboloMoneda { get; set; }

    public string? Tipomonedasunat { get; set; }

    public string? CodigoUbigeoemisor { get; set; }

    public string? Departamentoemisor { get; set; }

    public string? Provinciaemisor { get; set; }

    public string? Distritoemisor { get; set; }

    public string? ConectarSunat { get; set; }

    public string? Servidor { get; set; }

    public string? CarpetaCertificasdo { get; set; }

    public string? Passcertificado { get; set; }

    public string? UserSecundario { get; set; }

    public string? PassSecundario { get; set; }

    public string? Servidor2 { get; set; }

    public string? NombreUsuario { get; set; }

    public string? Clave { get; set; }

    public string? Rol { get; set; }
}
