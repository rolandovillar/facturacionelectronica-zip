﻿namespace Facturacionelectronica.Models.ViewModelsJson
{
    public class Empresa
    {
        public string ruc { get; set; }
        public string razon_social { get; set; }
        public string nombre_comercial { get; set; }
        public string domicilio_fiscal { get; set; }
        public string ubigeo { get; set; }
        public string urbanizacion { get; set; }
        public string distrito { get; set; }
        public string provincia { get; set; }
        public string departamento { get; set; }
        public string modo { get; set; }
        public string usu_secundario_produccion_user { get; set; }
        public string usu_secundario_produccion_password { get; set; }
    }

    public class Cliente
    {
        public string razon_social_nombres { get; set; }
        public string numero_documento { get; set; }
        public string codigo_tipo_entidad { get; set; }
        public string cliente_direccion { get; set; }
    }

    public class VentaJson
    {
        public string serie { get; set; }
        public string numero { get; set; }
        public string fecha_emision { get; set; }
        public string hora_emision { get; set; }
        public string fecha_vencimiento { get; set; }
        public string moneda_id { get; set; }
        public string forma_pago_id { get; set; }
        public string total_gravada { get; set; }
        public string total_igv { get; set; }
        public string total_exonerada { get; set; }
        public string total_inafecta { get; set; }
        public string tipo_documento_codigo { get; set; }
        public string nota { get; set; }
    }

    public class Item
    {
        public string producto { get; set; }
        public string cantidad { get; set; }
        public string precio_base { get; set; }
        public string codigo_sunat { get; set; }
        public int codigo_producto { get; set; }
        public string codigo_unidad { get; set; }
        public string tipo_igv_codigo { get; set; }
    }

    public class FacturaJson
    {
        public Empresa empresa { get; set; }
        public Cliente cliente { get; set; }
        public VentaJson venta { get; set; }
        public List<Item> items { get; set; }
    }
}

