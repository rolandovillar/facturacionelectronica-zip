﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Comprasdetalle
{
    public int Id { get; set; }

    public DateTime? Fecha { get; set; }

    public string? NumeroFactura { get; set; }

    public string? Documento { get; set; }

    public int? IdProducto { get; set; }

    public string? Descproducto { get; set; }

    public int? Cantidad { get; set; }

    public int? Idproveedor { get; set; }

    public string? NomProv { get; set; }

    public decimal? PrecSinIgic { get; set; }

    public decimal? Precio { get; set; }

    public decimal? Importe { get; set; }

    public string? Categoria { get; set; }

    public string? Marca { get; set; }

    public string? Serie { get; set; }

    public string? Modelo { get; set; }

    public string? Situacion { get; set; }

    public int? IdVenta { get; set; }

    public int? ComprascabeId { get; set; }

    public string? Referencia { get; set; }

    public decimal? Canon { get; set; }

    public decimal? Porcentajedescuento { get; set; }

    public string? SituacionVenta { get; set; }

    public decimal? PrecioVenta { get; set; }

    public decimal? FechaVenta { get; set; }

    public string? DocumNumeroVenta { get; set; }

    public decimal? PreciobaseCompra { get; set; }

    public int? PorcentajeIgic { get; set; }

    public int? IdEmpresas { get; set; }
}
