﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Facturacionelectronica.Models;

public partial class Contexto : DbContext
{
    public Contexto()
    {
    }

    public Contexto(DbContextOptions<Contexto> options)
        : base(options)
    {
    }

    public virtual DbSet<Categoria> Categoria { get; set; }

    public virtual DbSet<Cliente> Clientes { get; set; }
    public DbSet<CertificadoDigital> CertificadosDigitales { get; set; }

    public virtual DbSet<Comprascabe> Comprascabes { get; set; }

    public virtual DbSet<Comprasdetalle> Comprasdetalles { get; set; }

    public virtual DbSet<Empresa> Empresas { get; set; }

    public virtual DbSet<Facturacabe> Facturacabes { get; set; }

    public virtual DbSet<Facturadetalle> Facturadetalles { get; set; }

    public virtual DbSet<Imagen> Imagens { get; set; }

    public virtual DbSet<Inventario> Inventarios { get; set; }

    public virtual DbSet<Marca> Marcas { get; set; }

    public virtual DbSet<Movimientodiario> Movimientodiarios { get; set; }

    public virtual DbSet<Pagodecliente> Pagodeclientes { get; set; }

    public virtual DbSet<Producto> Productos { get; set; }

    public virtual DbSet<Proveedor> Proveedors { get; set; }

    public virtual DbSet<Recepcionequipo> Recepcionequipos { get; set; }

    public virtual DbSet<TipoEquipo> TipoEquipos { get; set; }

    public virtual DbSet<Tipodocumento> Tipodocumentos { get; set; }

    public virtual DbSet<Tipodocumentocompra> Tipodocumentocompras { get; set; }

    public virtual DbSet<Unidadmedidum> Unidadmedida { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Categoria>(entity =>
        {
            entity.HasKey(e => e.Id); // ✅ Esto define la clave primaria;

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Nombrecategoria).HasMaxLength(100);
        });

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.Id); // ✅ Esto define la clave primaria

            entity.Property(e => e.Codigoubigeocliente).HasMaxLength(20);
            entity.Property(e => e.Correo).HasMaxLength(150);
            entity.Property(e => e.Departamentocliente).HasMaxLength(150);
            entity.Property(e => e.Direccion).HasMaxLength(150);
            entity.Property(e => e.Distritocliente).HasMaxLength(150);
            entity.Property(e => e.Estado).HasMaxLength(20);
            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Nombrecliente).HasMaxLength(150);
            entity.Property(e => e.Provinciacliente).HasMaxLength(150);
            entity.Property(e => e.Rucdni).HasMaxLength(11);
            entity.Property(e => e.Telefono).HasMaxLength(150);
            entity.Property(e => e.Tipodocumentocliente).HasMaxLength(3);
        });

        modelBuilder.Entity<Comprascabe>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Comprasc__3214EC070C31B8A1");

            entity.ToTable("Comprascabe");

            entity.Property(e => e.Direccion).HasMaxLength(150);
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.Formapago).HasMaxLength(20);
            entity.Property(e => e.Igic).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Impuesto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.NomProv).HasMaxLength(150);
            entity.Property(e => e.NroDoc).HasMaxLength(11);
            entity.Property(e => e.Ruc).HasMaxLength(12);
            entity.Property(e => e.Situacion).HasMaxLength(10);
            entity.Property(e => e.SubTotal).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TipoCompra).HasMaxLength(10);
            entity.Property(e => e.TipoDoc).HasMaxLength(15);
            entity.Property(e => e.Total).HasColumnType("decimal(12, 0)");
        });

        modelBuilder.Entity<Comprasdetalle>(entity =>
        {
           
            entity.HasKey(e => e.Id);
            entity.ToTable("Comprasdetalle");

            entity.Property(e => e.Canon).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Categoria).HasMaxLength(30);
            entity.Property(e => e.Descproducto).HasMaxLength(150);
            entity.Property(e => e.DocumNumeroVenta).HasMaxLength(20);
            entity.Property(e => e.Documento).HasMaxLength(15);
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.FechaVenta).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Importe).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Marca).HasMaxLength(20);
            entity.Property(e => e.Modelo).HasMaxLength(30);
            entity.Property(e => e.NomProv).HasMaxLength(120);
            entity.Property(e => e.NumeroFactura).HasMaxLength(11);
            entity.Property(e => e.Porcentajedescuento).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PrecSinIgic).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Precio).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PrecioVenta).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PreciobaseCompra).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Referencia).HasMaxLength(20);
            entity.Property(e => e.Serie).HasMaxLength(25);
            entity.Property(e => e.Situacion).HasMaxLength(10);
            entity.Property(e => e.SituacionVenta).HasMaxLength(30);
        });

        modelBuilder.Entity<Empresa>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Empresas__3214EC0785464D1C");

            entity.Property(e => e.CarpetaCertificasdo).HasMaxLength(300);
            entity.Property(e => e.Clave).HasMaxLength(500);
            entity.Property(e => e.CodigoUbigeoemisor).HasMaxLength(10);
            entity.Property(e => e.ConectarSunat).HasMaxLength(1);
            entity.Property(e => e.Correo).HasMaxLength(150);
            entity.Property(e => e.Departamentoemisor).HasMaxLength(150);
            entity.Property(e => e.Direccion).HasMaxLength(150);
            entity.Property(e => e.Distritoemisor).HasMaxLength(150);
            entity.Property(e => e.Enterecaudador).HasMaxLength(150);
            entity.Property(e => e.Moneda).HasMaxLength(10);
            entity.Property(e => e.NomEmpresa).HasMaxLength(150);
            entity.Property(e => e.NombreUsuario).HasMaxLength(100);
            entity.Property(e => e.Nrofiscal).HasMaxLength(10);
            entity.Property(e => e.Pais).HasMaxLength(150);
            entity.Property(e => e.PassSecundario).HasMaxLength(500);
            entity.Property(e => e.Passcertificado).HasMaxLength(500);
            entity.Property(e => e.Provinciaemisor).HasMaxLength(150);
            entity.Property(e => e.Rol).HasMaxLength(50);
            entity.Property(e => e.RucDni).HasMaxLength(11);
            entity.Property(e => e.Servidor).HasMaxLength(300);
            entity.Property(e => e.Servidor2).HasMaxLength(300);
            entity.Property(e => e.SimboloMoneda).HasMaxLength(3);
            entity.Property(e => e.Telefono).HasMaxLength(100);
            entity.Property(e => e.Tipomonedasunat).HasMaxLength(3);
            entity.Property(e => e.UserSecundario).HasMaxLength(100);
            entity.Property(e => e.Versionestdoc).HasMaxLength(3);
            entity.Property(e => e.Versionubl).HasMaxLength(3);
        });

        modelBuilder.Entity<Facturacabe>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Facturac__3214EC07985B9B15");

            entity.ToTable("Facturacabe");

            entity.Property(e => e.Acuenta).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CodVen).HasMaxLength(5);
            entity.Property(e => e.Descuento).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Dias).HasColumnName("dias");
            entity.Property(e => e.DireCli).HasMaxLength(120);
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.FechaAnulacion).HasColumnType("datetime");
            entity.Property(e => e.Fechapago).HasColumnType("datetime");
            entity.Property(e => e.FechapagoComision).HasColumnType("datetime");
            entity.Property(e => e.Formapago).HasMaxLength(10);
            entity.Property(e => e.Hora).HasColumnName("hora");
            entity.Property(e => e.Impuesto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.LetraDocumento).HasMaxLength(5);
            entity.Property(e => e.LetrayserieSunat).HasMaxLength(5);
            entity.Property(e => e.MesAño).HasMaxLength(7);
            entity.Property(e => e.MesAñoOk)
                .HasMaxLength(7)
                .HasColumnName("MesAñoOK");
            entity.Property(e => e.Moneda).HasMaxLength(8);
            entity.Property(e => e.Neto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.NetoPagar).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.NomCli).HasMaxLength(120);
            entity.Property(e => e.NomVen).HasMaxLength(50);
            entity.Property(e => e.NroFac).HasMaxLength(14);
            entity.Property(e => e.NroFacOk).HasMaxLength(14);
            entity.Property(e => e.NroGuia).HasMaxLength(13);
            entity.Property(e => e.NroSerieFactura).HasMaxLength(5);
            entity.Property(e => e.Nrorecepcion).HasMaxLength(10);
            entity.Property(e => e.NumLetras).HasMaxLength(120);
            entity.Property(e => e.Observacion).HasMaxLength(100);
            entity.Property(e => e.OrdenCompra).HasMaxLength(13);
            entity.Property(e => e.PagoEfectivo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PagoTarjeta).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PorcIgv)
                .HasMaxLength(5)
                .HasColumnName("PorcIGV");
            entity.Property(e => e.Qr).HasMaxLength(2000);
            entity.Property(e => e.Ruc)
                .HasMaxLength(12)
                .HasColumnName("RUC");
            entity.Property(e => e.Rucemisor).HasMaxLength(11);
            entity.Property(e => e.Saldo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Simbolo).HasMaxLength(3);
            entity.Property(e => e.Situacion).HasMaxLength(25);
            entity.Property(e => e.SituacionComision).HasMaxLength(20);
            entity.Property(e => e.SubTot).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Telefono).HasMaxLength(100);
            entity.Property(e => e.TipDoc).HasMaxLength(20);
            entity.Property(e => e.Tipodocumentocliente).HasMaxLength(5);
            entity.Property(e => e.Tipodocumentosunat).HasMaxLength(5);
            entity.Property(e => e.Tipopago).HasMaxLength(10);
            entity.Property(e => e.Usuario).HasMaxLength(30);
            entity.Property(e => e.Vuelto).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<Facturadetalle>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Facturad__3214EC071B081A6E");

            entity.ToTable("Facturadetalle");

            entity.Property(e => e.CodVen).HasMaxLength(5);
            entity.Property(e => e.Codigoproducto).HasMaxLength(8);
            entity.Property(e => e.CodigoproductoSunat).HasMaxLength(20);
            entity.Property(e => e.Descprod).HasMaxLength(100);
            entity.Property(e => e.Descuento).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.FacturacabeNroFac).HasMaxLength(10);
            entity.Property(e => e.Facturacabeid).HasColumnName("facturacabeid");
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.FechaAnulacion).HasColumnType("datetime");
            entity.Property(e => e.FormaPago).HasMaxLength(10);
            entity.Property(e => e.Hora).HasColumnName("hora");
            entity.Property(e => e.Marca).HasMaxLength(150);
            entity.Property(e => e.MesAño).HasMaxLength(7);
            entity.Property(e => e.MesAñoOk)
                .HasMaxLength(7)
                .HasColumnName("MesAñoOK");
            entity.Property(e => e.Modelo).HasMaxLength(150);
            entity.Property(e => e.Moneda).HasMaxLength(8);
            entity.Property(e => e.NomCli).HasMaxLength(100);
            entity.Property(e => e.NomVen).HasMaxLength(150);
            entity.Property(e => e.NroFac).HasMaxLength(14);
            entity.Property(e => e.NroSerieFactura).HasMaxLength(10);
            entity.Property(e => e.PorcDescuento).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PorcUtil).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PorcentajeImpuesto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PreCosto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PrecioLista).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Precsinigvsunat).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Punitprod).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Serie).HasMaxLength(20);
            entity.Property(e => e.Simbolo).HasMaxLength(3);
            entity.Property(e => e.Situacion).HasMaxLength(25);
            entity.Property(e => e.TipDoc).HasMaxLength(20);
            entity.Property(e => e.Total).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TotalpreciosinImpuesto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UndMedida).HasMaxLength(30);
            entity.Property(e => e.Usuario).HasMaxLength(150);
            entity.Property(e => e.Utilidad).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<Imagen>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Imagen__3214EC0704CE1B8C");

            entity.ToTable("Imagen");

            entity.Property(e => e.MimeType).HasMaxLength(50);
        });

        modelBuilder.Entity<Inventario>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Inventar__3214EC07D5443B75");

            entity.ToTable("Inventario");

            entity.Property(e => e.Cantidadcompras).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Cantidadventas).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Descproducto).HasMaxLength(120);
            entity.Property(e => e.Documento).HasMaxLength(20);
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.Marca).HasMaxLength(50);
            entity.Property(e => e.Nrodocumento).HasMaxLength(20);
            entity.Property(e => e.Nroserieproducto).HasMaxLength(150);
            entity.Property(e => e.Observaciones).HasMaxLength(100);
            entity.Property(e => e.Referencia).HasMaxLength(100);
            entity.Property(e => e.Saldo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Stock).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<Marca>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Marca__3214EC07587134AA");

            entity.ToTable("Marca");

            entity.Property(e => e.Nombremarca).HasMaxLength(100);
        });

        modelBuilder.Entity<Movimientodiario>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Movimien__3214EC0717653F80");

            entity.ToTable("Movimientodiario");

            entity.Property(e => e.Comprobante).HasMaxLength(20);
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.Importeefectivo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Importetarjeta).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Nombre).HasMaxLength(150);
            entity.Property(e => e.Referencia).HasMaxLength(150);
        });

        modelBuilder.Entity<Pagodecliente>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Pagodecl__3214EC0792E1AF89");

            entity.Property(e => e.Acuentaefectivo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Acuentatarjeta).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.FechaFactura).HasColumnType("datetime");
            entity.Property(e => e.FechaPago).HasColumnType("datetime");
            entity.Property(e => e.Formapago).HasMaxLength(20);
            entity.Property(e => e.Importe).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.NombreCliente).HasMaxLength(120);
            entity.Property(e => e.NroSerie)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Saldo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TipDoc).HasMaxLength(20);
        });

        modelBuilder.Entity<Producto>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Producto__3214EC07E72FA30A");

            entity.Property(e => e.Categoria).HasMaxLength(25);
            entity.Property(e => e.Codproductosunat).HasMaxLength(15);
            entity.Property(e => e.Descripcion).HasMaxLength(120);
            entity.Property(e => e.Fechavencimiento).HasColumnType("datetime");
            entity.Property(e => e.Marca).HasMaxLength(25);
            entity.Property(e => e.Modelo).HasMaxLength(100);
            entity.Property(e => e.PorcentajeImpuesto).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.Posologia).HasMaxLength(200);
            entity.Property(e => e.Preciocosto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Precioventa).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Presentacion).HasMaxLength(100);
            entity.Property(e => e.Presiosinimpuesto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Referencia).HasMaxLength(100);
            entity.Property(e => e.Serie).HasMaxLength(20);
            entity.Property(e => e.Unidadmedida).HasMaxLength(15);
        });

        modelBuilder.Entity<Proveedor>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Proveedo__3214EC073A1C9F1C");

            entity.ToTable("Proveedor");

            entity.Property(e => e.Correo).HasMaxLength(100);
            entity.Property(e => e.Direccion).HasMaxLength(150);
            entity.Property(e => e.Nombreproveedor).HasMaxLength(100);
            entity.Property(e => e.Rucdni).HasMaxLength(11);
            entity.Property(e => e.Telefono).HasMaxLength(25);
        });

        modelBuilder.Entity<Recepcionequipo>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Recepcio__3214EC07A33BE5F7");

            entity.Property(e => e.Acuentaefectivo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Acuentatarjeta).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Diagnostico).HasMaxLength(250);
            entity.Property(e => e.Dni).HasMaxLength(11);
            entity.Property(e => e.Fechaatencion).HasColumnType("datetime");
            entity.Property(e => e.Fechaultimapago).HasColumnType("datetime");
            entity.Property(e => e.Marca).HasMaxLength(20);
            entity.Property(e => e.Modelo).HasMaxLength(20);
            entity.Property(e => e.Nombre).HasMaxLength(80);
            entity.Property(e => e.Nrofactura).HasMaxLength(14);
            entity.Property(e => e.Qr).HasMaxLength(2000);
            entity.Property(e => e.Recomendaciones).HasMaxLength(250);
            entity.Property(e => e.Reparaciones).HasMaxLength(250);
            entity.Property(e => e.Saldo).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Serie).HasMaxLength(30);
            entity.Property(e => e.Sintomas).HasMaxLength(250);
            entity.Property(e => e.Situacion).HasMaxLength(20);
            entity.Property(e => e.Situacion2).HasMaxLength(20);
            entity.Property(e => e.Telefono).HasMaxLength(30);
            entity.Property(e => e.Tipocita).HasMaxLength(250);
            entity.Property(e => e.Tipoconsulta).HasMaxLength(20);
            entity.Property(e => e.Tipodocumento).HasMaxLength(20);
            entity.Property(e => e.Tipoequipo).HasMaxLength(50);
            entity.Property(e => e.Totalimporte).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<TipoEquipo>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__TipoEqui__3214EC073CD3422F");

            entity.ToTable("TipoEquipo");

            entity.Property(e => e.Nombre).HasMaxLength(50);
        });

        modelBuilder.Entity<Tipodocumento>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tipodocu__3214EC0753F21053");

            entity.ToTable("Tipodocumento");

            entity.Property(e => e.Documento).HasMaxLength(20);
            entity.Property(e => e.Idsunat).HasMaxLength(4);
            entity.Property(e => e.Impuesto).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Letrasunat).HasMaxLength(4);
            entity.Property(e => e.NroSerie).HasMaxLength(4);
        });

        modelBuilder.Entity<Tipodocumentocompra>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tipodocu__3214EC0758A7377D");

            entity.Property(e => e.Comprobante).HasMaxLength(20);
        });

        modelBuilder.Entity<Unidadmedidum>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Unidadme__3214EC07F4AC30EA");

            entity.Property(e => e.Nombreunidadmedida).HasMaxLength(20);
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.Idusuario).HasName("PK__Usuario__7AC21576091C444F");

            entity.ToTable("Usuario");

            entity.Property(e => e.Claves).HasMaxLength(500);
            entity.Property(e => e.Correo).HasMaxLength(80);
            entity.Property(e => e.Nombre).HasMaxLength(80);
            entity.Property(e => e.Roles).HasMaxLength(100);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
