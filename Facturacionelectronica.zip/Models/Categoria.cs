﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Categoria
{
    public int Id { get; set; }

    public string? Nombrecategoria { get; set; }

    public int? IdEmpresas { get; set; }

    public virtual ICollection<Producto> Productos { get; set; } = new List<Producto>();
}
