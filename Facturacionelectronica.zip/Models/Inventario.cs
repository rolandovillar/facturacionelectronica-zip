﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Inventario
{
    public int Id { get; set; }

    public DateTime? Fecha { get; set; }

    public int? Tipomov { get; set; }

    public int? Idproducto { get; set; }

    public string? Descproducto { get; set; }

    public int? Tipdocumento { get; set; }

    public string? Documento { get; set; }

    public decimal? Cantidadcompras { get; set; }

    public decimal? Cantidadventas { get; set; }

    public decimal? Saldo { get; set; }

    public string? Nroserieproducto { get; set; }

    public string? Observaciones { get; set; }

    public int? Bhabilitado { get; set; }

    public decimal? Stock { get; set; }

    public int? ComprasdetalleId { get; set; }

    public string? Marca { get; set; }

    public string? Referencia { get; set; }

    public int? IdEmpresas { get; set; }

    public string? Nrodocumento { get; set; }
}
