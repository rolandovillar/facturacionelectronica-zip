﻿using System;
using System.Collections.Generic;

namespace Facturacionelectronica.Models;

public partial class Tipodocumentocompra
{
    public int Id { get; set; }

    public string? Comprobante { get; set; }

    public int? IdEmpresas { get; set; }
}
